package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableHistoryGatewayWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableHistoryGateway#findHistoryList.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableHistoryGatewayFindHistoryListScenario {

    @Test
    @DisplayName("UTAPI-003882")
    void case_UTAPI_003882() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003882",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003882", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003882", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003882", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003882", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003882", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003882", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003882", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003882", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003882", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003882", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003882", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003882", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003882")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003883")
    void case_UTAPI_003883() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003883",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003883", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003883", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003883", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003883", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003883", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003883", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003883", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003883", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003883", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003883", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003883", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003883", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003883")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003884")
    void case_UTAPI_003884() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003884",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003884", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003884", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003884", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003884", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003884", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003884", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003884", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003884", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003884", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003884", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003884", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003884", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003884")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003885")
    void case_UTAPI_003885() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003885",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003885", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003885", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003885", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003885", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003885", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003885", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003885", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003885", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003885", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003885", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003885", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003885", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003885")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003886")
    void case_UTAPI_003886() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003886",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003886", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003886", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003886", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003886", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003886", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003886", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003886", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003886", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003886", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003886", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003886", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003886", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003886")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003887")
    void case_UTAPI_003887() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003887",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003887", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003887", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003887", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003887", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003887", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003887", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003887", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003887", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003887", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003887", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003887", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003887", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003887")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003888")
    void case_UTAPI_003888() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003888",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003888", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003888", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003888", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003888", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003888", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003888", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003888", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003888", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003888", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003888", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003888", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003888", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003888")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003889")
    void case_UTAPI_003889() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003889",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003889", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003889", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003889", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003889", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003889", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003889", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003889", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003889", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003889", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003889", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003889", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003889", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003889")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003890")
    void case_UTAPI_003890() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003890",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003890", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003890", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003890", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003890", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003890", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003890", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003890", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003890", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003890", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003890", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003890", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003890", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003890")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003891")
    void case_UTAPI_003891() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003891",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003891", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003891", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003891", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003891", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003891", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003891", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003891", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003891", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003891", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003891", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003891", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003891", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003891")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003892")
    void case_UTAPI_003892() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003892",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003892", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003892", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003892", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003892", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003892", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003892", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003892", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003892", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003892", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003892", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003892", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003892", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003892")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003893")
    void case_UTAPI_003893() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003893",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003893", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003893", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003893", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003893", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003893", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003893", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003893", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003893", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003893", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003893", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003893", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003893", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003893")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003894")
    void case_UTAPI_003894() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003894",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003894", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003894", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003894", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003894", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003894", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003894", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003894", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003894", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003894", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003894", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003894", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003894", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003894")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003895")
    void case_UTAPI_003895() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003895",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003895", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003895", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003895", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003895", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003895", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003895", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003895", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003895", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003895", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003895", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003895", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003895", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003895")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003896")
    void case_UTAPI_003896() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003896",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003896", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003896", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003896", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003896", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003896", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003896", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003896", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003896", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003896", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003896", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003896", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003896", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003896")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003897")
    void case_UTAPI_003897() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003897",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003897", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003897", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003897", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003897", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003897", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003897", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003897", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003897", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003897", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003897", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003897", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003897", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003897")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003898")
    void case_UTAPI_003898() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003898",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003898", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003898", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003898", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003898", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003898", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003898", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003898", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003898", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003898", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003898", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003898", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003898", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003898")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003899")
    void case_UTAPI_003899() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003899",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003899", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003899", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003899", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003899", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003899", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003899", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003899", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003899", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003899", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003899", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003899", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003899", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003899")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003900")
    void case_UTAPI_003900() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003900",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003900", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003900", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003900", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003900", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003900", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003900", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003900", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003900", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003900", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003900", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003900", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003900", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003900")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003901")
    void case_UTAPI_003901() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003901",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003901", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003901", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003901", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003901", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003901", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003901", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003901", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003901", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003901", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003901", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003901", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003901", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003901")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003902")
    void case_UTAPI_003902() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003902",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003902", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003902", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003902", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003902", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003902", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003902", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003902", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003902", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003902", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003902", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003902", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003902", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003902")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003903")
    void case_UTAPI_003903() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003903",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003903", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003903", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003903", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003903", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003903", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003903", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003903", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003903", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003903", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003903", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003903", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003903", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003903")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003904")
    void case_UTAPI_003904() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003904",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003904", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003904", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003904", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003904", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003904", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003904", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003904", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003904", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003904", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003904", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003904", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003904", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003904")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003905")
    void case_UTAPI_003905() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003905",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003905", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003905", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003905", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003905", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003905", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003905", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003905", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003905", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003905", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003905", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003905", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003905", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003905")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003906")
    void case_UTAPI_003906() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003906",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003906", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003906", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003906", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003906", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003906", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003906", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003906", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003906", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003906", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003906", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003906", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003906", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003906")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003907")
    void case_UTAPI_003907() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003907",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003907", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003907", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003907", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003907", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003907", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003907", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003907", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003907", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003907", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003907", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003907", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003907", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003907")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003908")
    void case_UTAPI_003908() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003908",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003908", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003908", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003908", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003908", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003908", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003908", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003908", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003908", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003908", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003908", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003908", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003908", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003908")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003909")
    void case_UTAPI_003909() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003909",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003909", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003909", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003909", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003909", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003909", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003909", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003909", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003909", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003909", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003909", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003909", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003909", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003909")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003910")
    void case_UTAPI_003910() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003910",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003910", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003910", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003910", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003910", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003910", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003910", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003910", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003910", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003910", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003910", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003910", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003910", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003910")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003911")
    void case_UTAPI_003911() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003911",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003911", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003911", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003911", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003911", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003911", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003911", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003911", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003911", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003911", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003911", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003911", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003911", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003911")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003912")
    void case_UTAPI_003912() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003912",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003912", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003912", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003912", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003912", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003912", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003912", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003912", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003912", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003912", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003912", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003912", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003912", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003912")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003913")
    void case_UTAPI_003913() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003913",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003913", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003913", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003913", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003913", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003913", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003913", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003913", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003913", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003913", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003913", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003913", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003913", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003913")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003914")
    void case_UTAPI_003914() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003914",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003914", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003914", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003914", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003914", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003914", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003914", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003914", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003914", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003914", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003914", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003914", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003914", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003914")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003915")
    void case_UTAPI_003915() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003915",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003915", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003915", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003915", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003915", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003915", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003915", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003915", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003915", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003915", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003915", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003915", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003915", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003915")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003916")
    void case_UTAPI_003916() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003916",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003916", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003916", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003916", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003916", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003916", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003916", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003916", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003916", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003916", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003916", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003916", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003916", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003916")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003917")
    void case_UTAPI_003917() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003917",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003917", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003917", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003917", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003917", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003917", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003917", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003917", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003917", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003917", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003917", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003917", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003917", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003917")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003918")
    void case_UTAPI_003918() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003918",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003918", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003918", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003918", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003918", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003918", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003918", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003918", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003918", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003918", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003918", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003918", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003918", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003918")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003919")
    void case_UTAPI_003919() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003919",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003919", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003919", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003919", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003919", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003919", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003919", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003919", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003919", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003919", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003919", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003919", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003919", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003919")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003920")
    void case_UTAPI_003920() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003920",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003920", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003920", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003920", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003920", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003920", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003920", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003920", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003920", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003920", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003920", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003920", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003920", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003920")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003921")
    void case_UTAPI_003921() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003921",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003921", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003921", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003921", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003921", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003921", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003921", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003921", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003921", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003921", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003921", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003921", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003921", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003921")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003922")
    void case_UTAPI_003922() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003922",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003922", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003922", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003922", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003922", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003922", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003922", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003922", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003922", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003922", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003922", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003922", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003922", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003922")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003923")
    void case_UTAPI_003923() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003923",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003923", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003923", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003923", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003923", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003923", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003923", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003923", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003923", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003923", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003923", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003923", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003923", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003923")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003924")
    void case_UTAPI_003924() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003924",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003924", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003924", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003924", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003924", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003924", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003924", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003924", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003924", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003924", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003924", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003924", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003924", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003924")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003925")
    void case_UTAPI_003925() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003925",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003925", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003925", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003925", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003925", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003925", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003925", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003925", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003925", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003925", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003925", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003925", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003925", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003925")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003926")
    void case_UTAPI_003926() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003926",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003926", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003926", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003926", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003926", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003926", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003926", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003926", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003926", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003926", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003926", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003926", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003926", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003926")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003927")
    void case_UTAPI_003927() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003927",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003927", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003927", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003927", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003927", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003927", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003927", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003927", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003927", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003927", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003927", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003927", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003927", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003927")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003928")
    void case_UTAPI_003928() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003928",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003928", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003928", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003928", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003928", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003928", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003928", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003928", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003928", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003928", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003928", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003928", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003928", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003928")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003929")
    void case_UTAPI_003929() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003929",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003929", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003929", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003929", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003929", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003929", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003929", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003929", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003929", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003929", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003929", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003929", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003929", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003929")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003930")
    void case_UTAPI_003930() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003930",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003930", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003930", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003930", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003930", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003930", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003930", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003930", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003930", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003930", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003930", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003930", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003930", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003930")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003931")
    void case_UTAPI_003931() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003931",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003931", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003931", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003931", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003931", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003931", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003931", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003931", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003931", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003931", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003931", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003931", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003931", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003931")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003932")
    void case_UTAPI_003932() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003932",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003932", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003932", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003932", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003932", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003932", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003932", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003932", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003932", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003932", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003932", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003932", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003932", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003932")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003933")
    void case_UTAPI_003933() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003933",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003933", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003933", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003933", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003933", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003933", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003933", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003933", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003933", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003933", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003933", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003933", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003933", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003933")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003934")
    void case_UTAPI_003934() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003934",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003934", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003934", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003934", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003934", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003934", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003934", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003934", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003934", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003934", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003934", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003934", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003934", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003934")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003935")
    void case_UTAPI_003935() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003935",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003935", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003935", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003935", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003935", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003935", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003935", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003935", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003935", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003935", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003935", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003935", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003935", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003935")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003936")
    void case_UTAPI_003936() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003936",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003936", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003936", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003936", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003936", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003936", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003936", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003936", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003936", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003936", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003936", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003936", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003936", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003936")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003937")
    void case_UTAPI_003937() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003937",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003937", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003937", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003937", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003937", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003937", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003937", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003937", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003937", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003937", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003937", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003937", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003937", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003937")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003938")
    void case_UTAPI_003938() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003938",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003938", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003938", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003938", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003938", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003938", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003938", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003938", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003938", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003938", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003938", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003938", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003938", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003938")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003939")
    void case_UTAPI_003939() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003939",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003939", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003939", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003939", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003939", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003939", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003939", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003939", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003939", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003939", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003939", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003939", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003939", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003939")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003940")
    void case_UTAPI_003940() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003940",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003940", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003940", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003940", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003940", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003940", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003940", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003940", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003940", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003940", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003940", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003940", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003940", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003940")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003941")
    void case_UTAPI_003941() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003941",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003941", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003941", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003941", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003941", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003941", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003941", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003941", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003941", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003941", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003941", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003941", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003941", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003941")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003942")
    void case_UTAPI_003942() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003942",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003942", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003942", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003942", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003942", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003942", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003942", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003942", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003942", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003942", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003942", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003942", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003942", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003942")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003943")
    void case_UTAPI_003943() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003943",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003943", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003943", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003943", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003943", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003943", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003943", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003943", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003943", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003943", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003943", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003943", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003943", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003943")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003944")
    void case_UTAPI_003944() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003944",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003944", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003944", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003944", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003944", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003944", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003944", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003944", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003944", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003944", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003944", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003944", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003944", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003944")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003945")
    void case_UTAPI_003945() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003945",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003945", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003945", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003945", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003945", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003945", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003945", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003945", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003945", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003945", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003945", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003945", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003945", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003945")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003946")
    void case_UTAPI_003946() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003946",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003946", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003946", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003946", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003946", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003946", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003946", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003946", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003946", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003946", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003946", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003946", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003946", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003946")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003947")
    void case_UTAPI_003947() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003947",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003947", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003947", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003947", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003947", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003947", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003947", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003947", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003947", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003947", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003947", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003947", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003947", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003947")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003948")
    void case_UTAPI_003948() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003948",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003948", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003948", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003948", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003948", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003948", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003948", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003948", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003948", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003948", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003948", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003948", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003948", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003948")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003949")
    void case_UTAPI_003949() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003949",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003949", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003949", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003949", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003949", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003949", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003949", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003949", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003949", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003949", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003949", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003949", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003949", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003949")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003950")
    void case_UTAPI_003950() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003950",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003950", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003950", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003950", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003950", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003950", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003950", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003950", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003950", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003950", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003950", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003950", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003950", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003950")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003951")
    void case_UTAPI_003951() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003951",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003951", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003951", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003951", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003951", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003951", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003951", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003951", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003951", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003951", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003951", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003951", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003951", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003951")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003952")
    void case_UTAPI_003952() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003952",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003952", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003952", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003952", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003952", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003952", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003952", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003952", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003952", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003952", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003952", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003952", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003952", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003952")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003953")
    void case_UTAPI_003953() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003953",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003953", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003953", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003953", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003953", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003953", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003953", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003953", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003953", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003953", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003953", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003953", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003953", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003953")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003954")
    void case_UTAPI_003954() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003954",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003954", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003954", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003954", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003954", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003954", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003954", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003954", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003954", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003954", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003954", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003954", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003954", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003954")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003955")
    void case_UTAPI_003955() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003955",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003955", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003955", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003955", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003955", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003955", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003955", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003955", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003955", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003955", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003955", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003955", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003955", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003955")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003956")
    void case_UTAPI_003956() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003956",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003956", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003956", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003956", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003956", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003956", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003956", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003956", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003956", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003956", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003956", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003956", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003956", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003956")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003957")
    void case_UTAPI_003957() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003957",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003957", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003957", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003957", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003957", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003957", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003957", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003957", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003957", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003957", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003957", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003957", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003957", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003957")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003958")
    void case_UTAPI_003958() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003958",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003958", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003958", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003958", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003958", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003958", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003958", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003958", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003958", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003958", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003958", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003958", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003958", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003958")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003959")
    void case_UTAPI_003959() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003959",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003959", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003959", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003959", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003959", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003959", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003959", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003959", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003959", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003959", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003959", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003959", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003959", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003959")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003960")
    void case_UTAPI_003960() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003960",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003960", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003960", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003960", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003960", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003960", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003960", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003960", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003960", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003960", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003960", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003960", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003960", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003960")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003961")
    void case_UTAPI_003961() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003961",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003961", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003961", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003961", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003961", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003961", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003961", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003961", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003961", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003961", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003961", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003961", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003961", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003961")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003962")
    void case_UTAPI_003962() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003962",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003962", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003962", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003962", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003962", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003962", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003962", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003962", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003962", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003962", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003962", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003962", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003962", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003962")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003963")
    void case_UTAPI_003963() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003963",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003963", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003963", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003963", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003963", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003963", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003963", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003963", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003963", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003963", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003963", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003963", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003963", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003963")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003964")
    void case_UTAPI_003964() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003964",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003964", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003964", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003964", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003964", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003964", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003964", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003964", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003964", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003964", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003964", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003964", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003964", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003964")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003965")
    void case_UTAPI_003965() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003965",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003965", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003965", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003965", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003965", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003965", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003965", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003965", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003965", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003965", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003965", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003965", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003965", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003965")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003966")
    void case_UTAPI_003966() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003966",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003966", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003966", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003966", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003966", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003966", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003966", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003966", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003966", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003966", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003966", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003966", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003966", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003966")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003967")
    void case_UTAPI_003967() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003967",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003967", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003967", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003967", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003967", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003967", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003967", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003967", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003967", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003967", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003967", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003967", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003967", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003967")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003968")
    void case_UTAPI_003968() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003968",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003968", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003968", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003968", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003968", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003968", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003968", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003968", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003968", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003968", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003968", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003968", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003968", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003968")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003969")
    void case_UTAPI_003969() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003969",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003969", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003969", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003969", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003969", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003969", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003969", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003969", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003969", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003969", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003969", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003969", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003969", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003969")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003970")
    void case_UTAPI_003970() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003970",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003970", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003970", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003970", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003970", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003970", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003970", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003970", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003970", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003970", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003970", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003970", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003970", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003970")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003971")
    void case_UTAPI_003971() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003971",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003971", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003971", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003971", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003971", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003971", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003971", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003971", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003971", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003971", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003971", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003971", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003971", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003971")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003972")
    void case_UTAPI_003972() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003972",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003972", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003972", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003972", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003972", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003972", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003972", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003972", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003972", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003972", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003972", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003972", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003972", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003972")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003973")
    void case_UTAPI_003973() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003973",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003973", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003973", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003973", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003973", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003973", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003973", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003973", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003973", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003973", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003973", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003973", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003973", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003973")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003974")
    void case_UTAPI_003974() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003974",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003974", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003974", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003974", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003974", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003974", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003974", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003974", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003974", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003974", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003974", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003974", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003974", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003974")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003975")
    void case_UTAPI_003975() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003975",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003975", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003975", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003975", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003975", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003975", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003975", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003975", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003975", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003975", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003975", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003975", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003975", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003975")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003976")
    void case_UTAPI_003976() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003976",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003976", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003976", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003976", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003976", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003976", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003976", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003976", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003976", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003976", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003976", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003976", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003976", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003976")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003977")
    void case_UTAPI_003977() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003977",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003977", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003977", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003977", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003977", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003977", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003977", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003977", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003977", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003977", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003977", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003977", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003977", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003977")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003978")
    void case_UTAPI_003978() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003978",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003978", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003978", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003978", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003978", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003978", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003978", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003978", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003978", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003978", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003978", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003978", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003978", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003978")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003979")
    void case_UTAPI_003979() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003979",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003979", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003979", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003979", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003979", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003979", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003979", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003979", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003979", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003979", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003979", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003979", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003979", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003979")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003980")
    void case_UTAPI_003980() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003980",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003980", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003980", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003980", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003980", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003980", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003980", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003980", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003980", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003980", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003980", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003980", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003980", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003980")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003981")
    void case_UTAPI_003981() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003981",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003981", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003981", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003981", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003981", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003981", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003981", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003981", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003981", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003981", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003981", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003981", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003981", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003981")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003982")
    void case_UTAPI_003982() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003982",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003982", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003982", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003982", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003982", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003982", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003982", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003982", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003982", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003982", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003982", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003982", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003982", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003982")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003983")
    void case_UTAPI_003983() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003983",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003983", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003983", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003983", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003983", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003983", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003983", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003983", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003983", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003983", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003983", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003983", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003983", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003983")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003984")
    void case_UTAPI_003984() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003984",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003984", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003984", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003984", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003984", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003984", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003984", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003984", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003984", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003984", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003984", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003984", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003984", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003984")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003985")
    void case_UTAPI_003985() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003985",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003985", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003985", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003985", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003985", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003985", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003985", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003985", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003985", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003985", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003985", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003985", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003985", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003985")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003986")
    void case_UTAPI_003986() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003986",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003986", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003986", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003986", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003986", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003986", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003986", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003986", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003986", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003986", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003986", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003986", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003986", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003986")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003987")
    void case_UTAPI_003987() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003987",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003987", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003987", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003987", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003987", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003987", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003987", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003987", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003987", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003987", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003987", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003987", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003987", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003987")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003988")
    void case_UTAPI_003988() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003988",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003988", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003988", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003988", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003988", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003988", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003988", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003988", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003988", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003988", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003988", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003988", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003988", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003988")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003989")
    void case_UTAPI_003989() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003989",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003989", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003989", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003989", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003989", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003989", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003989", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003989", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003989", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003989", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003989", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003989", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003989", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003989")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003990")
    void case_UTAPI_003990() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003990",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003990", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003990", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003990", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003990", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003990", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003990", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003990", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003990", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003990", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003990", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003990", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003990", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003990")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003991")
    void case_UTAPI_003991() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003991",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003991", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003991", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003991", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003991", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003991", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003991", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003991", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003991", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003991", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003991", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003991", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003991", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003991")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003992")
    void case_UTAPI_003992() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003992",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003992", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003992", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003992", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003992", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003992", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003992", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003992", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003992", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003992", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003992", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003992", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003992", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003992")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003993")
    void case_UTAPI_003993() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003993",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003993", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003993", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003993", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003993", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003993", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003993", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003993", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003993", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003993", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003993", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003993", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003993", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003993")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003994")
    void case_UTAPI_003994() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003994",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003994", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003994", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003994", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003994", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003994", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003994", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003994", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003994", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003994", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003994", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003994", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003994", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003994")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003995")
    void case_UTAPI_003995() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003995",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003995", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003995", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003995", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003995", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003995", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003995", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003995", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003995", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003995", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003995", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003995", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003995", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003995")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003996")
    void case_UTAPI_003996() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003996",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003996", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003996", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003996", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003996", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003996", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003996", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003996", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003996", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003996", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003996", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003996", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003996", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003996")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003997")
    void case_UTAPI_003997() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003997",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003997", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003997", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003997", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003997", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003997", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003997", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003997", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003997", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003997", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003997", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003997", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003997", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003997")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003998")
    void case_UTAPI_003998() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003998",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003998", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003998", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003998", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003998", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003998", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003998", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003998", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003998", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003998", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003998", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003998", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003998", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003998")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003999")
    void case_UTAPI_003999() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003999",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003999", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003999", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003999", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003999", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003999", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003999", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003999", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003999", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003999", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003999", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003999", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003999", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003999")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004000")
    void case_UTAPI_004000() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004000",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004000", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004000", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004000", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004000", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004000", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004000", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004000", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004000", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004000", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004000", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004000", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004000", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004000")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004001")
    void case_UTAPI_004001() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004001",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004001", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004001", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004001", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004001", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004001", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004001", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004001", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004001", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004001", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004001", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004001", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004001", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004001")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004002")
    void case_UTAPI_004002() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004002",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004002", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004002", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004002", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004002", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004002", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004002", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004002", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004002", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004002", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004002", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004002", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004002", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004002")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004003")
    void case_UTAPI_004003() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004003",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004003", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004003", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004003", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004003", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004003", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004003", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004003", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004003", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004003", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004003", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004003", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004003", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004003")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004004")
    void case_UTAPI_004004() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004004",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004004", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004004", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004004", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004004", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004004", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004004", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004004", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004004", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004004", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004004", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004004", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004004", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004004")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004005")
    void case_UTAPI_004005() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004005",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004005", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004005", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004005", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004005", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004005", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004005", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004005", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004005", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004005", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004005", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004005", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004005", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004005")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004006")
    void case_UTAPI_004006() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004006",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004006", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004006", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004006", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004006", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004006", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004006", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004006", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004006", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004006", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004006", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004006", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004006", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004006")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004007")
    void case_UTAPI_004007() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004007",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004007", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004007", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004007", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004007", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004007", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004007", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004007", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004007", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004007", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004007", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004007", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004007", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004007")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004008")
    void case_UTAPI_004008() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004008",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004008", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004008", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004008", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004008", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004008", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004008", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004008", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004008", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004008", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004008", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004008", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004008", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004008")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004009")
    void case_UTAPI_004009() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004009",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004009", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004009", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004009", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004009", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004009", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004009", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004009", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004009", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004009", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004009", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004009", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004009", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004009")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004010")
    void case_UTAPI_004010() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004010",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004010", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004010", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004010", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004010", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004010", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004010", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004010", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004010", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004010", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004010", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004010", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004010", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004010")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004011")
    void case_UTAPI_004011() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004011",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004011", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004011", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004011", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004011", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004011", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004011", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004011", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004011", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004011", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004011", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004011", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004011", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004011")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004012")
    void case_UTAPI_004012() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004012",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004012", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004012", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004012", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004012", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004012", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004012", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004012", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004012", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004012", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004012", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004012", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004012", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004012")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004013")
    void case_UTAPI_004013() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004013",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004013", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004013", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004013", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004013", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004013", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004013", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004013", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004013", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004013", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004013", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004013", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004013", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004013")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004014")
    void case_UTAPI_004014() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004014",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004014", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004014", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004014", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004014", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004014", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004014", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004014", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004014", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004014", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004014", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004014", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004014", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004014")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004015")
    void case_UTAPI_004015() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004015",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004015", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004015", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004015", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004015", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004015", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004015", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004015", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004015", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004015", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004015", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004015", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004015", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004015")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004016")
    void case_UTAPI_004016() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004016",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004016", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004016", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004016", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004016", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004016", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004016", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004016", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004016", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004016", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004016", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004016", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004016", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004016")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004017")
    void case_UTAPI_004017() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004017",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004017", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004017", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004017", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004017", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004017", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004017", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004017", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004017", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004017", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004017", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004017", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004017", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004017")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004018")
    void case_UTAPI_004018() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004018",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004018", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004018", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004018", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004018", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004018", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004018", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004018", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004018", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004018", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004018", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004018", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004018", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004018")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004019")
    void case_UTAPI_004019() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004019",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004019", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004019", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004019", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004019", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004019", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004019", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004019", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004019", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004019", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004019", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004019", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004019", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004019")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004020")
    void case_UTAPI_004020() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004020",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004020", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004020", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004020", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004020", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004020", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004020", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004020", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004020", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004020", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004020", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004020", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004020", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004020")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004021")
    void case_UTAPI_004021() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004021",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004021", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004021", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004021", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004021", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004021", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004021", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004021", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004021", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004021", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004021", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004021", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004021", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004021")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004022")
    void case_UTAPI_004022() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004022",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004022", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004022", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004022", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004022", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004022", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004022", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004022", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004022", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004022", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004022", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004022", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004022", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004022")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004023")
    void case_UTAPI_004023() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004023",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004023", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004023", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004023", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004023", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004023", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004023", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004023", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004023", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004023", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004023", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004023", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004023", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004023")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004024")
    void case_UTAPI_004024() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004024",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004024", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004024", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004024", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004024", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004024", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004024", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004024", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004024", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004024", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004024", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004024", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004024", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004024")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004025")
    void case_UTAPI_004025() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004025",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004025", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004025", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004025", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004025", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004025", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004025", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004025", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004025", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004025", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004025", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004025", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004025", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004025")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004026")
    void case_UTAPI_004026() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004026",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004026", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004026", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004026", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004026", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004026", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004026", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004026", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004026", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004026", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004026", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004026", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004026", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004026")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004027")
    void case_UTAPI_004027() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004027",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004027", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004027", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004027", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004027", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004027", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004027", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004027", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004027", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004027", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004027", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004027", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004027", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004027")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004028")
    void case_UTAPI_004028() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004028",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004028", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004028", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004028", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004028", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004028", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004028", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004028", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004028", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004028", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004028", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004028", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004028", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004028")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004029")
    void case_UTAPI_004029() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004029",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004029", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004029", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004029", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004029", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004029", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004029", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004029", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004029", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004029", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004029", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004029", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004029", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004029")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004030")
    void case_UTAPI_004030() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004030",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004030", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004030", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004030", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004030", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004030", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004030", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004030", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004030", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004030", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004030", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004030", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004030", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004030")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004031")
    void case_UTAPI_004031() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004031",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004031", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004031", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004031", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004031", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004031", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004031", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004031", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004031", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004031", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004031", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004031", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004031", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004031")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004032")
    void case_UTAPI_004032() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004032",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004032", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004032", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004032", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004032", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004032", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004032", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004032", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004032", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004032", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004032", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004032", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004032", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004032")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004033")
    void case_UTAPI_004033() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004033",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004033", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004033", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004033", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004033", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004033", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004033", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004033", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004033", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004033", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004033", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004033", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004033", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004033")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004034")
    void case_UTAPI_004034() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004034",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004034", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004034", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004034", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004034", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004034", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004034", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004034", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004034", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004034", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004034", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004034", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004034", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004034")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004035")
    void case_UTAPI_004035() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004035",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004035", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004035", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004035", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004035", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004035", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004035", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004035", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004035", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004035", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004035", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004035", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004035", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004035")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004036")
    void case_UTAPI_004036() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004036",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004036", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004036", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004036", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004036", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004036", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004036", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004036", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004036", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004036", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004036", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004036", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004036", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004036")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004037")
    void case_UTAPI_004037() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004037",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004037", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004037", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004037", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004037", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004037", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004037", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004037", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004037", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004037", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004037", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004037", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004037", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004037")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004038")
    void case_UTAPI_004038() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004038",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004038", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004038", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004038", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004038", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004038", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004038", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004038", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004038", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004038", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004038", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004038", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004038", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004038")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004039")
    void case_UTAPI_004039() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004039",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004039", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004039", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004039", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004039", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004039", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004039", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004039", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004039", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004039", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004039", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004039", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004039", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004039")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004040")
    void case_UTAPI_004040() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004040",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004040", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004040", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004040", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004040", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004040", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004040", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004040", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004040", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004040", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004040", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004040", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004040", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004040")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004041")
    void case_UTAPI_004041() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004041",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004041", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004041", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004041", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004041", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004041", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004041", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004041", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004041", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004041", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004041", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004041", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004041", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004041")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004042")
    void case_UTAPI_004042() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004042",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004042", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004042", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004042", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004042", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004042", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004042", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004042", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004042", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004042", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004042", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004042", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004042", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004042")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004043")
    void case_UTAPI_004043() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004043",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004043", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004043", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004043", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004043", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004043", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004043", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004043", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004043", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004043", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004043", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004043", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004043", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004043")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004044")
    void case_UTAPI_004044() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004044",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004044", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004044", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004044", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004044", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004044", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004044", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004044", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004044", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004044", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004044", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004044", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004044", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004044")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004045")
    void case_UTAPI_004045() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004045",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004045", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004045", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004045", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004045", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004045", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004045", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004045", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004045", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004045", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004045", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004045", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004045", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004045")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004046")
    void case_UTAPI_004046() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004046",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004046", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004046", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004046", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004046", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004046", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004046", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004046", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004046", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004046", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004046", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004046", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004046", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004046")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004047")
    void case_UTAPI_004047() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004047",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004047", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004047", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004047", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004047", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004047", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004047", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004047", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004047", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004047", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004047", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004047", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004047", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004047")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004048")
    void case_UTAPI_004048() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004048",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004048", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004048", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004048", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004048", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004048", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004048", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004048", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004048", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004048", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004048", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004048", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004048", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004048")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004049")
    void case_UTAPI_004049() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004049",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004049", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004049", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004049", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004049", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004049", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004049", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004049", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004049", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004049", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004049", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004049", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004049", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004049")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004050")
    void case_UTAPI_004050() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004050",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004050", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004050", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004050", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004050", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004050", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004050", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004050", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004050", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004050", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004050", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004050", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004050", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004050")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004051")
    void case_UTAPI_004051() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004051",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004051", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004051", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004051", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004051", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004051", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004051", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004051", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004051", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004051", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004051", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004051", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004051", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004051")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004052")
    void case_UTAPI_004052() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004052",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004052", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004052", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004052", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004052", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004052", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004052", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004052", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004052", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004052", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004052", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004052", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004052", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004052")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004053")
    void case_UTAPI_004053() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004053",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004053", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004053", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004053", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004053", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004053", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004053", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004053", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004053", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004053", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004053", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004053", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004053", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004053")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004054")
    void case_UTAPI_004054() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004054",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004054", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004054", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004054", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004054", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004054", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004054", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004054", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004054", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004054", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004054", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004054", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004054", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004054")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004055")
    void case_UTAPI_004055() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004055",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004055", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004055", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004055", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004055", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004055", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004055", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004055", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004055", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004055", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004055", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004055", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004055", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004055")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004056")
    void case_UTAPI_004056() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004056",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004056", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004056", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004056", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004056", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004056", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004056", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004056", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004056", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004056", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004056", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004056", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004056", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004056")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004057")
    void case_UTAPI_004057() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004057",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004057", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004057", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004057", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004057", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004057", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004057", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004057", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004057", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004057", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004057", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004057", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004057", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004057")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004058")
    void case_UTAPI_004058() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004058",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004058", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004058", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004058", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004058", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004058", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004058", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004058", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004058", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004058", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004058", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004058", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004058", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004058")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004059")
    void case_UTAPI_004059() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004059",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004059", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004059", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004059", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004059", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004059", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004059", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004059", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004059", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004059", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004059", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004059", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004059", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004059")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004060")
    void case_UTAPI_004060() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004060",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004060", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004060", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004060", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004060", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004060", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004060", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004060", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004060", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004060", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004060", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004060", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004060", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004060")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004061")
    void case_UTAPI_004061() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004061",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004061", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004061", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004061", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004061", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004061", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004061", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004061", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004061", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004061", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004061", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004061", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004061", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004061")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004062")
    void case_UTAPI_004062() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004062",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004062", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004062", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004062", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004062", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004062", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004062", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004062", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004062", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004062", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004062", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004062", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004062", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004062")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004063")
    void case_UTAPI_004063() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004063",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004063", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004063", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004063", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004063", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004063", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004063", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004063", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004063", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004063", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004063", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004063", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004063", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004063")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004064")
    void case_UTAPI_004064() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004064",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004064", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004064", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004064", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004064", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004064", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004064", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004064", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004064", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004064", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004064", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004064", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004064", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004064")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryList::4::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

}

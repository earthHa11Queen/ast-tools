package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ImportControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ImportController#getExcelSheets.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ImportControllerGetExcelSheetsScenario {

    @Test
    @DisplayName("UTAPI-000802")
    void case_UTAPI_000802() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000802",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "getExcelSheets",
                "ResponseEntity<List<String>>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000802", "file", "TARGET", "OBJECT", "MultipartFile")
                },
                OraclePlan.builder("UTAPI-000802")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::getExcelSheets::2::ARG::1::-::file")
                    .mirror("-", "1:length_null", "-")
                    .target("file", "file")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.getExcelSheetNames")
                    .expected("the value generated for file is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_REQUIRED, "an absent upload cannot be processed", "java.lang.RuntimeException", "data:file")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000803")
    void case_UTAPI_000803() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000803",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "getExcelSheets",
                "ResponseEntity<List<String>>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000803", "file", "TARGET", "OBJECT", "MultipartFile")
                },
                OraclePlan.builder("UTAPI-000803")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::getExcelSheets::2::ARG::1::-::file")
                    .mirror("-", "2:length_empty", "-")
                    .target("file", "file")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.getExcelSheetNames")
                    .expected("the value generated for file is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.getExcelSheetNames", "importUseCase", "getExcelSheetNames")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.getExcelSheetNames must carry the value generated for file", "importUseCase", "getExcelSheetNames", "0", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SAME, "the uploaded document must be handed on as it was received", "importUseCase", "getExcelSheetNames", "0", "data:file")
                    .build()),
            new ImportControllerWrapper());
    }

}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableRecordRepositoryWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableRecordRepository#findStaleTables.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableRecordRepositoryFindStaleTablesScenario {

    @Test
    @DisplayName("UTAPI-009760")
    void case_UTAPI_009760() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009760",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009760", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009760", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009760", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009760", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009760", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009760", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009760", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009760", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009760", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009760", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009760", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009760")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009761")
    void case_UTAPI_009761() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009761",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009761", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009761", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009761", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009761", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009761", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009761", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009761", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009761", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009761", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009761", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009761", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009761")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009762")
    void case_UTAPI_009762() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009762",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009762", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009762", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009762", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009762", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009762", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009762", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009762", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009762", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009762", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009762", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009762", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009762")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009763")
    void case_UTAPI_009763() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009763",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009763", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009763", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009763", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009763", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009763", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009763", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009763", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009763", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009763", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009763", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009763", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009763")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009764")
    void case_UTAPI_009764() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009764",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009764", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009764", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009764", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009764", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009764", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009764", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009764", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009764", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009764", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009764", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009764", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009764")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009765")
    void case_UTAPI_009765() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009765",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009765", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009765", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009765", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009765", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009765", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009765", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009765", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009765", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009765", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009765", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009765", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009765")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009766")
    void case_UTAPI_009766() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009766",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009766", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009766", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009766", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009766", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009766", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009766", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009766", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009766", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009766", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009766", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009766", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009766")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009767")
    void case_UTAPI_009767() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009767",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009767", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009767", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009767", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009767", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009767", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009767", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009767", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009767", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009767", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009767", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009767", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009767")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009768")
    void case_UTAPI_009768() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009768",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009768", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009768", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009768", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009768", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009768", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009768", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009768", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009768", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009768", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009768", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009768", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009768")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009769")
    void case_UTAPI_009769() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009769",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009769", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009769", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009769", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009769", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009769", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009769", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009769", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009769", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009769", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009769", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009769", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009769")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009770")
    void case_UTAPI_009770() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009770",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009770", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009770", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009770", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009770", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009770", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009770", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009770", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009770", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009770", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009770", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009770", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009770")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009771")
    void case_UTAPI_009771() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009771",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009771", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009771", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009771", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009771", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009771", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009771", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009771", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009771", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009771", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009771", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009771", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009771")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009772")
    void case_UTAPI_009772() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009772",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009772", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009772", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009772", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009772", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009772", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009772", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009772", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009772", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009772", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009772", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009772", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009772")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009773")
    void case_UTAPI_009773() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009773",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009773", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009773", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009773", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009773", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009773", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009773", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009773", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009773", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009773", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009773", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009773", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009773")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009774")
    void case_UTAPI_009774() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009774",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009774", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009774", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009774", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009774", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009774", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009774", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009774", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009774", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009774", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009774", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009774", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009774")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009775")
    void case_UTAPI_009775() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009775",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009775", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009775", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009775", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009775", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009775", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009775", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009775", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009775", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009775", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009775", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009775", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009775")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009776")
    void case_UTAPI_009776() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009776",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009776", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009776", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009776", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009776", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009776", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009776", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009776", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009776", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009776", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009776", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009776", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009776")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009777")
    void case_UTAPI_009777() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009777",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009777", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009777", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009777", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009777", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009777", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009777", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009777", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009777", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009777", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009777", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009777", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009777")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009778")
    void case_UTAPI_009778() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009778",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009778", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009778", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009778", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009778", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009778", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009778", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009778", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009778", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009778", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009778", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009778", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009778")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009779")
    void case_UTAPI_009779() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009779",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009779", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009779", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009779", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009779", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009779", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009779", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009779", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009779", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009779", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009779", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009779", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009779")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009780")
    void case_UTAPI_009780() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009780",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009780", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009780", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009780", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009780", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009780", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009780", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009780", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009780", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009780", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009780", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009780", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009780")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009781")
    void case_UTAPI_009781() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009781",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009781", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009781", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009781", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009781", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009781", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009781", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009781", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009781", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009781", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009781", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009781", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009781")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009782")
    void case_UTAPI_009782() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009782",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009782", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009782", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009782", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009782", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009782", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009782", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009782", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009782", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009782", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009782", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009782", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009782")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009783")
    void case_UTAPI_009783() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009783",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009783", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009783", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009783", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009783", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009783", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009783", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009783", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009783", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009783", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009783", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009783", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009783")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009784")
    void case_UTAPI_009784() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009784",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009784", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009784", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009784", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009784", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009784", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009784", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009784", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009784", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009784", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009784", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009784", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009784")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009785")
    void case_UTAPI_009785() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009785",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009785", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009785", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009785", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009785", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009785", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009785", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009785", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009785", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009785", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009785", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009785", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009785")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009786")
    void case_UTAPI_009786() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009786",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009786", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009786", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009786", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009786", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009786", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009786", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009786", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009786", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009786", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009786", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009786", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009786")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009787")
    void case_UTAPI_009787() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009787",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009787", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009787", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009787", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009787", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009787", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009787", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009787", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009787", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009787", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009787", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009787", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009787")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009788")
    void case_UTAPI_009788() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009788",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009788", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009788", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009788", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009788", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009788", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009788", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009788", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009788", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009788", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009788", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009788", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009788")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009789")
    void case_UTAPI_009789() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009789",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009789", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009789", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009789", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009789", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009789", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009789", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009789", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009789", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009789", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009789", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009789", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009789")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009790")
    void case_UTAPI_009790() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009790",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009790", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009790", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009790", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009790", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009790", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009790", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009790", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009790", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009790", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009790", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009790", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009790")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009791")
    void case_UTAPI_009791() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009791",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009791", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009791", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009791", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009791", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009791", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009791", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009791", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009791", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009791", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009791", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009791", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009791")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009792")
    void case_UTAPI_009792() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009792",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009792", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009792", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009792", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009792", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009792", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009792", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009792", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009792", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009792", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009792", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009792", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009792")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009793")
    void case_UTAPI_009793() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009793",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009793", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009793", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009793", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009793", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009793", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009793", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009793", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009793", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009793", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009793", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009793", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009793")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009794")
    void case_UTAPI_009794() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009794",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009794", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009794", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009794", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009794", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009794", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009794", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009794", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009794", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009794", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009794", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009794", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009794")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009795")
    void case_UTAPI_009795() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009795",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009795", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009795", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009795", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009795", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009795", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009795", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009795", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009795", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009795", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009795", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009795", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009795")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009796")
    void case_UTAPI_009796() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009796",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009796", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009796", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009796", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009796", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009796", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009796", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009796", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009796", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009796", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009796", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009796", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009796")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009797")
    void case_UTAPI_009797() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009797",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009797", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009797", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009797", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009797", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009797", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009797", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009797", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009797", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009797", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009797", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009797", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009797")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009798")
    void case_UTAPI_009798() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009798",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009798", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009798", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009798", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009798", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009798", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009798", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009798", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009798", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009798", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009798", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009798", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009798")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009799")
    void case_UTAPI_009799() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009799",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009799", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009799", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009799", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009799", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009799", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009799", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009799", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009799", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009799", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009799", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009799", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009799")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009800")
    void case_UTAPI_009800() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009800",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009800", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009800", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009800", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009800", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009800", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009800", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009800", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009800", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009800", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009800", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009800", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009800")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009801")
    void case_UTAPI_009801() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009801",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009801", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009801", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009801", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009801", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009801", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009801", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009801", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009801", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009801", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009801", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009801", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009801")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009802")
    void case_UTAPI_009802() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009802",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009802", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009802", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009802", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009802", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009802", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009802", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009802", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009802", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009802", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009802", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009802", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009802")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009803")
    void case_UTAPI_009803() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009803",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009803", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009803", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009803", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009803", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009803", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009803", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009803", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009803", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009803", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009803", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009803", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009803")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009804")
    void case_UTAPI_009804() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009804",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009804", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009804", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009804", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009804", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009804", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009804", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009804", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009804", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009804", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009804", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009804", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009804")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009805")
    void case_UTAPI_009805() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009805",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009805", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009805", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009805", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009805", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009805", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009805", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009805", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009805", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009805", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009805", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009805", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009805")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009806")
    void case_UTAPI_009806() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009806",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009806", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009806", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009806", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009806", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009806", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009806", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009806", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009806", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009806", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009806", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009806", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009806")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009807")
    void case_UTAPI_009807() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009807",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009807", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009807", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009807", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009807", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009807", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009807", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009807", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009807", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009807", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009807", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009807", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009807")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009808")
    void case_UTAPI_009808() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009808",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009808", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009808", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009808", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009808", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009808", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009808", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009808", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009808", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009808", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009808", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009808", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009808")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009809")
    void case_UTAPI_009809() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009809",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009809", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009809", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009809", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009809", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009809", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009809", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009809", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009809", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009809", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009809", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009809", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009809")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009810")
    void case_UTAPI_009810() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009810",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009810", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009810", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009810", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009810", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009810", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009810", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009810", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009810", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009810", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009810", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009810", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009810")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009811")
    void case_UTAPI_009811() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009811",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009811", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009811", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009811", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009811", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009811", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009811", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009811", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009811", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009811", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009811", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009811", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009811")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009812")
    void case_UTAPI_009812() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009812",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009812", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009812", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009812", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009812", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009812", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009812", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009812", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009812", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009812", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009812", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009812", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009812")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009813")
    void case_UTAPI_009813() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009813",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009813", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009813", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009813", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009813", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009813", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009813", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009813", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009813", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009813", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009813", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009813", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009813")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009814")
    void case_UTAPI_009814() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009814",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009814", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009814", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009814", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009814", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009814", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009814", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009814", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009814", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009814", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009814", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009814", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009814")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009815")
    void case_UTAPI_009815() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009815",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009815", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009815", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009815", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009815", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009815", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009815", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009815", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009815", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009815", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009815", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009815", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009815")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009816")
    void case_UTAPI_009816() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009816",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009816", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009816", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009816", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009816", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009816", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009816", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009816", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009816", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009816", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009816", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009816", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009816")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009817")
    void case_UTAPI_009817() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009817",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009817", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009817", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009817", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009817", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009817", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009817", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009817", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009817", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009817", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009817", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009817", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009817")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009818")
    void case_UTAPI_009818() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009818",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009818", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009818", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009818", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009818", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009818", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009818", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009818", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009818", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009818", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009818", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009818", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009818")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009819")
    void case_UTAPI_009819() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009819",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009819", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009819", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009819", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009819", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009819", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009819", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009819", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009819", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009819", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009819", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009819", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009819")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009820")
    void case_UTAPI_009820() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009820",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009820", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009820", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009820", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009820", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009820", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009820", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009820", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009820", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009820", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009820", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009820", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009820")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009821")
    void case_UTAPI_009821() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009821",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009821", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009821", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009821", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009821", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009821", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009821", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009821", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009821", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009821", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009821", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009821", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009821")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009822")
    void case_UTAPI_009822() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009822",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009822", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009822", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009822", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009822", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009822", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009822", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009822", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009822", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009822", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009822", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009822", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009822")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009823")
    void case_UTAPI_009823() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009823",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009823", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009823", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009823", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009823", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009823", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009823", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009823", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009823", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009823", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009823", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009823", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009823")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009824")
    void case_UTAPI_009824() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009824",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009824", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009824", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009824", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009824", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009824", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009824", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009824", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009824", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009824", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009824", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009824", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009824")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009825")
    void case_UTAPI_009825() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009825",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009825", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009825", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009825", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009825", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009825", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009825", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009825", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009825", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009825", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009825", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009825", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009825")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009826")
    void case_UTAPI_009826() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009826",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009826", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009826", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009826", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009826", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009826", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009826", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009826", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009826", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009826", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009826", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009826", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009826")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009827")
    void case_UTAPI_009827() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009827",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009827", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009827", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009827", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009827", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009827", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009827", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009827", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009827", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009827", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009827", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009827", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009827")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009828")
    void case_UTAPI_009828() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009828",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009828", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009828", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009828", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009828", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009828", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009828", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009828", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009828", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009828", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009828", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009828", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009828")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009829")
    void case_UTAPI_009829() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009829",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009829", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009829", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009829", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009829", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009829", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009829", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009829", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009829", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009829", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009829", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009829", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009829")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009830")
    void case_UTAPI_009830() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009830",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009830", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009830", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009830", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009830", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009830", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009830", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009830", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009830", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009830", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009830", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009830", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009830")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009831")
    void case_UTAPI_009831() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009831",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009831", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009831", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009831", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009831", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009831", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009831", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009831", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009831", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009831", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009831", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009831", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009831")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009832")
    void case_UTAPI_009832() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009832",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009832", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009832", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009832", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009832", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009832", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009832", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009832", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009832", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009832", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009832", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009832", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009832")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009833")
    void case_UTAPI_009833() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009833",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009833", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009833", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009833", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009833", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009833", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009833", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009833", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009833", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009833", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009833", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009833", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009833")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009834")
    void case_UTAPI_009834() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009834",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009834", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009834", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009834", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009834", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009834", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009834", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009834", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009834", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009834", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009834", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009834", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009834")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009835")
    void case_UTAPI_009835() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009835",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009835", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009835", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009835", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009835", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009835", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009835", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009835", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009835", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009835", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009835", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009835", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009835")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009836")
    void case_UTAPI_009836() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009836",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009836", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009836", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009836", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009836", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009836", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009836", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009836", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009836", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009836", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009836", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009836", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009836")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009837")
    void case_UTAPI_009837() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009837",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009837", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009837", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009837", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009837", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009837", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009837", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009837", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009837", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009837", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009837", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009837", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009837")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009838")
    void case_UTAPI_009838() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009838",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009838", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009838", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009838", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009838", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009838", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009838", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009838", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009838", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009838", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009838", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009838", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009838")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009839")
    void case_UTAPI_009839() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009839",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009839", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009839", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009839", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009839", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009839", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009839", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009839", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009839", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009839", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009839", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009839", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009839")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009840")
    void case_UTAPI_009840() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009840",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009840", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009840", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009840", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009840", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009840", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009840", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009840", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009840", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009840", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009840", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009840", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009840")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009841")
    void case_UTAPI_009841() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009841",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009841", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009841", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009841", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009841", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009841", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009841", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009841", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009841", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009841", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009841", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009841", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009841")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009842")
    void case_UTAPI_009842() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009842",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009842", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009842", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009842", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009842", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009842", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009842", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009842", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009842", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009842", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009842", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009842", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009842")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009843")
    void case_UTAPI_009843() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009843",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009843", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009843", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009843", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009843", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009843", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009843", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009843", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009843", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009843", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009843", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009843", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009843")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009844")
    void case_UTAPI_009844() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009844",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009844", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009844", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009844", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009844", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009844", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009844", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009844", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009844", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009844", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009844", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009844", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009844")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009845")
    void case_UTAPI_009845() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009845",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009845", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009845", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009845", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009845", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009845", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009845", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009845", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009845", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009845", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009845", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009845", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009845")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009846")
    void case_UTAPI_009846() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009846",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009846", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009846", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009846", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009846", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009846", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009846", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009846", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009846", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009846", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009846", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009846", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009846")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009847")
    void case_UTAPI_009847() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009847",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009847", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009847", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009847", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009847", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009847", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009847", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009847", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009847", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009847", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009847", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009847", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009847")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009848")
    void case_UTAPI_009848() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009848",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009848", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009848", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009848", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009848", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009848", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009848", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009848", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009848", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009848", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009848", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009848", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009848")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009849")
    void case_UTAPI_009849() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009849",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009849", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009849", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009849", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009849", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009849", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009849", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009849", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009849", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009849", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009849", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009849", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009849")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009850")
    void case_UTAPI_009850() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009850",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009850", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009850", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009850", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009850", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009850", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009850", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009850", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009850", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009850", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009850", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009850", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009850")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009851")
    void case_UTAPI_009851() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009851",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009851", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009851", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009851", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009851", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009851", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009851", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009851", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009851", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009851", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009851", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009851", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009851")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009852")
    void case_UTAPI_009852() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009852",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009852", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009852", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009852", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009852", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009852", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009852", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009852", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009852", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009852", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009852", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009852", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009852")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009853")
    void case_UTAPI_009853() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009853",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009853", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009853", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009853", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009853", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009853", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009853", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009853", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009853", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009853", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009853", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009853", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009853")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009854")
    void case_UTAPI_009854() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009854",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009854", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009854", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009854", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009854", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009854", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009854", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009854", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009854", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009854", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009854", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009854", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009854")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009855")
    void case_UTAPI_009855() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009855",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009855", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009855", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009855", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009855", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009855", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009855", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009855", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009855", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009855", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009855", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009855", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009855")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009856")
    void case_UTAPI_009856() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009856",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009856", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009856", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009856", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009856", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009856", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009856", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009856", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009856", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009856", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009856", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009856", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009856")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009857")
    void case_UTAPI_009857() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009857",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009857", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009857", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009857", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009857", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009857", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009857", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009857", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009857", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009857", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009857", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009857", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009857")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009858")
    void case_UTAPI_009858() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009858",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009858", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009858", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009858", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009858", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009858", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009858", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009858", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009858", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009858", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009858", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009858", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009858")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009859")
    void case_UTAPI_009859() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009859",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009859", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009859", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009859", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009859", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009859", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009859", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009859", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009859", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009859", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009859", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009859", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009859")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009860")
    void case_UTAPI_009860() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009860",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009860", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009860", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009860", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009860", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009860", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009860", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009860", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009860", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009860", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009860", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009860", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009860")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009861")
    void case_UTAPI_009861() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009861",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009861", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009861", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009861", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009861", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009861", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009861", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009861", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009861", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009861", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009861", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009861", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009861")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009862")
    void case_UTAPI_009862() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009862",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009862", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009862", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009862", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009862", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009862", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009862", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009862", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009862", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009862", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009862", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009862", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009862")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009863")
    void case_UTAPI_009863() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009863",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009863", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009863", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009863", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009863", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009863", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009863", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009863", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009863", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009863", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009863", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009863", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009863")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009864")
    void case_UTAPI_009864() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009864",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009864", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009864", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009864", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009864", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009864", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009864", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009864", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009864", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009864", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009864", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009864", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009864")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009865")
    void case_UTAPI_009865() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009865",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009865", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009865", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009865", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009865", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009865", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009865", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009865", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009865", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009865", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009865", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009865", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009865")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009866")
    void case_UTAPI_009866() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009866",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009866", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009866", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009866", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009866", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009866", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009866", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009866", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009866", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009866", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009866", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009866", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009866")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009867")
    void case_UTAPI_009867() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009867",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009867", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009867", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009867", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009867", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009867", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009867", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009867", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009867", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009867", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009867", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009867", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009867")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009868")
    void case_UTAPI_009868() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009868",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009868", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009868", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009868", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009868", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009868", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009868", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009868", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009868", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009868", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009868", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009868", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009868")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009869")
    void case_UTAPI_009869() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009869",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009869", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009869", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009869", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009869", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009869", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009869", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009869", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009869", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009869", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009869", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009869", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009869")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009870")
    void case_UTAPI_009870() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009870",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009870", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009870", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009870", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009870", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009870", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009870", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009870", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009870", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009870", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009870", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009870", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009870")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009871")
    void case_UTAPI_009871() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009871",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009871", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009871", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009871", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009871", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009871", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009871", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009871", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009871", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009871", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009871", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009871", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009871")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009872")
    void case_UTAPI_009872() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009872",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009872", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009872", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009872", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009872", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009872", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009872", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009872", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009872", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009872", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009872", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009872", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009872")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009873")
    void case_UTAPI_009873() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009873",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009873", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009873", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009873", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009873", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009873", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009873", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009873", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009873", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009873", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009873", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009873", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009873")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009874")
    void case_UTAPI_009874() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009874",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009874", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009874", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009874", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009874", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009874", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009874", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009874", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009874", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009874", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009874", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009874", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009874")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009875")
    void case_UTAPI_009875() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009875",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009875", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009875", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009875", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009875", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009875", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009875", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009875", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009875", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009875", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009875", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009875", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009875")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009876")
    void case_UTAPI_009876() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009876",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009876", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009876", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009876", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009876", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009876", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009876", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009876", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009876", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009876", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009876", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009876", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009876")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009877")
    void case_UTAPI_009877() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009877",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009877", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009877", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009877", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009877", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009877", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009877", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009877", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009877", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009877", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009877", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009877", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009877")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009878")
    void case_UTAPI_009878() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009878",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009878", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009878", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009878", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009878", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009878", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009878", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009878", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009878", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009878", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009878", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009878", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009878")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009879")
    void case_UTAPI_009879() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009879",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009879", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009879", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009879", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009879", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009879", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009879", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009879", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009879", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009879", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009879", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009879", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009879")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009880")
    void case_UTAPI_009880() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009880",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009880", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009880", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009880", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009880", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009880", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009880", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009880", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009880", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009880", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009880", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009880", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009880")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009881")
    void case_UTAPI_009881() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009881",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009881", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009881", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009881", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009881", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009881", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009881", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009881", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009881", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009881", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009881", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009881", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009881")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009882")
    void case_UTAPI_009882() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009882",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009882", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009882", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009882", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009882", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009882", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009882", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009882", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009882", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009882", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009882", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009882", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009882")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009883")
    void case_UTAPI_009883() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009883",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009883", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009883", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009883", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009883", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009883", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009883", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009883", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009883", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009883", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009883", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009883", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009883")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009884")
    void case_UTAPI_009884() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009884",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009884", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009884", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009884", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009884", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009884", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009884", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009884", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009884", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009884", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009884", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009884", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009884")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009885")
    void case_UTAPI_009885() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009885",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009885", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009885", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009885", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009885", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009885", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009885", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009885", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009885", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009885", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009885", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009885", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009885")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009886")
    void case_UTAPI_009886() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009886",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009886", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009886", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009886", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009886", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009886", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009886", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009886", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009886", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009886", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009886", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009886", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009886")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009887")
    void case_UTAPI_009887() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009887",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009887", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009887", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009887", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009887", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009887", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009887", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009887", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009887", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009887", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009887", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009887", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009887")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009888")
    void case_UTAPI_009888() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009888",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009888", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009888", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009888", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009888", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009888", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009888", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009888", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009888", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009888", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009888", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009888", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009888")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009889")
    void case_UTAPI_009889() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009889",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009889", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009889", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009889", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009889", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009889", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009889", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009889", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009889", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009889", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009889", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009889", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009889")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009890")
    void case_UTAPI_009890() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009890",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009890", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009890", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009890", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009890", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009890", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009890", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009890", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009890", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009890", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009890", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009890", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009890")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009891")
    void case_UTAPI_009891() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009891",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009891", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009891", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009891", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009891", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009891", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009891", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009891", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009891", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009891", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009891", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009891", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009891")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009892")
    void case_UTAPI_009892() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009892",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009892", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009892", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009892", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009892", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009892", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009892", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009892", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009892", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009892", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009892", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009892", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009892")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009893")
    void case_UTAPI_009893() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009893",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009893", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009893", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009893", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009893", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009893", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009893", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009893", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009893", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009893", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009893", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009893", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009893")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009894")
    void case_UTAPI_009894() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009894",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009894", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009894", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009894", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009894", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009894", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009894", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009894", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009894", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009894", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009894", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009894", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009894")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009895")
    void case_UTAPI_009895() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009895",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009895", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009895", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009895", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009895", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009895", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009895", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009895", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009895", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009895", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009895", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009895", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009895")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009896")
    void case_UTAPI_009896() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009896",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009896", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009896", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009896", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009896", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009896", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009896", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009896", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009896", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009896", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009896", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009896", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009896")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009897")
    void case_UTAPI_009897() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009897",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009897", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009897", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009897", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009897", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009897", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009897", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009897", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009897", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009897", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009897", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009897", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009897")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009898")
    void case_UTAPI_009898() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009898",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009898", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009898", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009898", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009898", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009898", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009898", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009898", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009898", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009898", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009898", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009898", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009898")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009899")
    void case_UTAPI_009899() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009899",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009899", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009899", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009899", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009899", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009899", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009899", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009899", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009899", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009899", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009899", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009899", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009899")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009900")
    void case_UTAPI_009900() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009900",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009900", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009900", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009900", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009900", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009900", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009900", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009900", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009900", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009900", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009900", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009900", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009900")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009901")
    void case_UTAPI_009901() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009901",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009901", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009901", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009901", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009901", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009901", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009901", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009901", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009901", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009901", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009901", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009901", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009901")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009902")
    void case_UTAPI_009902() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009902",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009902", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009902", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009902", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009902", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009902", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009902", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009902", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009902", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009902", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009902", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009902", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009902")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009903")
    void case_UTAPI_009903() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009903",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009903", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009903", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009903", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009903", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009903", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009903", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009903", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009903", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009903", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009903", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009903", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009903")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009904")
    void case_UTAPI_009904() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009904",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009904", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009904", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009904", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009904", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009904", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009904", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009904", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009904", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009904", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009904", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009904", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009904")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009905")
    void case_UTAPI_009905() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009905",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009905", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009905", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009905", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009905", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009905", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009905", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009905", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009905", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009905", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009905", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009905", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009905")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009906")
    void case_UTAPI_009906() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009906",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009906", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009906", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009906", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009906", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009906", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009906", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009906", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009906", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009906", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009906", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009906", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009906")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009907")
    void case_UTAPI_009907() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009907",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009907", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009907", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009907", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009907", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009907", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009907", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009907", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009907", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009907", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009907", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009907", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009907")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009908")
    void case_UTAPI_009908() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009908",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009908", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009908", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009908", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009908", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009908", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009908", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009908", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009908", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009908", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009908", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009908", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009908")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009909")
    void case_UTAPI_009909() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009909",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009909", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009909", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009909", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009909", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009909", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009909", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009909", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009909", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009909", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009909", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009909", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009909")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009910")
    void case_UTAPI_009910() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009910",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009910", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009910", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009910", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009910", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009910", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009910", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009910", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009910", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009910", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009910", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009910", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009910")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009911")
    void case_UTAPI_009911() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009911",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009911", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009911", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009911", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009911", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009911", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009911", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009911", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009911", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009911", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009911", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009911", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009911")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009912")
    void case_UTAPI_009912() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009912",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009912", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009912", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009912", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009912", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009912", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009912", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009912", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009912", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009912", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009912", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009912", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009912")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009913")
    void case_UTAPI_009913() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009913",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009913", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009913", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009913", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009913", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009913", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009913", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009913", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009913", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009913", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009913", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009913", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009913")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009914")
    void case_UTAPI_009914() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009914",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009914", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009914", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009914", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009914", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009914", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009914", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009914", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009914", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009914", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009914", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009914", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009914")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009915")
    void case_UTAPI_009915() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009915",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009915", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009915", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009915", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009915", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009915", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009915", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009915", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009915", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009915", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009915", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009915", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009915")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009916")
    void case_UTAPI_009916() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009916",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009916", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009916", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009916", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009916", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009916", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009916", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009916", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009916", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009916", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009916", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009916", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009916")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009917")
    void case_UTAPI_009917() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009917",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009917", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009917", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009917", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009917", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009917", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009917", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009917", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009917", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009917", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009917", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009917", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009917")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009918")
    void case_UTAPI_009918() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009918",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009918", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009918", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009918", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009918", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009918", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009918", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009918", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009918", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009918", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009918", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009918", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009918")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009919")
    void case_UTAPI_009919() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009919",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009919", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009919", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009919", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009919", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009919", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009919", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009919", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009919", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009919", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009919", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009919", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009919")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009920")
    void case_UTAPI_009920() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009920",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009920", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009920", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009920", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009920", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009920", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009920", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009920", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009920", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009920", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009920", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009920", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009920")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009921")
    void case_UTAPI_009921() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009921",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009921", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009921", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009921", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009921", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009921", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009921", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009921", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009921", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009921", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009921", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009921", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009921")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

}

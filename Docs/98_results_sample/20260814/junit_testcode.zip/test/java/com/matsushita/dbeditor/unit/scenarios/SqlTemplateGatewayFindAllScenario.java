package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.SqlTemplateGatewayWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for SqlTemplateGateway#findAll.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class SqlTemplateGatewayFindAllScenario {

    @Test
    @DisplayName("UTAPI-003055")
    void case_UTAPI_003055() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003055",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "findAll",
                "List<SqlTemplate>",
                new ParamSpec[] {},
                new DataRef[] {},
                OraclePlan.builder("UTAPI-003055")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::findAll::1::METHOD::-1::-::-")
                    .mirror("-", "-", "-")
                    .target("-", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for - is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the listing must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.MemoResponseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for MemoResponse#fromEntity.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class MemoResponseFromEntityScenario {

    @Test
    @DisplayName("UTAPI-010285")
    void case_UTAPI_010285() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010285",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010285", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010285", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010285", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010285", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010285", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010285", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010285", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010285")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "1:length_null", "-")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010286")
    void case_UTAPI_010286() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010286",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010286", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010286", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010286", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010286", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010286", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010286", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010286", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010286")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "2:length_empty", "-")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010287")
    void case_UTAPI_010287() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010287",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010287", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010287", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010287", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010287", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010287", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010287", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010287", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010287")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "3:length_min", "-")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010288")
    void case_UTAPI_010288() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010288",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010288", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010288", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010288", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010288", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010288", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010288", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010288", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010288")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010289")
    void case_UTAPI_010289() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010289",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010289", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010289", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010289", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010289", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010289", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010289", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010289", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010289")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "5:length_max", "-")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010290")
    void case_UTAPI_010290() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010290",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010290", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010290", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010290", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010290", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010290", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010290", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010290", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010290")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010291")
    void case_UTAPI_010291() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010291",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010291", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010291", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010291", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010291", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010291", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010291", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010291", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010291")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010292")
    void case_UTAPI_010292() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010292",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010292", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010292", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010292", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010292", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010292", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010292", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010292", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010292")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::contentMemo")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010293")
    void case_UTAPI_010293() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010293",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010293", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010293", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010293", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010293", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010293", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010293", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010293", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010293")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::contentMemo")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010294")
    void case_UTAPI_010294() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010294",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010294", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010294", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010294", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010294", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010294", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010294", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010294", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010294")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::contentMemo")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010295")
    void case_UTAPI_010295() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010295",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010295", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010295", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010295", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010295", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010295", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010295", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010295", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010295")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010296")
    void case_UTAPI_010296() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010296",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010296", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010296", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010296", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010296", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010296", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010296", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010296", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010296")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010297")
    void case_UTAPI_010297() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010297",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010297", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010297", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010297", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010297", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010297", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010297", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010297", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010297")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "-", "56:space")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010298")
    void case_UTAPI_010298() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010298",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010298", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010298", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010298", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010298", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010298", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010298", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010298", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010298")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010299")
    void case_UTAPI_010299() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010299",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010299", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010299", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010299", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010299", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010299", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010299", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010299", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010299")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010300")
    void case_UTAPI_010300() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010300",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010300", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010300", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010300", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010300", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010300", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010300", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010300", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010300")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "-", "59:tab")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010301")
    void case_UTAPI_010301() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010301",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010301", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010301", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010301", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010301", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010301", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010301", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010301", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010301")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "-", "60:control_character_null")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010302")
    void case_UTAPI_010302() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010302",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010302", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010302", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010302", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010302", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010302", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010302", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010302", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010302")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010303")
    void case_UTAPI_010303() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010303",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010303", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010303", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010303", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010303", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010303", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010303", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010303", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010303")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010304")
    void case_UTAPI_010304() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010304",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010304", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010304", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010304", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010304", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010304", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010304", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010304", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010304")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010305")
    void case_UTAPI_010305() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010305",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010305", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010305", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010305", "memo.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010305", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010305", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010305", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010305", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010305")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("memo.createdTimestamp", "TableMemo.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010306")
    void case_UTAPI_010306() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010306",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010306", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010306", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010306", "memo.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010306", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010306", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010306", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010306", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010306")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("memo.createdTimestamp", "TableMemo.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010307")
    void case_UTAPI_010307() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010307",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010307", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010307", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010307", "memo.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010307", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010307", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010307", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010307", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010307")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("memo.createdTimestamp", "TableMemo.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010308")
    void case_UTAPI_010308() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010308",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010308", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010308", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010308", "memo.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010308", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010308", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010308", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010308", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010308")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("memo.createdTimestamp", "TableMemo.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010309")
    void case_UTAPI_010309() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010309",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010309", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010309", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010309", "memo.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010309", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010309", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010309", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010309", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010309")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("memo.createdTimestamp", "TableMemo.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010310")
    void case_UTAPI_010310() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010310",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010310", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010310", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010310", "memo.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010310", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010310", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010310", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010310", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010310")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("memo.createdTimestamp", "TableMemo.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010311")
    void case_UTAPI_010311() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010311",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010311", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010311", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010311", "memo.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010311", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010311", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010311", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010311", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010311")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("memo.createdTimestamp", "TableMemo.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010312")
    void case_UTAPI_010312() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010312",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010312", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010312", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010312", "memo.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010312", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010312", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010312", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010312", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010312")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("memo.createdTimestamp", "TableMemo.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010313")
    void case_UTAPI_010313() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010313",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010313", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010313", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010313", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010313", "memo.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010313", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010313", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010313", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010313")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::dbConnectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("memo.dbConnectionId", "TableMemo.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.dbConnectionId survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010314")
    void case_UTAPI_010314() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010314",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010314", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010314", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010314", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010314", "memo.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010314", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010314", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010314", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010314")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::dbConnectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("memo.dbConnectionId", "TableMemo.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.dbConnectionId survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010315")
    void case_UTAPI_010315() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010315",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010315", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010315", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010315", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010315", "memo.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010315", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010315", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010315", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010315")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::dbConnectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("memo.dbConnectionId", "TableMemo.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.dbConnectionId survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010316")
    void case_UTAPI_010316() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010316",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010316", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010316", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010316", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010316", "memo.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010316", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010316", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010316", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010316")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::dbConnectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("memo.dbConnectionId", "TableMemo.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.dbConnectionId survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010317")
    void case_UTAPI_010317() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010317",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010317", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010317", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010317", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010317", "memo.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010317", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010317", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010317", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010317")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::dbConnectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("memo.dbConnectionId", "TableMemo.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.dbConnectionId survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010318")
    void case_UTAPI_010318() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010318",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010318", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010318", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010318", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010318", "memo.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010318", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010318", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010318", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010318")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::dbConnectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("memo.dbConnectionId", "TableMemo.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.dbConnectionId survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010319")
    void case_UTAPI_010319() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010319",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010319", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010319", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010319", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010319", "memo.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010319", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010319", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010319", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010319")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::dbConnectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("memo.dbConnectionId", "TableMemo.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.dbConnectionId survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010320")
    void case_UTAPI_010320() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010320",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010320", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010320", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010320", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010320", "memo.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010320", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010320", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010320", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010320")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::dbConnectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("memo.dbConnectionId", "TableMemo.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.dbConnectionId survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010321")
    void case_UTAPI_010321() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010321",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010321", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010321", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010321", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010321", "memo.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010321", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010321", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010321", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010321")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::dbConnectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("memo.dbConnectionId", "TableMemo.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.dbConnectionId survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010322")
    void case_UTAPI_010322() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010322",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010322", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010322", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010322", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010322", "memo.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010322", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010322", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010322", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010322")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::dbConnectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("memo.dbConnectionId", "TableMemo.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.dbConnectionId survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010323")
    void case_UTAPI_010323() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010323",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010323", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010323", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010323", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010323", "memo.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010323", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010323", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010323", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010323")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::dbConnectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("memo.dbConnectionId", "TableMemo.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.dbConnectionId survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010324")
    void case_UTAPI_010324() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010324",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010324", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010324", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010324", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010324", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010324", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010324", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010324", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010324")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "1:length_null", "-")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.dbTableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010325")
    void case_UTAPI_010325() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010325",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010325", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010325", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010325", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010325", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010325", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010325", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010325", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010325")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.dbTableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010326")
    void case_UTAPI_010326() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010326",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010326", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010326", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010326", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010326", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010326", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010326", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010326", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010326")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "3:length_min", "-")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.dbTableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010327")
    void case_UTAPI_010327() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010327",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010327", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010327", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010327", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010327", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010327", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010327", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010327", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010327")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.dbTableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010328")
    void case_UTAPI_010328() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010328",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010328", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010328", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010328", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010328", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010328", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010328", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010328", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010328")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "5:length_max", "-")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.dbTableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010329")
    void case_UTAPI_010329() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010329",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010329", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010329", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010329", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010329", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010329", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010329", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010329", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010329")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.dbTableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010330")
    void case_UTAPI_010330() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010330",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010330", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010330", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010330", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010330", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010330", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010330", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010330", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010330")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.dbTableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010331")
    void case_UTAPI_010331() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010331",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010331", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010331", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010331", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010331", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010331", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010331", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010331", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010331")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::dbTableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.dbTableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010332")
    void case_UTAPI_010332() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010332",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010332", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010332", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010332", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010332", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010332", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010332", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010332", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010332")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::dbTableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.dbTableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010333")
    void case_UTAPI_010333() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010333",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010333", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010333", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010333", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010333", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010333", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010333", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010333", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010333")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::dbTableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.dbTableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010334")
    void case_UTAPI_010334() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010334",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010334", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010334", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010334", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010334", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010334", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010334", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010334", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010334")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::dbTableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.dbTableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010335")
    void case_UTAPI_010335() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010335",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010335", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010335", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010335", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010335", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010335", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010335", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010335", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010335")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.dbTableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010336")
    void case_UTAPI_010336() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010336",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010336", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010336", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010336", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010336", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010336", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010336", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010336", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010336")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.dbTableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010337")
    void case_UTAPI_010337() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010337",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010337", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010337", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010337", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010337", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010337", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010337", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010337", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010337")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "-", "56:space")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.dbTableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010338")
    void case_UTAPI_010338() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010338",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010338", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010338", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010338", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010338", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010338", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010338", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010338", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010338")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.dbTableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010339")
    void case_UTAPI_010339() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010339",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010339", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010339", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010339", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010339", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010339", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010339", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010339", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010339")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.dbTableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010340")
    void case_UTAPI_010340() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010340",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010340", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010340", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010340", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010340", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010340", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010340", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010340", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010340")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "-", "59:tab")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.dbTableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010341")
    void case_UTAPI_010341() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010341",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010341", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010341", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010341", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010341", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010341", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010341", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010341", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010341")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.dbTableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010342")
    void case_UTAPI_010342() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010342",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010342", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010342", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010342", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010342", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010342", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010342", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010342", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010342")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.dbTableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010343")
    void case_UTAPI_010343() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010343",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010343", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010343", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010343", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010343", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010343", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010343", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010343", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010343")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.dbTableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010344")
    void case_UTAPI_010344() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010344",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010344", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010344", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010344", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010344", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010344", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010344", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010344", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010344")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.dbTableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010345")
    void case_UTAPI_010345() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010345",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010345", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010345", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010345", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010345", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010345", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010345", "memo.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010345", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010345")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::n")
                    .mirror("-", "1:length_null", "-")
                    .target("memo.n", "TableMemo.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose n", "getN")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010346")
    void case_UTAPI_010346() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010346",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010346", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010346", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010346", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010346", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010346", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010346", "memo.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010346", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010346")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("memo.n", "TableMemo.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose n", "getN")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010347")
    void case_UTAPI_010347() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010347",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010347", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010347", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010347", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010347", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010347", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010347", "memo.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010347", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010347")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::n")
                    .mirror("-", "3:length_min", "-")
                    .target("memo.n", "TableMemo.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose n", "getN")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010348")
    void case_UTAPI_010348() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010348",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010348", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010348", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010348", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010348", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010348", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010348", "memo.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010348", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010348")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("memo.n", "TableMemo.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose n", "getN")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010349")
    void case_UTAPI_010349() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010349",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010349", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010349", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010349", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010349", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010349", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010349", "memo.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010349", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010349")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::n")
                    .mirror("-", "5:length_max", "-")
                    .target("memo.n", "TableMemo.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose n", "getN")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010350")
    void case_UTAPI_010350() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010350",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010350", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010350", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010350", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010350", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010350", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010350", "memo.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010350", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010350")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("memo.n", "TableMemo.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose n", "getN")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010351")
    void case_UTAPI_010351() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010351",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010351", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010351", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010351", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010351", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010351", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010351", "memo.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010351", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010351")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("memo.n", "TableMemo.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose n", "getN")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010352")
    void case_UTAPI_010352() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010352",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010352", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010352", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010352", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010352", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010352", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010352", "memo.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010352", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010352")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("memo.n", "TableMemo.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose n", "getN")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010353")
    void case_UTAPI_010353() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010353",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010353", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010353", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010353", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010353", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010353", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010353", "memo.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010353", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010353")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("memo.n", "TableMemo.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose n", "getN")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010354")
    void case_UTAPI_010354() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010354",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010354", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010354", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010354", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010354", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010354", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010354", "memo.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010354", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010354")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("memo.n", "TableMemo.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose n", "getN")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010355")
    void case_UTAPI_010355() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010355",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010355", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010355", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010355", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010355", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010355", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010355", "memo.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010355", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010355")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("memo.n", "TableMemo.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose n", "getN")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010356")
    void case_UTAPI_010356() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010356",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010356", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010356", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010356", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010356", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010356", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010356", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010356", "memo.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010356")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("memo.updatedTimestamp", "TableMemo.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.updatedTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose updatedTimestamp", "getUpdatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010357")
    void case_UTAPI_010357() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010357",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010357", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010357", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010357", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010357", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010357", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010357", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010357", "memo.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010357")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("memo.updatedTimestamp", "TableMemo.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.updatedTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose updatedTimestamp", "getUpdatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010358")
    void case_UTAPI_010358() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010358",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010358", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010358", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010358", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010358", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010358", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010358", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010358", "memo.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010358")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("memo.updatedTimestamp", "TableMemo.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.updatedTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose updatedTimestamp", "getUpdatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010359")
    void case_UTAPI_010359() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010359",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010359", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010359", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010359", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010359", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010359", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010359", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010359", "memo.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010359")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("memo.updatedTimestamp", "TableMemo.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.updatedTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose updatedTimestamp", "getUpdatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010360")
    void case_UTAPI_010360() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010360",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010360", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010360", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010360", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010360", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010360", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010360", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010360", "memo.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010360")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("memo.updatedTimestamp", "TableMemo.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.updatedTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose updatedTimestamp", "getUpdatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010361")
    void case_UTAPI_010361() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010361",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010361", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010361", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010361", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010361", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010361", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010361", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010361", "memo.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010361")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("memo.updatedTimestamp", "TableMemo.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.updatedTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose updatedTimestamp", "getUpdatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010362")
    void case_UTAPI_010362() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010362",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010362", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010362", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010362", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010362", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010362", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010362", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010362", "memo.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010362")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("memo.updatedTimestamp", "TableMemo.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.updatedTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose updatedTimestamp", "getUpdatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010363")
    void case_UTAPI_010363() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010363",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "fromEntity",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010363", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-010363", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010363", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010363", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010363", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010363", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010363", "memo.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010363")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::fromEntity::1::FIELD::1::TableMemo::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("memo.updatedTimestamp", "TableMemo.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by MemoResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for memo.updatedTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry memo.dbConnectionId", "getConnectionId", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry memo.dbTableName", "getTableName", "data:memo.dbTableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry memo.contentMemo", "getContent", "data:memo.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose updatedTimestamp", "getUpdatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableRecordGatewayWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableRecordGateway#createCopyTable.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableRecordGatewayCreateCopyTableScenario {

    @Test
    @DisplayName("UTAPI-004939")
    void case_UTAPI_004939() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004939",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004939", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004939", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004939", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004939", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004939", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004939", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004939", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004939", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004939", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004939", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004939", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004939", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004939")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004940")
    void case_UTAPI_004940() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004940",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004940", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004940", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004940", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004940", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004940", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004940", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004940", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004940", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004940", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004940", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004940", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004940", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004940")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004941")
    void case_UTAPI_004941() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004941",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004941", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004941", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004941", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004941", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004941", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004941", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004941", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004941", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004941", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004941", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004941", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004941", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004941")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004942")
    void case_UTAPI_004942() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004942",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004942", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004942", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004942", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004942", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004942", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004942", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004942", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004942", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004942", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004942", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004942", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004942", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004942")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004943")
    void case_UTAPI_004943() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004943",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004943", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004943", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004943", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004943", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004943", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004943", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004943", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004943", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004943", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004943", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004943", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004943", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004943")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004944")
    void case_UTAPI_004944() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004944",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004944", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004944", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004944", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004944", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004944", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004944", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004944", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004944", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004944", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004944", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004944", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004944", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004944")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004945")
    void case_UTAPI_004945() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004945",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004945", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004945", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004945", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004945", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004945", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004945", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004945", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004945", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004945", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004945", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004945", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004945", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004945")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004946")
    void case_UTAPI_004946() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004946",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004946", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004946", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004946", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004946", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004946", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004946", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004946", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004946", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004946", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004946", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004946", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004946", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004946")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004947")
    void case_UTAPI_004947() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004947",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004947", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004947", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004947", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004947", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004947", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004947", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004947", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004947", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004947", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004947", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004947", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004947", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004947")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004948")
    void case_UTAPI_004948() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004948",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004948", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004948", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004948", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004948", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004948", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004948", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004948", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004948", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004948", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004948", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004948", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004948", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004948")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004949")
    void case_UTAPI_004949() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004949",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004949", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004949", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004949", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004949", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004949", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004949", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004949", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004949", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004949", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004949", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004949", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004949", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004949")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004950")
    void case_UTAPI_004950() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004950",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004950", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004950", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004950", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004950", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004950", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004950", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004950", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004950", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004950", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004950", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004950", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004950", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004950")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004951")
    void case_UTAPI_004951() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004951",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004951", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004951", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004951", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004951", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004951", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004951", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004951", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004951", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004951", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004951", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004951", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004951", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004951")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004952")
    void case_UTAPI_004952() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004952",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004952", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004952", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004952", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004952", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004952", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004952", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004952", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004952", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004952", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004952", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004952", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004952", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004952")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004953")
    void case_UTAPI_004953() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004953",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004953", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004953", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004953", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004953", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004953", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004953", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004953", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004953", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004953", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004953", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004953", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004953", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004953")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004954")
    void case_UTAPI_004954() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004954",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004954", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004954", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004954", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004954", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004954", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004954", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004954", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004954", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004954", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004954", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004954", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004954", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004954")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004955")
    void case_UTAPI_004955() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004955",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004955", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004955", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004955", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004955", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004955", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004955", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004955", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004955", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004955", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004955", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004955", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004955", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004955")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004956")
    void case_UTAPI_004956() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004956",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004956", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004956", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004956", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004956", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004956", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004956", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004956", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004956", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004956", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004956", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004956", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004956", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004956")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004957")
    void case_UTAPI_004957() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004957",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004957", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004957", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004957", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004957", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004957", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004957", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004957", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004957", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004957", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004957", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004957", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004957", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004957")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004958")
    void case_UTAPI_004958() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004958",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004958", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004958", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004958", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004958", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004958", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004958", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004958", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004958", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004958", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004958", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004958", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004958", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004958")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004959")
    void case_UTAPI_004959() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004959",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004959", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004959", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004959", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004959", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004959", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004959", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004959", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004959", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004959", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004959", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004959", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004959", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004959")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004960")
    void case_UTAPI_004960() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004960",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004960", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004960", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004960", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004960", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004960", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004960", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004960", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004960", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004960", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004960", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004960", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004960", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004960")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004961")
    void case_UTAPI_004961() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004961",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004961", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004961", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004961", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004961", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004961", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004961", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004961", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004961", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004961", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004961", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004961", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004961", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004961")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004962")
    void case_UTAPI_004962() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004962",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004962", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004962", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004962", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004962", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004962", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004962", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004962", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004962", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004962", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004962", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004962", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004962", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004962")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004963")
    void case_UTAPI_004963() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004963",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004963", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004963", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004963", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004963", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004963", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004963", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004963", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004963", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004963", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004963", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004963", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004963", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004963")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004964")
    void case_UTAPI_004964() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004964",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004964", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004964", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004964", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004964", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004964", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004964", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004964", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004964", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004964", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004964", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004964", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004964", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004964")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004965")
    void case_UTAPI_004965() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004965",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004965", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004965", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004965", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004965", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004965", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004965", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004965", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004965", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004965", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004965", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004965", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004965", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004965")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004966")
    void case_UTAPI_004966() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004966",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004966", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004966", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004966", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004966", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004966", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004966", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004966", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004966", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004966", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004966", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004966", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004966", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004966")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004967")
    void case_UTAPI_004967() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004967",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004967", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004967", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004967", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004967", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004967", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004967", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004967", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004967", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004967", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004967", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004967", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004967", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004967")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004968")
    void case_UTAPI_004968() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004968",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004968", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004968", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004968", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004968", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004968", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004968", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004968", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004968", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004968", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004968", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004968", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004968", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004968")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004969")
    void case_UTAPI_004969() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004969",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004969", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004969", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004969", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004969", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004969", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004969", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004969", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004969", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004969", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004969", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004969", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004969", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004969")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004970")
    void case_UTAPI_004970() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004970",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004970", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004970", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004970", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004970", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004970", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004970", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004970", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004970", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004970", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004970", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004970", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004970", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004970")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004971")
    void case_UTAPI_004971() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004971",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004971", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004971", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004971", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004971", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004971", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004971", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004971", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004971", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004971", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004971", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004971", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004971", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004971")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004972")
    void case_UTAPI_004972() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004972",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004972", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004972", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004972", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004972", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004972", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004972", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004972", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004972", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004972", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004972", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004972", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004972", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004972")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004973")
    void case_UTAPI_004973() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004973",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004973", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004973", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004973", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004973", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004973", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004973", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004973", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004973", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004973", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004973", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004973", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004973", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004973")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004974")
    void case_UTAPI_004974() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004974",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004974", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004974", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004974", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004974", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004974", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004974", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004974", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004974", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004974", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004974", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004974", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004974", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004974")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004975")
    void case_UTAPI_004975() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004975",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004975", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004975", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004975", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004975", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004975", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004975", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004975", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004975", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004975", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004975", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004975", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004975", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004975")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004976")
    void case_UTAPI_004976() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004976",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004976", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004976", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004976", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004976", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004976", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004976", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004976", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004976", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004976", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004976", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004976", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004976", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004976")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004977")
    void case_UTAPI_004977() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004977",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004977", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004977", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004977", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004977", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004977", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004977", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004977", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004977", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004977", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004977", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004977", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004977", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004977")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004978")
    void case_UTAPI_004978() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004978",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004978", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004978", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004978", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004978", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004978", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004978", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004978", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004978", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004978", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004978", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004978", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004978", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004978")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004979")
    void case_UTAPI_004979() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004979",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004979", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004979", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004979", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004979", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004979", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004979", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004979", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004979", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004979", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004979", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004979", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004979", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004979")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004980")
    void case_UTAPI_004980() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004980",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004980", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004980", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004980", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004980", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004980", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004980", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004980", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004980", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004980", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004980", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004980", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004980", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004980")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004981")
    void case_UTAPI_004981() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004981",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004981", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004981", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004981", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004981", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004981", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004981", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004981", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004981", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004981", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004981", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004981", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004981", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004981")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004982")
    void case_UTAPI_004982() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004982",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004982", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004982", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004982", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004982", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004982", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004982", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004982", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004982", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004982", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004982", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004982", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004982", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004982")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004983")
    void case_UTAPI_004983() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004983",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004983", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004983", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004983", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004983", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004983", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004983", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004983", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004983", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004983", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004983", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004983", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004983", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004983")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004984")
    void case_UTAPI_004984() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004984",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004984", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004984", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004984", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004984", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004984", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004984", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004984", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004984", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004984", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004984", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004984", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004984", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004984")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004985")
    void case_UTAPI_004985() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004985",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004985", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004985", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004985", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004985", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004985", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004985", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004985", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004985", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004985", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004985", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004985", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004985", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004985")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004986")
    void case_UTAPI_004986() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004986",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004986", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004986", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004986", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004986", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004986", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004986", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004986", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004986", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004986", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004986", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004986", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004986", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004986")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004987")
    void case_UTAPI_004987() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004987",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004987", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004987", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004987", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004987", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004987", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004987", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004987", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004987", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004987", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004987", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004987", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004987", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004987")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004988")
    void case_UTAPI_004988() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004988",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004988", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004988", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004988", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004988", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004988", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004988", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004988", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004988", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004988", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004988", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004988", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004988", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004988")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004989")
    void case_UTAPI_004989() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004989",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004989", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004989", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004989", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004989", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004989", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004989", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004989", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004989", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004989", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004989", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004989", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004989", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004989")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004990")
    void case_UTAPI_004990() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004990",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004990", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004990", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004990", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004990", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004990", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004990", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004990", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004990", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004990", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004990", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004990", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004990", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004990")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004991")
    void case_UTAPI_004991() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004991",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004991", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004991", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004991", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004991", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004991", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004991", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004991", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004991", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004991", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004991", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004991", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004991", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004991")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004992")
    void case_UTAPI_004992() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004992",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004992", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004992", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004992", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004992", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004992", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004992", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004992", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004992", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004992", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004992", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004992", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004992", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004992")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004993")
    void case_UTAPI_004993() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004993",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004993", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004993", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004993", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004993", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004993", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004993", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004993", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004993", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004993", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004993", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004993", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004993", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004993")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004994")
    void case_UTAPI_004994() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004994",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004994", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004994", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004994", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004994", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004994", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004994", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004994", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004994", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004994", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004994", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004994", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004994", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004994")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004995")
    void case_UTAPI_004995() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004995",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004995", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004995", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004995", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004995", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004995", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004995", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004995", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004995", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004995", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004995", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004995", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004995", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004995")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004996")
    void case_UTAPI_004996() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004996",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004996", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004996", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004996", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004996", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004996", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004996", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004996", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004996", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004996", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004996", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004996", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004996", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004996")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004997")
    void case_UTAPI_004997() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004997",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004997", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004997", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004997", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004997", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004997", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004997", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004997", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004997", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004997", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004997", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004997", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004997", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004997")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004998")
    void case_UTAPI_004998() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004998",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004998", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004998", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004998", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004998", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004998", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004998", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004998", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004998", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004998", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004998", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004998", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004998", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004998")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004999")
    void case_UTAPI_004999() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004999",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004999", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004999", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004999", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004999", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004999", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004999", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004999", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004999", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004999", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004999", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004999", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004999", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004999")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005000")
    void case_UTAPI_005000() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005000",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005000", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005000", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005000", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005000", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005000", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005000", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005000", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005000", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005000", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005000", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005000", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005000", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005000")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005001")
    void case_UTAPI_005001() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005001",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005001", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005001", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005001", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005001", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005001", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005001", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005001", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005001", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005001", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005001", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005001", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005001", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005001")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005002")
    void case_UTAPI_005002() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005002",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005002", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005002", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005002", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005002", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005002", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005002", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005002", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005002", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005002", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005002", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005002", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005002", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005002")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005003")
    void case_UTAPI_005003() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005003",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005003", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005003", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005003", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005003", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005003", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005003", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005003", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005003", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005003", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005003", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005003", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005003", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005003")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005004")
    void case_UTAPI_005004() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005004",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005004", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005004", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005004", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005004", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005004", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005004", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005004", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005004", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005004", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005004", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005004", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005004", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005004")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005005")
    void case_UTAPI_005005() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005005",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005005", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005005", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005005", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005005", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005005", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005005", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005005", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005005", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005005", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005005", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005005", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005005", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005005")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005006")
    void case_UTAPI_005006() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005006",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005006", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005006", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005006", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005006", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005006", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005006", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005006", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005006", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005006", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005006", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005006", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005006", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005006")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005007")
    void case_UTAPI_005007() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005007",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005007", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005007", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005007", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005007", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005007", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005007", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005007", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005007", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005007", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005007", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005007", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005007", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005007")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005008")
    void case_UTAPI_005008() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005008",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005008", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005008", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005008", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005008", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005008", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005008", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005008", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005008", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005008", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005008", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005008", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005008", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005008")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005009")
    void case_UTAPI_005009() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005009",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005009", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005009", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005009", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005009", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005009", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005009", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005009", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005009", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005009", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005009", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005009", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005009", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005009")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005010")
    void case_UTAPI_005010() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005010",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005010", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005010", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005010", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005010", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005010", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005010", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005010", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005010", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005010", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005010", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005010", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005010", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005010")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005011")
    void case_UTAPI_005011() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005011",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005011", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005011", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005011", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005011", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005011", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005011", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005011", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005011", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005011", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005011", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005011", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005011", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005011")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005012")
    void case_UTAPI_005012() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005012",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005012", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005012", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005012", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005012", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005012", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005012", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005012", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005012", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005012", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005012", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005012", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005012", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005012")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005013")
    void case_UTAPI_005013() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005013",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005013", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005013", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005013", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005013", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005013", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005013", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005013", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005013", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005013", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005013", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005013", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005013", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005013")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005014")
    void case_UTAPI_005014() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005014",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005014", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005014", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005014", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005014", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005014", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005014", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005014", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005014", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005014", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005014", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005014", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005014", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005014")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005015")
    void case_UTAPI_005015() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005015",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005015", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005015", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005015", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005015", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005015", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005015", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005015", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005015", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005015", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005015", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005015", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005015", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005015")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005016")
    void case_UTAPI_005016() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005016",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005016", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005016", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005016", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005016", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005016", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005016", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005016", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005016", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005016", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005016", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005016", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005016", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005016")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005017")
    void case_UTAPI_005017() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005017",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005017", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005017", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005017", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005017", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005017", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005017", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005017", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005017", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005017", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005017", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005017", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005017", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005017")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005018")
    void case_UTAPI_005018() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005018",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005018", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005018", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005018", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005018", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005018", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005018", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005018", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005018", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005018", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005018", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005018", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005018", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005018")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005019")
    void case_UTAPI_005019() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005019",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005019", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005019", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005019", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005019", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005019", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005019", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005019", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005019", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005019", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005019", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005019", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005019", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005019")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005020")
    void case_UTAPI_005020() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005020",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005020", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005020", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005020", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005020", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005020", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005020", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005020", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005020", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005020", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005020", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005020", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005020", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005020")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005021")
    void case_UTAPI_005021() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005021",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005021", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005021", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005021", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005021", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005021", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005021", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005021", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005021", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005021", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005021", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005021", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005021", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005021")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005022")
    void case_UTAPI_005022() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005022",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005022", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005022", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005022", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005022", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005022", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005022", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005022", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005022", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005022", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005022", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005022", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005022", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005022")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005023")
    void case_UTAPI_005023() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005023",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005023", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005023", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005023", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005023", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005023", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005023", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005023", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005023", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005023", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005023", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005023", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005023", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005023")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005024")
    void case_UTAPI_005024() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005024",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005024", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005024", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005024", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005024", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005024", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005024", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005024", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005024", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005024", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005024", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005024", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005024", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005024")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005025")
    void case_UTAPI_005025() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005025",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005025", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005025", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005025", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005025", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005025", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005025", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005025", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005025", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005025", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005025", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005025", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005025", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005025")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005026")
    void case_UTAPI_005026() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005026",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005026", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005026", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005026", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005026", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005026", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005026", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005026", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005026", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005026", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005026", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005026", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005026", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005026")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005027")
    void case_UTAPI_005027() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005027",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005027", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005027", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005027", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005027", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005027", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005027", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005027", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005027", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005027", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005027", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005027", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005027", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005027")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005028")
    void case_UTAPI_005028() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005028",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005028", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005028", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005028", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005028", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005028", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005028", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005028", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005028", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005028", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005028", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005028", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005028", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005028")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005029")
    void case_UTAPI_005029() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005029",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005029", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005029", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005029", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005029", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005029", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005029", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005029", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005029", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005029", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005029", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005029", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005029", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005029")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005030")
    void case_UTAPI_005030() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005030",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005030", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005030", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005030", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005030", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005030", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005030", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005030", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005030", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005030", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005030", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005030", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005030", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005030")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005031")
    void case_UTAPI_005031() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005031",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005031", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005031", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005031", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005031", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005031", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005031", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005031", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005031", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005031", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005031", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005031", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005031", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005031")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005032")
    void case_UTAPI_005032() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005032",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005032", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005032", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005032", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005032", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005032", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005032", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005032", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005032", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005032", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005032", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005032", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005032", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005032")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005033")
    void case_UTAPI_005033() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005033",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005033", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005033", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005033", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005033", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005033", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005033", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005033", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005033", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005033", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005033", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005033", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005033", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005033")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005034")
    void case_UTAPI_005034() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005034",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005034", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005034", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005034", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005034", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005034", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005034", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005034", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005034", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005034", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005034", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005034", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005034", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005034")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005035")
    void case_UTAPI_005035() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005035",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005035", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005035", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005035", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005035", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005035", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005035", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005035", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005035", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005035", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005035", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005035", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005035", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005035")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005036")
    void case_UTAPI_005036() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005036",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005036", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005036", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005036", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005036", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005036", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005036", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005036", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005036", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005036", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005036", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005036", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005036", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005036")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005037")
    void case_UTAPI_005037() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005037",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005037", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005037", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005037", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005037", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005037", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005037", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005037", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005037", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005037", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005037", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005037", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005037", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005037")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005038")
    void case_UTAPI_005038() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005038",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005038", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005038", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005038", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005038", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005038", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005038", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005038", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005038", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005038", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005038", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005038", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005038", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005038")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005039")
    void case_UTAPI_005039() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005039",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005039", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005039", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005039", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005039", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005039", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005039", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005039", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005039", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005039", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005039", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005039", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005039", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005039")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005040")
    void case_UTAPI_005040() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005040",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005040", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005040", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005040", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005040", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005040", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005040", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005040", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005040", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005040", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005040", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005040", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005040", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005040")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005041")
    void case_UTAPI_005041() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005041",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005041", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005041", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005041", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005041", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005041", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005041", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005041", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005041", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005041", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005041", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005041", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005041", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005041")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005042")
    void case_UTAPI_005042() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005042",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005042", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005042", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005042", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005042", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005042", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005042", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005042", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005042", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005042", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005042", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005042", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005042", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005042")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005043")
    void case_UTAPI_005043() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005043",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005043", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005043", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005043", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005043", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005043", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005043", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005043", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005043", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005043", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005043", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005043", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005043", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005043")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005044")
    void case_UTAPI_005044() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005044",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005044", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005044", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005044", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005044", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005044", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005044", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005044", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005044", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005044", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005044", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005044", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005044", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005044")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005045")
    void case_UTAPI_005045() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005045",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005045", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005045", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005045", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005045", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005045", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005045", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005045", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005045", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005045", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005045", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005045", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005045", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005045")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005046")
    void case_UTAPI_005046() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005046",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005046", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005046", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005046", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005046", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005046", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005046", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005046", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005046", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005046", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005046", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005046", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005046", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005046")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005047")
    void case_UTAPI_005047() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005047",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005047", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005047", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005047", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005047", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005047", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005047", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005047", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005047", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005047", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005047", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005047", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005047", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005047")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005048")
    void case_UTAPI_005048() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005048",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005048", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005048", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005048", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005048", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005048", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005048", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005048", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005048", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005048", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005048", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005048", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005048", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005048")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005049")
    void case_UTAPI_005049() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005049",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005049", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005049", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005049", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005049", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005049", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005049", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005049", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005049", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005049", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005049", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005049", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005049", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005049")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005050")
    void case_UTAPI_005050() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005050",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005050", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005050", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005050", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005050", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005050", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005050", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005050", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005050", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005050", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005050", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005050", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005050", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005050")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005051")
    void case_UTAPI_005051() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005051",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005051", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005051", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005051", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005051", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005051", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005051", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005051", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005051", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005051", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005051", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005051", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005051", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005051")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005052")
    void case_UTAPI_005052() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005052",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005052", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005052", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005052", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005052", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005052", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005052", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005052", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005052", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005052", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005052", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005052", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005052", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005052")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005053")
    void case_UTAPI_005053() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005053",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005053", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005053", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005053", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005053", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005053", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005053", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005053", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005053", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005053", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005053", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005053", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005053", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005053")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005054")
    void case_UTAPI_005054() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005054",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005054", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005054", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005054", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005054", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005054", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005054", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005054", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005054", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005054", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005054", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005054", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005054", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005054")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005055")
    void case_UTAPI_005055() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005055",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005055", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005055", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005055", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005055", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005055", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005055", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005055", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005055", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005055", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005055", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005055", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005055", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005055")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005056")
    void case_UTAPI_005056() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005056",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005056", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005056", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005056", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005056", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005056", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005056", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005056", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005056", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005056", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005056", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005056", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005056", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005056")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005057")
    void case_UTAPI_005057() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005057",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005057", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005057", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005057", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005057", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005057", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005057", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005057", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005057", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005057", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005057", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005057", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005057", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005057")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005058")
    void case_UTAPI_005058() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005058",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005058", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005058", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005058", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005058", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005058", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005058", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005058", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005058", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005058", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005058", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005058", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005058", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005058")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005059")
    void case_UTAPI_005059() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005059",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005059", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005059", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005059", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005059", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005059", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005059", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005059", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005059", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005059", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005059", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005059", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005059", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005059")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005060")
    void case_UTAPI_005060() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005060",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005060", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005060", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005060", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005060", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005060", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005060", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005060", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005060", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005060", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005060", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005060", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005060", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005060")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005061")
    void case_UTAPI_005061() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005061",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005061", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005061", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005061", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005061", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005061", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005061", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005061", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005061", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005061", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005061", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005061", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005061", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005061")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005062")
    void case_UTAPI_005062() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005062",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005062", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005062", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005062", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005062", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005062", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005062", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005062", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005062", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005062", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005062", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005062", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005062", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005062")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005063")
    void case_UTAPI_005063() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005063",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005063", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005063", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005063", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005063", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005063", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005063", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005063", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005063", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005063", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005063", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005063", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005063", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005063")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005064")
    void case_UTAPI_005064() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005064",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005064", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005064", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005064", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005064", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005064", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005064", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005064", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005064", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005064", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005064", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005064", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005064", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005064")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005065")
    void case_UTAPI_005065() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005065",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005065", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005065", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005065", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005065", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005065", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005065", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005065", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005065", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005065", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005065", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005065", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005065", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005065")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005066")
    void case_UTAPI_005066() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005066",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005066", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005066", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005066", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005066", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005066", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005066", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005066", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005066", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005066", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005066", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005066", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005066", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005066")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005067")
    void case_UTAPI_005067() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005067",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005067", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005067", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005067", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005067", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005067", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005067", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005067", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005067", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005067", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005067", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005067", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005067", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005067")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005068")
    void case_UTAPI_005068() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005068",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005068", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005068", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005068", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005068", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005068", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005068", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005068", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005068", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005068", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005068", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005068", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005068", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005068")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005069")
    void case_UTAPI_005069() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005069",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005069", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005069", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005069", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005069", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005069", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005069", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005069", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005069", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005069", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005069", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005069", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005069", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005069")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005070")
    void case_UTAPI_005070() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005070",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005070", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005070", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005070", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005070", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005070", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005070", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005070", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005070", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005070", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005070", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005070", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005070", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005070")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005071")
    void case_UTAPI_005071() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005071",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005071", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005071", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005071", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005071", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005071", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005071", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005071", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005071", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005071", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005071", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005071", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005071", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005071")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005072")
    void case_UTAPI_005072() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005072",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005072", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005072", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005072", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005072", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005072", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005072", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005072", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005072", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005072", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005072", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005072", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005072", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005072")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005073")
    void case_UTAPI_005073() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005073",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005073", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005073", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005073", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005073", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005073", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005073", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005073", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005073", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005073", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005073", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005073", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005073", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005073")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005074")
    void case_UTAPI_005074() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005074",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005074", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005074", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005074", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005074", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005074", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005074", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005074", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005074", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005074", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005074", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005074", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005074", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005074")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005075")
    void case_UTAPI_005075() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005075",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005075", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005075", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005075", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005075", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005075", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005075", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005075", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005075", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005075", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005075", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005075", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005075", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005075")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005076")
    void case_UTAPI_005076() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005076",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005076", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005076", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005076", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005076", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005076", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005076", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005076", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005076", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005076", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005076", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005076", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005076", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005076")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005077")
    void case_UTAPI_005077() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005077",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005077", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005077", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005077", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005077", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005077", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005077", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005077", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005077", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005077", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005077", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005077", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005077", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005077")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005078")
    void case_UTAPI_005078() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005078",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005078", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005078", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005078", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005078", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005078", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005078", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005078", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005078", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005078", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005078", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005078", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005078", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005078")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005079")
    void case_UTAPI_005079() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005079",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005079", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005079", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005079", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005079", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005079", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005079", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005079", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005079", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005079", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005079", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005079", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005079", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005079")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005080")
    void case_UTAPI_005080() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005080",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005080", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005080", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005080", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005080", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005080", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005080", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005080", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005080", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005080", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005080", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005080", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005080", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005080")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005081")
    void case_UTAPI_005081() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005081",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005081", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005081", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005081", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005081", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005081", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005081", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005081", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005081", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005081", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005081", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005081", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005081", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005081")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005082")
    void case_UTAPI_005082() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005082",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005082", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005082", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005082", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005082", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005082", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005082", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005082", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005082", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005082", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005082", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005082", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005082", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005082")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005083")
    void case_UTAPI_005083() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005083",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005083", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005083", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005083", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005083", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005083", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005083", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005083", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005083", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005083", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005083", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005083", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005083", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005083")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005084")
    void case_UTAPI_005084() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005084",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005084", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005084", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005084", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005084", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005084", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005084", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005084", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005084", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005084", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005084", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005084", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005084", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005084")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005085")
    void case_UTAPI_005085() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005085",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005085", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005085", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005085", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005085", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005085", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005085", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005085", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005085", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005085", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005085", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005085", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005085", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005085")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005086")
    void case_UTAPI_005086() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005086",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005086", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005086", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005086", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005086", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005086", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005086", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005086", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005086", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005086", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005086", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005086", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005086", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005086")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005087")
    void case_UTAPI_005087() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005087",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005087", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005087", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005087", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005087", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005087", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005087", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005087", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005087", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005087", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005087", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005087", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005087", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005087")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005088")
    void case_UTAPI_005088() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005088",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005088", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005088", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005088", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005088", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005088", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005088", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005088", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005088", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005088", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005088", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005088", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005088", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005088")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005089")
    void case_UTAPI_005089() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005089",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005089", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005089", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005089", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005089", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005089", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005089", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005089", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005089", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005089", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005089", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005089", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005089", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005089")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005090")
    void case_UTAPI_005090() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005090",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005090", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005090", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005090", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005090", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005090", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005090", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005090", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005090", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005090", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005090", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005090", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005090", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005090")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005091")
    void case_UTAPI_005091() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005091",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005091", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005091", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005091", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005091", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005091", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005091", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005091", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005091", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005091", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005091", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005091", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005091", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005091")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005092")
    void case_UTAPI_005092() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005092",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005092", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005092", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005092", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005092", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005092", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005092", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005092", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005092", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005092", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005092", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005092", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005092", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005092")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005093")
    void case_UTAPI_005093() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005093",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005093", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005093", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005093", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005093", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005093", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005093", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005093", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005093", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005093", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005093", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005093", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005093", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005093")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005094")
    void case_UTAPI_005094() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005094",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005094", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005094", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005094", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005094", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005094", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005094", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005094", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005094", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005094", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005094", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005094", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005094", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005094")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005095")
    void case_UTAPI_005095() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005095",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005095", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005095", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005095", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005095", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005095", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005095", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005095", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005095", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005095", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005095", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005095", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005095", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005095")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005096")
    void case_UTAPI_005096() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005096",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005096", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005096", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005096", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005096", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005096", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005096", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005096", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005096", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005096", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005096", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005096", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005096", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005096")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005097")
    void case_UTAPI_005097() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005097",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005097", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005097", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005097", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005097", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005097", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005097", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005097", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005097", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005097", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005097", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005097", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005097", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005097")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005098")
    void case_UTAPI_005098() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005098",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005098", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005098", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005098", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005098", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005098", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005098", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005098", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005098", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005098", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005098", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005098", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005098", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005098")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005099")
    void case_UTAPI_005099() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005099",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005099", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005099", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005099", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005099", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005099", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005099", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005099", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005099", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005099", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005099", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005099", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005099", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005099")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005100")
    void case_UTAPI_005100() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005100",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005100", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005100", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005100", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005100", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005100", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005100", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005100", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005100", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005100", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005100", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005100", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005100", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005100")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005101")
    void case_UTAPI_005101() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005101",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005101", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005101", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005101", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005101", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005101", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005101", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005101", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005101", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005101", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005101", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005101", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005101", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005101")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005102")
    void case_UTAPI_005102() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005102",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005102", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005102", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005102", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005102", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005102", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005102", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005102", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005102", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005102", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005102", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005102", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005102", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005102")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005103")
    void case_UTAPI_005103() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005103",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005103", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005103", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005103", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005103", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005103", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005103", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005103", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005103", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005103", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005103", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005103", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005103", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005103")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005104")
    void case_UTAPI_005104() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005104",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005104", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005104", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005104", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005104", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005104", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005104", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005104", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005104", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005104", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005104", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005104", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005104", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005104")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005105")
    void case_UTAPI_005105() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005105",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005105", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005105", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005105", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005105", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005105", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005105", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005105", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005105", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005105", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005105", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005105", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005105", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005105")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005106")
    void case_UTAPI_005106() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005106",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005106", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005106", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005106", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005106", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005106", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005106", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005106", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005106", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005106", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005106", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005106", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005106", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005106")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005107")
    void case_UTAPI_005107() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005107",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005107", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005107", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005107", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005107", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005107", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005107", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005107", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005107", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005107", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005107", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005107", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005107", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005107")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005108")
    void case_UTAPI_005108() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005108",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005108", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005108", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005108", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005108", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005108", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005108", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005108", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005108", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005108", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005108", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005108", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005108", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005108")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005109")
    void case_UTAPI_005109() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005109",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005109", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005109", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005109", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005109", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005109", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005109", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005109", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005109", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005109", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005109", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005109", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005109", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005109")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005110")
    void case_UTAPI_005110() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005110",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005110", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005110", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005110", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005110", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005110", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005110", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005110", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005110", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005110", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005110", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005110", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005110", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005110")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005111")
    void case_UTAPI_005111() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005111",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005111", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005111", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005111", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005111", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005111", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005111", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005111", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005111", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005111", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005111", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005111", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005111", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005111")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005112")
    void case_UTAPI_005112() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005112",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005112", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005112", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005112", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005112", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005112", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005112", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005112", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005112", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005112", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005112", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005112", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005112", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005112")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005113")
    void case_UTAPI_005113() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005113",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005113", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005113", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005113", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005113", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005113", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005113", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005113", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005113", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005113", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005113", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005113", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005113", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005113")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005114")
    void case_UTAPI_005114() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005114",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005114", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005114", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005114", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005114", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005114", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005114", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005114", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005114", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005114", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005114", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005114", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005114", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005114")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005115")
    void case_UTAPI_005115() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005115",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005115", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005115", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005115", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005115", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005115", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005115", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005115", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005115", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005115", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005115", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005115", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005115", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005115")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005116")
    void case_UTAPI_005116() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005116",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005116", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005116", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005116", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005116", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005116", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005116", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005116", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005116", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005116", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005116", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005116", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005116", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005116")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005117")
    void case_UTAPI_005117() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005117",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005117", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005117", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005117", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005117", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005117", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005117", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005117", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005117", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005117", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005117", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005117", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005117", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005117")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005118")
    void case_UTAPI_005118() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005118",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005118", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005118", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005118", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005118", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005118", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005118", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005118", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005118", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005118", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005118", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005118", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005118", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005118")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005119")
    void case_UTAPI_005119() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005119",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005119", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005119", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005119", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005119", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005119", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005119", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005119", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005119", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005119", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005119", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005119", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005119", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005119")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005120")
    void case_UTAPI_005120() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005120",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005120", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005120", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005120", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005120", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005120", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005120", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005120", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005120", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005120", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005120", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005120", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005120", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005120")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005121")
    void case_UTAPI_005121() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005121",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005121", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005121", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005121", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005121", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005121", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005121", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005121", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005121", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005121", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005121", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005121", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005121", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005121")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

}

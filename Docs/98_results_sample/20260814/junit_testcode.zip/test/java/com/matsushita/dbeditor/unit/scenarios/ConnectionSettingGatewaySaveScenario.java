package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ConnectionSettingGatewayWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ConnectionSettingGateway#save.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ConnectionSettingGatewaySaveScenario {

    @Test
    @DisplayName("UTAPI-001870")
    void case_UTAPI_001870() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001870",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001870", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001870", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001870", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001870", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001870", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001870", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001870", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001870", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001870", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001870", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001870")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001871")
    void case_UTAPI_001871() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001871",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001871", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001871", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001871", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001871", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001871", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001871", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001871", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001871", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001871", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001871", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001871")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001872")
    void case_UTAPI_001872() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001872",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001872", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001872", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001872", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001872", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001872", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001872", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001872", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001872", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001872", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001872", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001872")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001873")
    void case_UTAPI_001873() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001873",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001873", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001873", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001873", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001873", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001873", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001873", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001873", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001873", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001873", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001873", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001873")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001874")
    void case_UTAPI_001874() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001874",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001874", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001874", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001874", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001874", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001874", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001874", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001874", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001874", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001874", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001874", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001874")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001875")
    void case_UTAPI_001875() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001875",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001875", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001875", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001875", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001875", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001875", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001875", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001875", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001875", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001875", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001875", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001875")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001876")
    void case_UTAPI_001876() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001876",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001876", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001876", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001876", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001876", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001876", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001876", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001876", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001876", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001876", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001876", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001876")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001877")
    void case_UTAPI_001877() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001877",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001877", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001877", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001877", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001877", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001877", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001877", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001877", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001877", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001877", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001877", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001877")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001878")
    void case_UTAPI_001878() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001878",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001878", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001878", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001878", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001878", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001878", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001878", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001878", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001878", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001878", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001878", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001878")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001879")
    void case_UTAPI_001879() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001879",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001879", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001879", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001879", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001879", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001879", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001879", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001879", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001879", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001879", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001879", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001879")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001880")
    void case_UTAPI_001880() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001880",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001880", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001880", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001880", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001880", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001880", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001880", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001880", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001880", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001880", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001880", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001880")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001881")
    void case_UTAPI_001881() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001881",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001881", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001881", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001881", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001881", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001881", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001881", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001881", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001881", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001881", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001881", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001881")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001882")
    void case_UTAPI_001882() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001882",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001882", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001882", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001882", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001882", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001882", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001882", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001882", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001882", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001882", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001882", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001882")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001883")
    void case_UTAPI_001883() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001883",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001883", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001883", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001883", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001883", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001883", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001883", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001883", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001883", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001883", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001883", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001883")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001884")
    void case_UTAPI_001884() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001884",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001884", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001884", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001884", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001884", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001884", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001884", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001884", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001884", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001884", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001884", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001884")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001885")
    void case_UTAPI_001885() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001885",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001885", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001885", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001885", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001885", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001885", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001885", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001885", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001885", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001885", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001885", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001885")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001886")
    void case_UTAPI_001886() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001886",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001886", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001886", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001886", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001886", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001886", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001886", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001886", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001886", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001886", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001886", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001886")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001887")
    void case_UTAPI_001887() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001887",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001887", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001887", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001887", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001887", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001887", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001887", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001887", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001887", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001887", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001887", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001887")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001888")
    void case_UTAPI_001888() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001888",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001888", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001888", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001888", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001888", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001888", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001888", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001888", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001888", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001888", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001888", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001888")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001889")
    void case_UTAPI_001889() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001889",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001889", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001889", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001889", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001889", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001889", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001889", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001889", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001889", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001889", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001889", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001889")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001890")
    void case_UTAPI_001890() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001890",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001890", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001890", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001890", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001890", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001890", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001890", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001890", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001890", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001890", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001890", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001890")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001891")
    void case_UTAPI_001891() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001891",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001891", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001891", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001891", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001891", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001891", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001891", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001891", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001891", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001891", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001891", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001891")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001892")
    void case_UTAPI_001892() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001892",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001892", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001892", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001892", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001892", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001892", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001892", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001892", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001892", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001892", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001892", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001892")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001893")
    void case_UTAPI_001893() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001893",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001893", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001893", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001893", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001893", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001893", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001893", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001893", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001893", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001893", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001893", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001893")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001894")
    void case_UTAPI_001894() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001894",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001894", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001894", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001894", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001894", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001894", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001894", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001894", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001894", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001894", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001894", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001894")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001895")
    void case_UTAPI_001895() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001895",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001895", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001895", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001895", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001895", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001895", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001895", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001895", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001895", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001895", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001895", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001895")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001896")
    void case_UTAPI_001896() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001896",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001896", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001896", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001896", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001896", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001896", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001896", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001896", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001896", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001896", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001896", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001896")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001897")
    void case_UTAPI_001897() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001897",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001897", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001897", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001897", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001897", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001897", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001897", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001897", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001897", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001897", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001897", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001897")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001898")
    void case_UTAPI_001898() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001898",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001898", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001898", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001898", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001898", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001898", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001898", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001898", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001898", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001898", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001898", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001898")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001899")
    void case_UTAPI_001899() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001899",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001899", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001899", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001899", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001899", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001899", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001899", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001899", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001899", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001899", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001899", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001899")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001900")
    void case_UTAPI_001900() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001900",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001900", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001900", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001900", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001900", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001900", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001900", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001900", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001900", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001900", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001900", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001900")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001901")
    void case_UTAPI_001901() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001901",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001901", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001901", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001901", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001901", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001901", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001901", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001901", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001901", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001901", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001901", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001901")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001902")
    void case_UTAPI_001902() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001902",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001902", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001902", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001902", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001902", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001902", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001902", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001902", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001902", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001902", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001902", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001902")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001903")
    void case_UTAPI_001903() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001903",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001903", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001903", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001903", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001903", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001903", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001903", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001903", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001903", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001903", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001903", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001903")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001904")
    void case_UTAPI_001904() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001904",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001904", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001904", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001904", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001904", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001904", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001904", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001904", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001904", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001904", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001904", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001904")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001905")
    void case_UTAPI_001905() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001905",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001905", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001905", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001905", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001905", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001905", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001905", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001905", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001905", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001905", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001905", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001905")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001906")
    void case_UTAPI_001906() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001906",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001906", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001906", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001906", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001906", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001906", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001906", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001906", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001906", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001906", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001906", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001906")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001907")
    void case_UTAPI_001907() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001907",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001907", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001907", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001907", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001907", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001907", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001907", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001907", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001907", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001907", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001907", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001907")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001908")
    void case_UTAPI_001908() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001908",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001908", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001908", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001908", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001908", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001908", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001908", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001908", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001908", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001908", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001908", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001908")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001909")
    void case_UTAPI_001909() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001909",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001909", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001909", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001909", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001909", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001909", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001909", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001909", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001909", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001909", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001909", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001909")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001910")
    void case_UTAPI_001910() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001910",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001910", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001910", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001910", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001910", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001910", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001910", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001910", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001910", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001910", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001910", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001910")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001911")
    void case_UTAPI_001911() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001911",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001911", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001911", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001911", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001911", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001911", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001911", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001911", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001911", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001911", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001911", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001911")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001912")
    void case_UTAPI_001912() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001912",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001912", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001912", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001912", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001912", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001912", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001912", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001912", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001912", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001912", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001912", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001912")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001913")
    void case_UTAPI_001913() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001913",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001913", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001913", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001913", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001913", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001913", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001913", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001913", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001913", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001913", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001913", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001913")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001914")
    void case_UTAPI_001914() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001914",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001914", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001914", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001914", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001914", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001914", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001914", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001914", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001914", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001914", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001914", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001914")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001915")
    void case_UTAPI_001915() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001915",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001915", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001915", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001915", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001915", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001915", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001915", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001915", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001915", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001915", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001915", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001915")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001916")
    void case_UTAPI_001916() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001916",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001916", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001916", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001916", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001916", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001916", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001916", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001916", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001916", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001916", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001916", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001916")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001917")
    void case_UTAPI_001917() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001917",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001917", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001917", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001917", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001917", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001917", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001917", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001917", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001917", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001917", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001917", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001917")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001918")
    void case_UTAPI_001918() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001918",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001918", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001918", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001918", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001918", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001918", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001918", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001918", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001918", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001918", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001918", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001918")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001919")
    void case_UTAPI_001919() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001919",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001919", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001919", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001919", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001919", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001919", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001919", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001919", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001919", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001919", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001919", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001919")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001920")
    void case_UTAPI_001920() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001920",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001920", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001920", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001920", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001920", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001920", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001920", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001920", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001920", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001920", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001920", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001920")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001921")
    void case_UTAPI_001921() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001921",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001921", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001921", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001921", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001921", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001921", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001921", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001921", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001921", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001921", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001921", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001921")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001922")
    void case_UTAPI_001922() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001922",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001922", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001922", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001922", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001922", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001922", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001922", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001922", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001922", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001922", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001922", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001922")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001923")
    void case_UTAPI_001923() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001923",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001923", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001923", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001923", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001923", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001923", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001923", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001923", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001923", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001923", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001923", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001923")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001924")
    void case_UTAPI_001924() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001924",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001924", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001924", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001924", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001924", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001924", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001924", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001924", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001924", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001924", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001924", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001924")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001925")
    void case_UTAPI_001925() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001925",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001925", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001925", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001925", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001925", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001925", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001925", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001925", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001925", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001925", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001925", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001925")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001926")
    void case_UTAPI_001926() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001926",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001926", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001926", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001926", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001926", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001926", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001926", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001926", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001926", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001926", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001926", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001926")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001927")
    void case_UTAPI_001927() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001927",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001927", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001927", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001927", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001927", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001927", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001927", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001927", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001927", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001927", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001927", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001927")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001928")
    void case_UTAPI_001928() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001928",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001928", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001928", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001928", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001928", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001928", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001928", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001928", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001928", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001928", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001928", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001928")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001929")
    void case_UTAPI_001929() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001929",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001929", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001929", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001929", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001929", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001929", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001929", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001929", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001929", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001929", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001929", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001929")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001930")
    void case_UTAPI_001930() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001930",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001930", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001930", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001930", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001930", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001930", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001930", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001930", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001930", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001930", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001930", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001930")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001931")
    void case_UTAPI_001931() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001931",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001931", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001931", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001931", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001931", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001931", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001931", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001931", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001931", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001931", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001931", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001931")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001932")
    void case_UTAPI_001932() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001932",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001932", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001932", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001932", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001932", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001932", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001932", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001932", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001932", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001932", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001932", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001932")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001933")
    void case_UTAPI_001933() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001933",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001933", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001933", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001933", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001933", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001933", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001933", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001933", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001933", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001933", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001933", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001933")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001934")
    void case_UTAPI_001934() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001934",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001934", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001934", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001934", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001934", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001934", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001934", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001934", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001934", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001934", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001934", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001934")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001935")
    void case_UTAPI_001935() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001935",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001935", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001935", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001935", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001935", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001935", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001935", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001935", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001935", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001935", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001935", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001935")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001936")
    void case_UTAPI_001936() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001936",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001936", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001936", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001936", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001936", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001936", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001936", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001936", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001936", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001936", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001936", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001936")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001937")
    void case_UTAPI_001937() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001937",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001937", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001937", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001937", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001937", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001937", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001937", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001937", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001937", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001937", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001937", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001937")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001938")
    void case_UTAPI_001938() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001938",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001938", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001938", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001938", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001938", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001938", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001938", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001938", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001938", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001938", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001938", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001938")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001939")
    void case_UTAPI_001939() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001939",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001939", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001939", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001939", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001939", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001939", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001939", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001939", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001939", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001939", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001939", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001939")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001940")
    void case_UTAPI_001940() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001940",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001940", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001940", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001940", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001940", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001940", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001940", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001940", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001940", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001940", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001940", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001940")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001941")
    void case_UTAPI_001941() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001941",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001941", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001941", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001941", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001941", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001941", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001941", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001941", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001941", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001941", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001941", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001941")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001942")
    void case_UTAPI_001942() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001942",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001942", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001942", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001942", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001942", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001942", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001942", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001942", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001942", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001942", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001942", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001942")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001943")
    void case_UTAPI_001943() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001943",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001943", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001943", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001943", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001943", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001943", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001943", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001943", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001943", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001943", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001943", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001943")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001944")
    void case_UTAPI_001944() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001944",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001944", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001944", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001944", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001944", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001944", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001944", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001944", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001944", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001944", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001944", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001944")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001945")
    void case_UTAPI_001945() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001945",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001945", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001945", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001945", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001945", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001945", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001945", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001945", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001945", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001945", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001945", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001945")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001946")
    void case_UTAPI_001946() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001946",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001946", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001946", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001946", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001946", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001946", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001946", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001946", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001946", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001946", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001946", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001946")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001947")
    void case_UTAPI_001947() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001947",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001947", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001947", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001947", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001947", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001947", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001947", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001947", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001947", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001947", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001947", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001947")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001948")
    void case_UTAPI_001948() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001948",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001948", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001948", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001948", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001948", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001948", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001948", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001948", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001948", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001948", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001948", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001948")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001949")
    void case_UTAPI_001949() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001949",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001949", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001949", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001949", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001949", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001949", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001949", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001949", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001949", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001949", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001949", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001949")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001950")
    void case_UTAPI_001950() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001950",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001950", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001950", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001950", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001950", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001950", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001950", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001950", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001950", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001950", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001950", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001950")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001951")
    void case_UTAPI_001951() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001951",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001951", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001951", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001951", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001951", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001951", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001951", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001951", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001951", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001951", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001951", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001951")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001952")
    void case_UTAPI_001952() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001952",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001952", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001952", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001952", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001952", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001952", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001952", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001952", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001952", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001952", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001952", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001952")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001953")
    void case_UTAPI_001953() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001953",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001953", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001953", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001953", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001953", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001953", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001953", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001953", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001953", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001953", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001953", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001953")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001954")
    void case_UTAPI_001954() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001954",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001954", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001954", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001954", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001954", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001954", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001954", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001954", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001954", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001954", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001954", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001954")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001955")
    void case_UTAPI_001955() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001955",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001955", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001955", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001955", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001955", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001955", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001955", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001955", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001955", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001955", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001955", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001955")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001956")
    void case_UTAPI_001956() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001956",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001956", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001956", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001956", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001956", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001956", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001956", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001956", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001956", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001956", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001956", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001956")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001957")
    void case_UTAPI_001957() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001957",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001957", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001957", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001957", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001957", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001957", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001957", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001957", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001957", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001957", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001957", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001957")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001958")
    void case_UTAPI_001958() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001958",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001958", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001958", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001958", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001958", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001958", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001958", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001958", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001958", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001958", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001958", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001958")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001959")
    void case_UTAPI_001959() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001959",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001959", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001959", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001959", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001959", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001959", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001959", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001959", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001959", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001959", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001959", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001959")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001960")
    void case_UTAPI_001960() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001960",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001960", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001960", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001960", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001960", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001960", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001960", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001960", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001960", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001960", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001960", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001960")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001961")
    void case_UTAPI_001961() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001961",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001961", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001961", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001961", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001961", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001961", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001961", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001961", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001961", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001961", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001961", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001961")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001962")
    void case_UTAPI_001962() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001962",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001962", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001962", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001962", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001962", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001962", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001962", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001962", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001962", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001962", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001962", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001962")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001963")
    void case_UTAPI_001963() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001963",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001963", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001963", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001963", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001963", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001963", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001963", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001963", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001963", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001963", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001963", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001963")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001964")
    void case_UTAPI_001964() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001964",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001964", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001964", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001964", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001964", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001964", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001964", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001964", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001964", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001964", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001964", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001964")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001965")
    void case_UTAPI_001965() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001965",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001965", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001965", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001965", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001965", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001965", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001965", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001965", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001965", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001965", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001965", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001965")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001966")
    void case_UTAPI_001966() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001966",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001966", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001966", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001966", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001966", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001966", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001966", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001966", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001966", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001966", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001966", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001966")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001967")
    void case_UTAPI_001967() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001967",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001967", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001967", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001967", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001967", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001967", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001967", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001967", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001967", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001967", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001967", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001967")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001968")
    void case_UTAPI_001968() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001968",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001968", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001968", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001968", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001968", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001968", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001968", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001968", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001968", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001968", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001968", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001968")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001969")
    void case_UTAPI_001969() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001969",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001969", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001969", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001969", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001969", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001969", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001969", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001969", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001969", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001969", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001969", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001969")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001970")
    void case_UTAPI_001970() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001970",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001970", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001970", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001970", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001970", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001970", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001970", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001970", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001970", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001970", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001970", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001970")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001971")
    void case_UTAPI_001971() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001971",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001971", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001971", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001971", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001971", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001971", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001971", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001971", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001971", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001971", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001971", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001971")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001972")
    void case_UTAPI_001972() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001972",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001972", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001972", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001972", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001972", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001972", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001972", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001972", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001972", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001972", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001972", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001972")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001973")
    void case_UTAPI_001973() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001973",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001973", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001973", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001973", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001973", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001973", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001973", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001973", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001973", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001973", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001973", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001973")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001974")
    void case_UTAPI_001974() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001974",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001974", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001974", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001974", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001974", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001974", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001974", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001974", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001974", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001974", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001974", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001974")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001975")
    void case_UTAPI_001975() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001975",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001975", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001975", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001975", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001975", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001975", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001975", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001975", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001975", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001975", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001975", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001975")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001976")
    void case_UTAPI_001976() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001976",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001976", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001976", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001976", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001976", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001976", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001976", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001976", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001976", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001976", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001976", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001976")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001977")
    void case_UTAPI_001977() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001977",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001977", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001977", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001977", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001977", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001977", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001977", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001977", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001977", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001977", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001977", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001977")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001978")
    void case_UTAPI_001978() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001978",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001978", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001978", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001978", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001978", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001978", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001978", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001978", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001978", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001978", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001978", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001978")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001979")
    void case_UTAPI_001979() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001979",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001979", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001979", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001979", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001979", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001979", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001979", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001979", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001979", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001979", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001979", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001979")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001980")
    void case_UTAPI_001980() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001980",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001980", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001980", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001980", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001980", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001980", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001980", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001980", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001980", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001980", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001980", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001980")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001981")
    void case_UTAPI_001981() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001981",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001981", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001981", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001981", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001981", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001981", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001981", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001981", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001981", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001981", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001981", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001981")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001982")
    void case_UTAPI_001982() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001982",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001982", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001982", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001982", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001982", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001982", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001982", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001982", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001982", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001982", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001982", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001982")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001983")
    void case_UTAPI_001983() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001983",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001983", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001983", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001983", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001983", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001983", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001983", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001983", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001983", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001983", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001983", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001983")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001984")
    void case_UTAPI_001984() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001984",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001984", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001984", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001984", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001984", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001984", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001984", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001984", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001984", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001984", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001984", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001984")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001985")
    void case_UTAPI_001985() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001985",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001985", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001985", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001985", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001985", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001985", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001985", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001985", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001985", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001985", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001985", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001985")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001986")
    void case_UTAPI_001986() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001986",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001986", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001986", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001986", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001986", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001986", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001986", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001986", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001986", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001986", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001986", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001986")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001987")
    void case_UTAPI_001987() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001987",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001987", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001987", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001987", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001987", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001987", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001987", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001987", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001987", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001987", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001987", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001987")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001988")
    void case_UTAPI_001988() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001988",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001988", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001988", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001988", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001988", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001988", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001988", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001988", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001988", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001988", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001988", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001988")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001989")
    void case_UTAPI_001989() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001989",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001989", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001989", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001989", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001989", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001989", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001989", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001989", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001989", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001989", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001989", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001989")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001990")
    void case_UTAPI_001990() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001990",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001990", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001990", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001990", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001990", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001990", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001990", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001990", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001990", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001990", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001990", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001990")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001991")
    void case_UTAPI_001991() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001991",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001991", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001991", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001991", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001991", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001991", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001991", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001991", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001991", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001991", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001991", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001991")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001992")
    void case_UTAPI_001992() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001992",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001992", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001992", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001992", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001992", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001992", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001992", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001992", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001992", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001992", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001992", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001992")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001993")
    void case_UTAPI_001993() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001993",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001993", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001993", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001993", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001993", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001993", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001993", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001993", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001993", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001993", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001993", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001993")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001994")
    void case_UTAPI_001994() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001994",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001994", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001994", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001994", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001994", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001994", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001994", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001994", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001994", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001994", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001994", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001994")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001995")
    void case_UTAPI_001995() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001995",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001995", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001995", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001995", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001995", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001995", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001995", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001995", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001995", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001995", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001995", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001995")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001996")
    void case_UTAPI_001996() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001996",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001996", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001996", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001996", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001996", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001996", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001996", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001996", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001996", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001996", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001996", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001996")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001997")
    void case_UTAPI_001997() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001997",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001997", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001997", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001997", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001997", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001997", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001997", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001997", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001997", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001997", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001997", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001997")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001998")
    void case_UTAPI_001998() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001998",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001998", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001998", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001998", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001998", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001998", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001998", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001998", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001998", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001998", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001998", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001998")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001999")
    void case_UTAPI_001999() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001999",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001999", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-001999", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-001999", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001999", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001999", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001999", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001999", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001999", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001999", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001999", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-001999")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002000")
    void case_UTAPI_002000() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002000",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002000", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002000", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002000", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002000", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002000", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002000", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002000", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002000", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002000", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002000", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002000")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002001")
    void case_UTAPI_002001() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002001",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002001", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002001", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002001", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002001", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002001", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002001", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002001", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002001", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002001", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002001", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002001")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002002")
    void case_UTAPI_002002() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002002",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002002", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002002", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002002", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002002", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002002", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002002", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002002", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002002", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002002", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002002", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002002")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002003")
    void case_UTAPI_002003() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002003",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002003", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002003", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002003", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002003", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002003", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002003", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002003", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002003", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002003", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002003", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002003")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002004")
    void case_UTAPI_002004() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002004",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002004", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002004", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002004", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002004", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002004", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002004", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002004", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002004", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002004", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002004", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002004")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002005")
    void case_UTAPI_002005() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002005",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002005", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002005", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002005", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002005", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002005", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002005", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002005", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002005", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002005", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002005", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002005")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002006")
    void case_UTAPI_002006() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002006",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002006", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002006", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002006", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002006", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002006", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002006", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002006", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002006", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002006", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002006", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002006")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002007")
    void case_UTAPI_002007() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002007",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002007", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002007", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002007", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002007", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002007", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002007", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002007", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002007", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002007", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002007", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002007")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002008")
    void case_UTAPI_002008() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002008",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002008", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002008", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002008", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002008", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002008", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002008", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002008", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002008", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002008", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002008", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002008")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002009")
    void case_UTAPI_002009() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002009",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002009", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002009", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002009", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002009", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002009", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002009", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002009", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002009", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002009", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002009", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002009")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002010")
    void case_UTAPI_002010() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002010",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002010", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002010", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002010", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002010", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002010", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002010", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002010", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002010", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002010", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002010", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002010")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::save::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.SqlControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for SqlController#saveSql.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class SqlControllerSaveSqlScenario {

    @Test
    @DisplayName("UTAPI-001046")
    void case_UTAPI_001046() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001046",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001046", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001046", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001046", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001046", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001046")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.connectionId", "SqlSaveRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of SqlSaveRequest.connectionId classifies this input condition", "SqlSaveRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001047")
    void case_UTAPI_001047() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001047",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001047", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001047", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001047", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001047", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001047")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("request.connectionId", "SqlSaveRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of SqlSaveRequest.connectionId classifies this input condition", "SqlSaveRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001048")
    void case_UTAPI_001048() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001048",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001048", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001048", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001048", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001048", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001048")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.connectionId", "SqlSaveRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of SqlSaveRequest.connectionId classifies this input condition", "SqlSaveRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001049")
    void case_UTAPI_001049() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001049",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001049", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001049", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001049", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001049", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001049")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("request.connectionId", "SqlSaveRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of SqlSaveRequest.connectionId classifies this input condition", "SqlSaveRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001050")
    void case_UTAPI_001050() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001050",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001050", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001050", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001050", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001050", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001050")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.connectionId", "SqlSaveRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of SqlSaveRequest.connectionId classifies this input condition", "SqlSaveRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001051")
    void case_UTAPI_001051() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001051",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001051", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001051", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001051", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001051", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001051")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.connectionId", "SqlSaveRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of SqlSaveRequest.connectionId classifies this input condition", "SqlSaveRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001052")
    void case_UTAPI_001052() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001052",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001052", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001052", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001052", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001052", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001052")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("request.connectionId", "SqlSaveRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001053")
    void case_UTAPI_001053() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001053",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001053", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001053", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001053", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001053", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001053")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("request.connectionId", "SqlSaveRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001054")
    void case_UTAPI_001054() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001054",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001054", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001054", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001054", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001054", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001054")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("request.connectionId", "SqlSaveRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001055")
    void case_UTAPI_001055() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001055",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001055", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001055", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001055", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001055", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001055")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("request.connectionId", "SqlSaveRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001056")
    void case_UTAPI_001056() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001056",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001056", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001056", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001056", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001056", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001056")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::content")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.content", "SqlSaveRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared NotBlank contract of SqlSaveRequest.content classifies this input condition", "SqlSaveRequest", "content", "NotBlank", "data:request.content")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001057")
    void case_UTAPI_001057() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001057",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001057", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001057", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001057", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001057", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001057")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::content")
                    .mirror("-", "3:length_min", "-")
                    .target("request.content", "SqlSaveRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001058")
    void case_UTAPI_001058() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001058",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001058", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001058", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001058", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001058", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001058")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::content")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.content", "SqlSaveRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001059")
    void case_UTAPI_001059() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001059",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001059", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001059", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001059", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001059", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001059")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::content")
                    .mirror("-", "5:length_max", "-")
                    .target("request.content", "SqlSaveRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001060")
    void case_UTAPI_001060() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001060",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001060", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001060", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001060", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001060", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001060")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::content")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.content", "SqlSaveRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001061")
    void case_UTAPI_001061() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001061",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001061", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001061", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001061", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001061", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001061")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::content")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.content", "SqlSaveRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001062")
    void case_UTAPI_001062() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001062",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001062", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001062", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001062", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001062", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001062")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::content")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.content", "SqlSaveRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001063")
    void case_UTAPI_001063() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001063",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001063", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001063", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001063", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001063", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001063")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::content")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.content", "SqlSaveRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001064")
    void case_UTAPI_001064() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001064",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001064", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001064", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001064", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001064", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001064")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::content")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.content", "SqlSaveRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001065")
    void case_UTAPI_001065() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001065",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001065", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001065", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001065", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001065", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001065")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::content")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.content", "SqlSaveRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001066")
    void case_UTAPI_001066() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001066",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001066", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001066", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001066", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001066", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001066")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::content")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.content", "SqlSaveRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001067")
    void case_UTAPI_001067() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001067",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001067", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001067", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001067", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001067", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001067")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::content")
                    .mirror("-", "-", "56:space")
                    .target("request.content", "SqlSaveRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001068")
    void case_UTAPI_001068() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001068",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001068", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001068", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001068", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001068", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001068")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::content")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.content", "SqlSaveRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001069")
    void case_UTAPI_001069() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001069",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001069", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001069", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001069", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001069", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001069")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::content")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.content", "SqlSaveRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001070")
    void case_UTAPI_001070() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001070",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001070", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001070", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001070", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001070", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001070")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::content")
                    .mirror("-", "-", "59:tab")
                    .target("request.content", "SqlSaveRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001071")
    void case_UTAPI_001071() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001071",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001071", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001071", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001071", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001071", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001071")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::content")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.content", "SqlSaveRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001072")
    void case_UTAPI_001072() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001072",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001072", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001072", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001072", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001072", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001072")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::content")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.content", "SqlSaveRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001073")
    void case_UTAPI_001073() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001073",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001073", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001073", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001073", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001073", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001073")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::content")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.content", "SqlSaveRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001074")
    void case_UTAPI_001074() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001074",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001074", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001074", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001074", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001074", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001074")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::content")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.content", "SqlSaveRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001075")
    void case_UTAPI_001075() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001075",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001075", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001075", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001075", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001075", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001075")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::title")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.title", "SqlSaveRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared NotBlank contract of SqlSaveRequest.title classifies this input condition", "SqlSaveRequest", "title", "NotBlank", "data:request.title")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001076")
    void case_UTAPI_001076() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001076",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001076", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001076", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001076", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001076", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001076")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::title")
                    .mirror("-", "3:length_min", "-")
                    .target("request.title", "SqlSaveRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001077")
    void case_UTAPI_001077() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001077",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001077", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001077", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001077", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001077", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001077")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::title")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.title", "SqlSaveRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001078")
    void case_UTAPI_001078() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001078",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001078", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001078", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001078", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001078", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001078")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::title")
                    .mirror("-", "5:length_max", "-")
                    .target("request.title", "SqlSaveRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001079")
    void case_UTAPI_001079() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001079",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001079", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001079", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001079", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001079", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001079")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::title")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.title", "SqlSaveRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001080")
    void case_UTAPI_001080() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001080",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001080", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001080", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001080", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001080", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001080")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::title")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.title", "SqlSaveRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001081")
    void case_UTAPI_001081() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001081",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001081", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001081", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001081", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001081", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001081")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::title")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.title", "SqlSaveRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001082")
    void case_UTAPI_001082() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001082",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001082", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001082", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001082", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001082", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001082")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::title")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.title", "SqlSaveRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001083")
    void case_UTAPI_001083() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001083",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001083", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001083", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001083", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001083", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001083")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::title")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.title", "SqlSaveRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001084")
    void case_UTAPI_001084() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001084",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001084", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001084", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001084", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001084", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001084")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::title")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("request.title", "SqlSaveRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001085")
    void case_UTAPI_001085() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001085",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001085", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001085", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001085", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001085", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001085")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::title")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.title", "SqlSaveRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001086")
    void case_UTAPI_001086() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001086",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001086", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001086", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001086", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001086", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001086")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::title")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.title", "SqlSaveRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001087")
    void case_UTAPI_001087() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001087",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001087", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001087", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001087", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001087", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001087")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::title")
                    .mirror("-", "-", "56:space")
                    .target("request.title", "SqlSaveRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001088")
    void case_UTAPI_001088() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001088",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001088", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001088", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001088", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001088", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001088")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::title")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.title", "SqlSaveRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001089")
    void case_UTAPI_001089() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001089",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001089", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001089", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001089", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001089", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001089")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::title")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.title", "SqlSaveRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001090")
    void case_UTAPI_001090() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001090",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001090", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001090", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001090", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001090", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001090")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::title")
                    .mirror("-", "-", "59:tab")
                    .target("request.title", "SqlSaveRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001091")
    void case_UTAPI_001091() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001091",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001091", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001091", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001091", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001091", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001091")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::title")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.title", "SqlSaveRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001092")
    void case_UTAPI_001092() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001092",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001092", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001092", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001092", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001092", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001092")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::title")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.title", "SqlSaveRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001093")
    void case_UTAPI_001093() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001093",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001093", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001093", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001093", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001093", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001093")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::title")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.title", "SqlSaveRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001094")
    void case_UTAPI_001094() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001094",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "saveSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001094", "request", "NORMAL", "OBJECT", "SqlSaveRequest"),
                    new DataRef("UTAPI-001094", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001094", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001094", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001094")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::saveSql::3::FIELD::1::SqlSaveRequest::title")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.title", "SqlSaveRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.saveSql")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.saveSql", "sqlUseCase", "saveSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.saveSql must carry the value generated for request.connectionId", "sqlUseCase", "saveSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.saveSql must carry the value generated for request.title", "sqlUseCase", "saveSql", "1", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 2 of sqlUseCase.saveSql must carry the value generated for request.content", "sqlUseCase", "saveSql", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

}

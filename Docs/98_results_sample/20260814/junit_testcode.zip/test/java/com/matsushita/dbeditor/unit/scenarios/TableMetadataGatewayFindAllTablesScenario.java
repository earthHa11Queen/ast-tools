package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableMetadataGatewayWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableMetadataGateway#findAllTables.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableMetadataGatewayFindAllTablesScenario {

    @Test
    @DisplayName("UTAPI-004798")
    void case_UTAPI_004798() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004798",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004798", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004798", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004798", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004798", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004798", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004798", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004798", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004798", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004798", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004798", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004798")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004799")
    void case_UTAPI_004799() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004799",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004799", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004799", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004799", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004799", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004799", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004799", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004799", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004799", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004799", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004799", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004799")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004800")
    void case_UTAPI_004800() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004800",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004800", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004800", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004800", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004800", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004800", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004800", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004800", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004800", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004800", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004800", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004800")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004801")
    void case_UTAPI_004801() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004801",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004801", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004801", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004801", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004801", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004801", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004801", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004801", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004801", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004801", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004801", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004801")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004802")
    void case_UTAPI_004802() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004802",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004802", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004802", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004802", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004802", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004802", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004802", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004802", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004802", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004802", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004802", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004802")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004803")
    void case_UTAPI_004803() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004803",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004803", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004803", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004803", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004803", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004803", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004803", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004803", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004803", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004803", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004803", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004803")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004804")
    void case_UTAPI_004804() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004804",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004804", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004804", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004804", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004804", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004804", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004804", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004804", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004804", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004804", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004804", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004804")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004805")
    void case_UTAPI_004805() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004805",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004805", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004805", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004805", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004805", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004805", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004805", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004805", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004805", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004805", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004805", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004805")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004806")
    void case_UTAPI_004806() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004806",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004806", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004806", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004806", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004806", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004806", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004806", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004806", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004806", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004806", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004806", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004806")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004807")
    void case_UTAPI_004807() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004807",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004807", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004807", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004807", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004807", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004807", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004807", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004807", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004807", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004807", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004807", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004807")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004808")
    void case_UTAPI_004808() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004808",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004808", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004808", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004808", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004808", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004808", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004808", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004808", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004808", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004808", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004808", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004808")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004809")
    void case_UTAPI_004809() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004809",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004809", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004809", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004809", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004809", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004809", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004809", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004809", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004809", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004809", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004809", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004809")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004810")
    void case_UTAPI_004810() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004810",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004810", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004810", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004810", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004810", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004810", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004810", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004810", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004810", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004810", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004810", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004810")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004811")
    void case_UTAPI_004811() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004811",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004811", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004811", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004811", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004811", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004811", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004811", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004811", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004811", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004811", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004811", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004811")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004812")
    void case_UTAPI_004812() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004812",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004812", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004812", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004812", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004812", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004812", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004812", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004812", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004812", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004812", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004812", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004812")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004813")
    void case_UTAPI_004813() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004813",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004813", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004813", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004813", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004813", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004813", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004813", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004813", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004813", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004813", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004813", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004813")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004814")
    void case_UTAPI_004814() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004814",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004814", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004814", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004814", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004814", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004814", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004814", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004814", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004814", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004814", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004814", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004814")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004815")
    void case_UTAPI_004815() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004815",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004815", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004815", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004815", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004815", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004815", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004815", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004815", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004815", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004815", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004815", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004815")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004816")
    void case_UTAPI_004816() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004816",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004816", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004816", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004816", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004816", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004816", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004816", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004816", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004816", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004816", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004816", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004816")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004817")
    void case_UTAPI_004817() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004817",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004817", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004817", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004817", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004817", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004817", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004817", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004817", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004817", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004817", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004817", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004817")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004818")
    void case_UTAPI_004818() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004818",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004818", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004818", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004818", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004818", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004818", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004818", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004818", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004818", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004818", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004818", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004818")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004819")
    void case_UTAPI_004819() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004819",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004819", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004819", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004819", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004819", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004819", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004819", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004819", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004819", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004819", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004819", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004819")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004820")
    void case_UTAPI_004820() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004820",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004820", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004820", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004820", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004820", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004820", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004820", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004820", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004820", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004820", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004820", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004820")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004821")
    void case_UTAPI_004821() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004821",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004821", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004821", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004821", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004821", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004821", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004821", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004821", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004821", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004821", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004821", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004821")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004822")
    void case_UTAPI_004822() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004822",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004822", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004822", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004822", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004822", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004822", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004822", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004822", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004822", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004822", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004822", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004822")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004823")
    void case_UTAPI_004823() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004823",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004823", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004823", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004823", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004823", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004823", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004823", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004823", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004823", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004823", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004823", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004823")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004824")
    void case_UTAPI_004824() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004824",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004824", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004824", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004824", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004824", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004824", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004824", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004824", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004824", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004824", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004824", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004824")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004825")
    void case_UTAPI_004825() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004825",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004825", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004825", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004825", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004825", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004825", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004825", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004825", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004825", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004825", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004825", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004825")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004826")
    void case_UTAPI_004826() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004826",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004826", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004826", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004826", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004826", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004826", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004826", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004826", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004826", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004826", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004826", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004826")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004827")
    void case_UTAPI_004827() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004827",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004827", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004827", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004827", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004827", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004827", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004827", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004827", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004827", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004827", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004827", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004827")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004828")
    void case_UTAPI_004828() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004828",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004828", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004828", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004828", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004828", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004828", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004828", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004828", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004828", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004828", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004828", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004828")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004829")
    void case_UTAPI_004829() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004829",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004829", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004829", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004829", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004829", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004829", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004829", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004829", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004829", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004829", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004829", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004829")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004830")
    void case_UTAPI_004830() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004830",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004830", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004830", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004830", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004830", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004830", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004830", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004830", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004830", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004830", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004830", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004830")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004831")
    void case_UTAPI_004831() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004831",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004831", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004831", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004831", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004831", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004831", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004831", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004831", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004831", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004831", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004831", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004831")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004832")
    void case_UTAPI_004832() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004832",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004832", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004832", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004832", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004832", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004832", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004832", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004832", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004832", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004832", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004832", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004832")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004833")
    void case_UTAPI_004833() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004833",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004833", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004833", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004833", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004833", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004833", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004833", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004833", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004833", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004833", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004833", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004833")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004834")
    void case_UTAPI_004834() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004834",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004834", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004834", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004834", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004834", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004834", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004834", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004834", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004834", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004834", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004834", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004834")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004835")
    void case_UTAPI_004835() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004835",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004835", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004835", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004835", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004835", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004835", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004835", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004835", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004835", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004835", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004835", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004835")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004836")
    void case_UTAPI_004836() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004836",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004836", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004836", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004836", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004836", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004836", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004836", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004836", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004836", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004836", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004836", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004836")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004837")
    void case_UTAPI_004837() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004837",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004837", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004837", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004837", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004837", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004837", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004837", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004837", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004837", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004837", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004837", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004837")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004838")
    void case_UTAPI_004838() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004838",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004838", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004838", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004838", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004838", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004838", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004838", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004838", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004838", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004838", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004838", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004838")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004839")
    void case_UTAPI_004839() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004839",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004839", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004839", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004839", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004839", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004839", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004839", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004839", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004839", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004839", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004839", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004839")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004840")
    void case_UTAPI_004840() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004840",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004840", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004840", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004840", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004840", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004840", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004840", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004840", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004840", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004840", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004840", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004840")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004841")
    void case_UTAPI_004841() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004841",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004841", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004841", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004841", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004841", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004841", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004841", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004841", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004841", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004841", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004841", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004841")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004842")
    void case_UTAPI_004842() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004842",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004842", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004842", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004842", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004842", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004842", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004842", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004842", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004842", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004842", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004842", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004842")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004843")
    void case_UTAPI_004843() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004843",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004843", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004843", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004843", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004843", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004843", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004843", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004843", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004843", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004843", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004843", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004843")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004844")
    void case_UTAPI_004844() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004844",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004844", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004844", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004844", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004844", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004844", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004844", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004844", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004844", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004844", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004844", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004844")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004845")
    void case_UTAPI_004845() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004845",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004845", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004845", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004845", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004845", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004845", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004845", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004845", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004845", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004845", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004845", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004845")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004846")
    void case_UTAPI_004846() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004846",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004846", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004846", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004846", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004846", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004846", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004846", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004846", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004846", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004846", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004846", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004846")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004847")
    void case_UTAPI_004847() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004847",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004847", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004847", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004847", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004847", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004847", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004847", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004847", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004847", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004847", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004847", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004847")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004848")
    void case_UTAPI_004848() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004848",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004848", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004848", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004848", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004848", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004848", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004848", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004848", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004848", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004848", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004848", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004848")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004849")
    void case_UTAPI_004849() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004849",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004849", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004849", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004849", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004849", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004849", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004849", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004849", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004849", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004849", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004849", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004849")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004850")
    void case_UTAPI_004850() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004850",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004850", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004850", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004850", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004850", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004850", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004850", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004850", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004850", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004850", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004850", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004850")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004851")
    void case_UTAPI_004851() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004851",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004851", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004851", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004851", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004851", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004851", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004851", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004851", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004851", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004851", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004851", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004851")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004852")
    void case_UTAPI_004852() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004852",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004852", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004852", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004852", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004852", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004852", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004852", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004852", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004852", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004852", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004852", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004852")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004853")
    void case_UTAPI_004853() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004853",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004853", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004853", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004853", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004853", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004853", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004853", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004853", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004853", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004853", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004853", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004853")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004854")
    void case_UTAPI_004854() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004854",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004854", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004854", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004854", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004854", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004854", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004854", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004854", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004854", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004854", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004854", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004854")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004855")
    void case_UTAPI_004855() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004855",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004855", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004855", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004855", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004855", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004855", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004855", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004855", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004855", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004855", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004855", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004855")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004856")
    void case_UTAPI_004856() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004856",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004856", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004856", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004856", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004856", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004856", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004856", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004856", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004856", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004856", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004856", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004856")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004857")
    void case_UTAPI_004857() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004857",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004857", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004857", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004857", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004857", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004857", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004857", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004857", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004857", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004857", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004857", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004857")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004858")
    void case_UTAPI_004858() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004858",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004858", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004858", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004858", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004858", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004858", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004858", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004858", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004858", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004858", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004858", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004858")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004859")
    void case_UTAPI_004859() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004859",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004859", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004859", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004859", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004859", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004859", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004859", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004859", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004859", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004859", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004859", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004859")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004860")
    void case_UTAPI_004860() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004860",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004860", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004860", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004860", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004860", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004860", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004860", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004860", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004860", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004860", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004860", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004860")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004861")
    void case_UTAPI_004861() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004861",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004861", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004861", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004861", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004861", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004861", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004861", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004861", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004861", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004861", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004861", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004861")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004862")
    void case_UTAPI_004862() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004862",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004862", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004862", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004862", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004862", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004862", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004862", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004862", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004862", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004862", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004862", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004862")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004863")
    void case_UTAPI_004863() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004863",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004863", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004863", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004863", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004863", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004863", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004863", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004863", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004863", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004863", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004863", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004863")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004864")
    void case_UTAPI_004864() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004864",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004864", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004864", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004864", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004864", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004864", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004864", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004864", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004864", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004864", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004864", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004864")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004865")
    void case_UTAPI_004865() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004865",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004865", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004865", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004865", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004865", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004865", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004865", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004865", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004865", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004865", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004865", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004865")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004866")
    void case_UTAPI_004866() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004866",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004866", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004866", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004866", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004866", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004866", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004866", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004866", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004866", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004866", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004866", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004866")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004867")
    void case_UTAPI_004867() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004867",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004867", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004867", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004867", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004867", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004867", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004867", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004867", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004867", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004867", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004867", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004867")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004868")
    void case_UTAPI_004868() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004868",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004868", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004868", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004868", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004868", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004868", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004868", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004868", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004868", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004868", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004868", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004868")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004869")
    void case_UTAPI_004869() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004869",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004869", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004869", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004869", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004869", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004869", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004869", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004869", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004869", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004869", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004869", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004869")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004870")
    void case_UTAPI_004870() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004870",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004870", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004870", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004870", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004870", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004870", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004870", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004870", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004870", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004870", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004870", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004870")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004871")
    void case_UTAPI_004871() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004871",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004871", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004871", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004871", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004871", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004871", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004871", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004871", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004871", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004871", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004871", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004871")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004872")
    void case_UTAPI_004872() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004872",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004872", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004872", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004872", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004872", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004872", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004872", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004872", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004872", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004872", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004872", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004872")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004873")
    void case_UTAPI_004873() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004873",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004873", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004873", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004873", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004873", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004873", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004873", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004873", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004873", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004873", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004873", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004873")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004874")
    void case_UTAPI_004874() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004874",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004874", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004874", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004874", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004874", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004874", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004874", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004874", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004874", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004874", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004874", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004874")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004875")
    void case_UTAPI_004875() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004875",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004875", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004875", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004875", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004875", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004875", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004875", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004875", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004875", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004875", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004875", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004875")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004876")
    void case_UTAPI_004876() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004876",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004876", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004876", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004876", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004876", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004876", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004876", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004876", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004876", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004876", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004876", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004876")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004877")
    void case_UTAPI_004877() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004877",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004877", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004877", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004877", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004877", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004877", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004877", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004877", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004877", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004877", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004877", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004877")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004878")
    void case_UTAPI_004878() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004878",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004878", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004878", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004878", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004878", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004878", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004878", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004878", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004878", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004878", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004878", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004878")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004879")
    void case_UTAPI_004879() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004879",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004879", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004879", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004879", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004879", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004879", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004879", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004879", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004879", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004879", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004879", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004879")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004880")
    void case_UTAPI_004880() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004880",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004880", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004880", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004880", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004880", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004880", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004880", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004880", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004880", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004880", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004880", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004880")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004881")
    void case_UTAPI_004881() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004881",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004881", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004881", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004881", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004881", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004881", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004881", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004881", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004881", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004881", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004881", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004881")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004882")
    void case_UTAPI_004882() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004882",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004882", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004882", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004882", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004882", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004882", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004882", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004882", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004882", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004882", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004882", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004882")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004883")
    void case_UTAPI_004883() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004883",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004883", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004883", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004883", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004883", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004883", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004883", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004883", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004883", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004883", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004883", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004883")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004884")
    void case_UTAPI_004884() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004884",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004884", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004884", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004884", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004884", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004884", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004884", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004884", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004884", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004884", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004884", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004884")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004885")
    void case_UTAPI_004885() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004885",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004885", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004885", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004885", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004885", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004885", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004885", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004885", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004885", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004885", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004885", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004885")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004886")
    void case_UTAPI_004886() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004886",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004886", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004886", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004886", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004886", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004886", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004886", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004886", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004886", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004886", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004886", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004886")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004887")
    void case_UTAPI_004887() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004887",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004887", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004887", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004887", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004887", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004887", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004887", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004887", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004887", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004887", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004887", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004887")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004888")
    void case_UTAPI_004888() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004888",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004888", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004888", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004888", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004888", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004888", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004888", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004888", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004888", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004888", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004888", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004888")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004889")
    void case_UTAPI_004889() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004889",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004889", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004889", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004889", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004889", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004889", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004889", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004889", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004889", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004889", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004889", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004889")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004890")
    void case_UTAPI_004890() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004890",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004890", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004890", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004890", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004890", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004890", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004890", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004890", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004890", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004890", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004890", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004890")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004891")
    void case_UTAPI_004891() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004891",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004891", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004891", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004891", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004891", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004891", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004891", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004891", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004891", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004891", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004891", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004891")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004892")
    void case_UTAPI_004892() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004892",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004892", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004892", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004892", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004892", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004892", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004892", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004892", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004892", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004892", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004892", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004892")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004893")
    void case_UTAPI_004893() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004893",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004893", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004893", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004893", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004893", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004893", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004893", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004893", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004893", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004893", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004893", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004893")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004894")
    void case_UTAPI_004894() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004894",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004894", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004894", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004894", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004894", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004894", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004894", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004894", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004894", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004894", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004894", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004894")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004895")
    void case_UTAPI_004895() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004895",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004895", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004895", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004895", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004895", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004895", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004895", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004895", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004895", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004895", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004895", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004895")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004896")
    void case_UTAPI_004896() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004896",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004896", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004896", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004896", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004896", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004896", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004896", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004896", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004896", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004896", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004896", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004896")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004897")
    void case_UTAPI_004897() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004897",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004897", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004897", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004897", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004897", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004897", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004897", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004897", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004897", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004897", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004897", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004897")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004898")
    void case_UTAPI_004898() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004898",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004898", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004898", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004898", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004898", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004898", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004898", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004898", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004898", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004898", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004898", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004898")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004899")
    void case_UTAPI_004899() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004899",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004899", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004899", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004899", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004899", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004899", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004899", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004899", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004899", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004899", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004899", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004899")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004900")
    void case_UTAPI_004900() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004900",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004900", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004900", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004900", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004900", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004900", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004900", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004900", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004900", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004900", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004900", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004900")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004901")
    void case_UTAPI_004901() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004901",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004901", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004901", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004901", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004901", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004901", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004901", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004901", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004901", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004901", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004901", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004901")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004902")
    void case_UTAPI_004902() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004902",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004902", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004902", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004902", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004902", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004902", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004902", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004902", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004902", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004902", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004902", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004902")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004903")
    void case_UTAPI_004903() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004903",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004903", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004903", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004903", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004903", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004903", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004903", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004903", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004903", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004903", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004903", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004903")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004904")
    void case_UTAPI_004904() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004904",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004904", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004904", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004904", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004904", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004904", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004904", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004904", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004904", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004904", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004904", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004904")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004905")
    void case_UTAPI_004905() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004905",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004905", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004905", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004905", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004905", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004905", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004905", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004905", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004905", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004905", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004905", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004905")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004906")
    void case_UTAPI_004906() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004906",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004906", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004906", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004906", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004906", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004906", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004906", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004906", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004906", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004906", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004906", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004906")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004907")
    void case_UTAPI_004907() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004907",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004907", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004907", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004907", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004907", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004907", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004907", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004907", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004907", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004907", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004907", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004907")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004908")
    void case_UTAPI_004908() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004908",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004908", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004908", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004908", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004908", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004908", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004908", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004908", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004908", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004908", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004908", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004908")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004909")
    void case_UTAPI_004909() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004909",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004909", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004909", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004909", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004909", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004909", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004909", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004909", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004909", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004909", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004909", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004909")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004910")
    void case_UTAPI_004910() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004910",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004910", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004910", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004910", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004910", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004910", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004910", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004910", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004910", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004910", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004910", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004910")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004911")
    void case_UTAPI_004911() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004911",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004911", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004911", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004911", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004911", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004911", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004911", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004911", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004911", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004911", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004911", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004911")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004912")
    void case_UTAPI_004912() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004912",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004912", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004912", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004912", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004912", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004912", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004912", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004912", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004912", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004912", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004912", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004912")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004913")
    void case_UTAPI_004913() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004913",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004913", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004913", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004913", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004913", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004913", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004913", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004913", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004913", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004913", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004913", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004913")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004914")
    void case_UTAPI_004914() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004914",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004914", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004914", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004914", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004914", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004914", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004914", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004914", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004914", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004914", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004914", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004914")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004915")
    void case_UTAPI_004915() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004915",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004915", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004915", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004915", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004915", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004915", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004915", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004915", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004915", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004915", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004915", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004915")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004916")
    void case_UTAPI_004916() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004916",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004916", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004916", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004916", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004916", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004916", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004916", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004916", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004916", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004916", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004916", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004916")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004917")
    void case_UTAPI_004917() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004917",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004917", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004917", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004917", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004917", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004917", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004917", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004917", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004917", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004917", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004917", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004917")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004918")
    void case_UTAPI_004918() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004918",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004918", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004918", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004918", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004918", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004918", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004918", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004918", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004918", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004918", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004918", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004918")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004919")
    void case_UTAPI_004919() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004919",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004919", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004919", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004919", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004919", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004919", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004919", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004919", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004919", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004919", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004919", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004919")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004920")
    void case_UTAPI_004920() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004920",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004920", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004920", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004920", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004920", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004920", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004920", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004920", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004920", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004920", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004920", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004920")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004921")
    void case_UTAPI_004921() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004921",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004921", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004921", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004921", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004921", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004921", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004921", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004921", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004921", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004921", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004921", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004921")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004922")
    void case_UTAPI_004922() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004922",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004922", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004922", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004922", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004922", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004922", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004922", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004922", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004922", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004922", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004922", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004922")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004923")
    void case_UTAPI_004923() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004923",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004923", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004923", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004923", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004923", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004923", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004923", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004923", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004923", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004923", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004923", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004923")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004924")
    void case_UTAPI_004924() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004924",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004924", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004924", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004924", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004924", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004924", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004924", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004924", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004924", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004924", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004924", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004924")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004925")
    void case_UTAPI_004925() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004925",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004925", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004925", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004925", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004925", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004925", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004925", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004925", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004925", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004925", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004925", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004925")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004926")
    void case_UTAPI_004926() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004926",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004926", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004926", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004926", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004926", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004926", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004926", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004926", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004926", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004926", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004926", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004926")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004927")
    void case_UTAPI_004927() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004927",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004927", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004927", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004927", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004927", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004927", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004927", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004927", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004927", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004927", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004927", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004927")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004928")
    void case_UTAPI_004928() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004928",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004928", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004928", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004928", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004928", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004928", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004928", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004928", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004928", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004928", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004928", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004928")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004929")
    void case_UTAPI_004929() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004929",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004929", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004929", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004929", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004929", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004929", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004929", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004929", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004929", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004929", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004929", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004929")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004930")
    void case_UTAPI_004930() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004930",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004930", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004930", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004930", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004930", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004930", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004930", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004930", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004930", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004930", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004930", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004930")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004931")
    void case_UTAPI_004931() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004931",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004931", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004931", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004931", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004931", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004931", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004931", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004931", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004931", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004931", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004931", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004931")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004932")
    void case_UTAPI_004932() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004932",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004932", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004932", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004932", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004932", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004932", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004932", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004932", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004932", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004932", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004932", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004932")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004933")
    void case_UTAPI_004933() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004933",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004933", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004933", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004933", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004933", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004933", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004933", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004933", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004933", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004933", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004933", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004933")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004934")
    void case_UTAPI_004934() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004934",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004934", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004934", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004934", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004934", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004934", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004934", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004934", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004934", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004934", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004934", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004934")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004935")
    void case_UTAPI_004935() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004935",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004935", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004935", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004935", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004935", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004935", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004935", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004935", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004935", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004935", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004935", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004935")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004936")
    void case_UTAPI_004936() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004936",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004936", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004936", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004936", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004936", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004936", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004936", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004936", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004936", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004936", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004936", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004936")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004937")
    void case_UTAPI_004937() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004937",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004937", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004937", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004937", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004937", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004937", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004937", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004937", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004937", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004937", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004937", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004937")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004938")
    void case_UTAPI_004938() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004938",
                "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004938", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004938", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004938", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004938", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004938", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004938", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004938", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004938", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004938", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004938", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004938")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMetadataGateway.java::TableMetadataGateway::findAllTables::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataGatewayWrapper());
    }

}

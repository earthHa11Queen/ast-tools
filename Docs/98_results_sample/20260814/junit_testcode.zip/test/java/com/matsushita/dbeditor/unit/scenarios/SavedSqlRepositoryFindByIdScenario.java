package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.SavedSqlRepositoryWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for SavedSqlRepository#findById.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class SavedSqlRepositoryFindByIdScenario {

    @Test
    @DisplayName("UTAPI-007110")
    void case_UTAPI_007110() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007110",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "findById",
                "Optional<SavedSql>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007110", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007110")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::findById::2::ARG::1::-::n")
                    .mirror("-", "1:length_null", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007111")
    void case_UTAPI_007111() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007111",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "findById",
                "Optional<SavedSql>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007111", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007111")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::findById::2::ARG::1::-::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007112")
    void case_UTAPI_007112() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007112",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "findById",
                "Optional<SavedSql>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007112", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007112")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::findById::2::ARG::1::-::n")
                    .mirror("-", "3:length_min", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007113")
    void case_UTAPI_007113() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007113",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "findById",
                "Optional<SavedSql>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007113", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007113")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::findById::2::ARG::1::-::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007114")
    void case_UTAPI_007114() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007114",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "findById",
                "Optional<SavedSql>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007114", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007114")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::findById::2::ARG::1::-::n")
                    .mirror("-", "5:length_max", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007115")
    void case_UTAPI_007115() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007115",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "findById",
                "Optional<SavedSql>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007115", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007115")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::findById::2::ARG::1::-::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007116")
    void case_UTAPI_007116() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007116",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "findById",
                "Optional<SavedSql>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007116", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007116")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::findById::2::ARG::1::-::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007117")
    void case_UTAPI_007117() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007117",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "findById",
                "Optional<SavedSql>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007117", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007117")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::findById::2::ARG::1::-::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007118")
    void case_UTAPI_007118() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007118",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "findById",
                "Optional<SavedSql>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007118", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007118")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::findById::2::ARG::1::-::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007119")
    void case_UTAPI_007119() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007119",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "findById",
                "Optional<SavedSql>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007119", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007119")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::findById::2::ARG::1::-::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007120")
    void case_UTAPI_007120() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007120",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "findById",
                "Optional<SavedSql>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007120", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007120")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::findById::2::ARG::1::-::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

}

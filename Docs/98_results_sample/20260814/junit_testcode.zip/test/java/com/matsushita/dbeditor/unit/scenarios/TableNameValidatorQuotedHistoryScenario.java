package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableNameValidatorWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableNameValidator#quotedHistory.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableNameValidatorQuotedHistoryScenario {

    @Test
    @DisplayName("UTAPI-010946")
    void case_UTAPI_010946() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010946",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010946", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010946", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010946", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010946")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::1::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the outcome of quotedHistory for an absent or empty identifier")
                    .expected("the composition rejects the identifier as an invalid argument")
                    .failure("an absent or empty identifier is composed into a statement fragment")
                    .assertion("assertThrows(IllegalArgumentException.class, ...)")
                    .check(CheckType.EXCEPTION_REQUIRED, "an absent or empty identifier can never match the declared identifier pattern", "java.lang.IllegalArgumentException", "data:schemaName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010947")
    void case_UTAPI_010947() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010947",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010947", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010947", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010947", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010947")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::1::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the outcome of quotedHistory for an absent or empty identifier")
                    .expected("the composition rejects the identifier as an invalid argument")
                    .failure("an absent or empty identifier is composed into a statement fragment")
                    .assertion("assertThrows(IllegalArgumentException.class, ...)")
                    .check(CheckType.EXCEPTION_REQUIRED, "an absent or empty identifier can never match the declared identifier pattern", "java.lang.IllegalArgumentException", "data:schemaName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010948")
    void case_UTAPI_010948() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010948",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010948", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010948", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010948", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010948")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::1::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010949")
    void case_UTAPI_010949() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010949",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010949", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010949", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010949", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010949")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::1::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010950")
    void case_UTAPI_010950() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010950",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010950", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010950", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010950", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010950")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::1::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010951")
    void case_UTAPI_010951() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010951",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010951", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010951", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010951", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010951")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::1::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010952")
    void case_UTAPI_010952() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010952",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010952", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010952", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010952", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010952")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::1::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010953")
    void case_UTAPI_010953() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010953",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010953", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010953", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010953", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010953")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::1::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010954")
    void case_UTAPI_010954() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010954",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010954", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010954", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010954", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010954")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::1::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010955")
    void case_UTAPI_010955() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010955",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010955", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010955", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010955", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010955")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::1::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010956")
    void case_UTAPI_010956() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010956",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010956", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010956", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010956", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010956")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::1::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010957")
    void case_UTAPI_010957() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010957",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010957", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010957", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010957", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010957")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::1::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010958")
    void case_UTAPI_010958() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010958",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010958", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010958", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010958", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010958")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::1::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010959")
    void case_UTAPI_010959() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010959",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010959", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010959", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010959", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010959")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::1::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010960")
    void case_UTAPI_010960() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010960",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010960", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010960", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010960", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010960")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::1::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010961")
    void case_UTAPI_010961() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010961",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010961", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010961", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010961", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010961")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::1::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010962")
    void case_UTAPI_010962() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010962",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010962", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010962", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010962", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010962")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::1::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010963")
    void case_UTAPI_010963() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010963",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010963", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010963", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010963", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010963")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::1::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010964")
    void case_UTAPI_010964() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010964",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010964", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010964", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010964", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010964")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::1::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010965")
    void case_UTAPI_010965() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010965",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010965", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010965", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010965", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010965")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::1::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010966")
    void case_UTAPI_010966() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010966",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010966", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010966", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010966", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010966")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::1::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010967")
    void case_UTAPI_010967() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010967",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010967", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010967", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010967", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010967")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::2::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the outcome of quotedHistory for an absent or empty identifier")
                    .expected("the composition rejects the identifier as an invalid argument")
                    .failure("an absent or empty identifier is composed into a statement fragment")
                    .assertion("assertThrows(IllegalArgumentException.class, ...)")
                    .check(CheckType.EXCEPTION_REQUIRED, "an absent or empty identifier can never match the declared identifier pattern", "java.lang.IllegalArgumentException", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010968")
    void case_UTAPI_010968() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010968",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010968", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010968", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010968", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010968")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::2::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the outcome of quotedHistory for an absent or empty identifier")
                    .expected("the composition rejects the identifier as an invalid argument")
                    .failure("an absent or empty identifier is composed into a statement fragment")
                    .assertion("assertThrows(IllegalArgumentException.class, ...)")
                    .check(CheckType.EXCEPTION_REQUIRED, "an absent or empty identifier can never match the declared identifier pattern", "java.lang.IllegalArgumentException", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010969")
    void case_UTAPI_010969() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010969",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010969", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010969", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010969", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010969")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::2::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010970")
    void case_UTAPI_010970() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010970",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010970", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010970", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010970", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010970")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::2::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010971")
    void case_UTAPI_010971() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010971",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010971", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010971", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010971", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010971")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::2::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010972")
    void case_UTAPI_010972() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010972",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010972", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010972", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010972", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010972")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::2::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010973")
    void case_UTAPI_010973() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010973",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010973", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010973", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010973", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010973")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::2::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010974")
    void case_UTAPI_010974() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010974",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010974", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010974", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010974", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010974")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::2::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010975")
    void case_UTAPI_010975() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010975",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010975", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010975", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010975", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010975")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::2::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010976")
    void case_UTAPI_010976() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010976",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010976", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010976", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010976", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010976")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::2::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010977")
    void case_UTAPI_010977() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010977",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010977", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010977", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010977", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010977")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::2::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010978")
    void case_UTAPI_010978() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010978",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010978", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010978", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010978", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010978")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::2::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010979")
    void case_UTAPI_010979() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010979",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010979", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010979", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010979", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010979")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::2::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010980")
    void case_UTAPI_010980() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010980",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010980", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010980", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010980", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010980")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::2::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010981")
    void case_UTAPI_010981() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010981",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010981", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010981", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010981", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010981")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::2::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010982")
    void case_UTAPI_010982() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010982",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010982", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010982", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010982", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010982")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::2::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010983")
    void case_UTAPI_010983() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010983",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010983", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010983", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010983", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010983")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::2::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010984")
    void case_UTAPI_010984() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010984",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010984", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010984", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010984", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010984")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::2::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010985")
    void case_UTAPI_010985() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010985",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010985", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010985", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010985", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010985")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::2::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010986")
    void case_UTAPI_010986() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010986",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010986", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010986", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010986", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010986")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::2::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010987")
    void case_UTAPI_010987() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010987",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010987", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010987", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010987", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010987")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::2::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010988")
    void case_UTAPI_010988() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010988",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010988", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010988", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010988", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010988")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::3::-::seq")
                    .mirror("-", "1:length_null", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .check(CheckType.SENSITIVE_TO_ARG, "the composed identifier must depend on the sequence number", "2", "data:seq")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010989")
    void case_UTAPI_010989() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010989",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010989", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010989", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010989", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010989")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::3::-::seq")
                    .mirror("-", "2:length_empty", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .check(CheckType.SENSITIVE_TO_ARG, "the composed identifier must depend on the sequence number", "2", "data:seq")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010990")
    void case_UTAPI_010990() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010990",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010990", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010990", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010990", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010990")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::3::-::seq")
                    .mirror("-", "3:length_min", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .check(CheckType.SENSITIVE_TO_ARG, "the composed identifier must depend on the sequence number", "2", "data:seq")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010991")
    void case_UTAPI_010991() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010991",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010991", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010991", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010991", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010991")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::3::-::seq")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .check(CheckType.SENSITIVE_TO_ARG, "the composed identifier must depend on the sequence number", "2", "data:seq")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010992")
    void case_UTAPI_010992() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010992",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010992", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010992", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010992", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010992")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::3::-::seq")
                    .mirror("-", "5:length_max", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .check(CheckType.SENSITIVE_TO_ARG, "the composed identifier must depend on the sequence number", "2", "data:seq")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010993")
    void case_UTAPI_010993() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010993",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010993", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010993", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010993", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010993")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::3::-::seq")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .check(CheckType.SENSITIVE_TO_ARG, "the composed identifier must depend on the sequence number", "2", "data:seq")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010994")
    void case_UTAPI_010994() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010994",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010994", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010994", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010994", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010994")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::3::-::seq")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .check(CheckType.SENSITIVE_TO_ARG, "the composed identifier must depend on the sequence number", "2", "data:seq")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010995")
    void case_UTAPI_010995() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010995",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010995", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010995", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010995", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010995")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::3::-::seq")
                    .mirror("46:hw_integer", "-", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .check(CheckType.SENSITIVE_TO_ARG, "the composed identifier must depend on the sequence number", "2", "data:seq")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010996")
    void case_UTAPI_010996() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010996",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010996", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010996", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010996", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010996")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::3::-::seq")
                    .mirror("-", "-", "12:integer_positive")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .check(CheckType.SENSITIVE_TO_ARG, "the composed identifier must depend on the sequence number", "2", "data:seq")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010997")
    void case_UTAPI_010997() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010997",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010997", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010997", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010997", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010997")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::3::-::seq")
                    .mirror("-", "-", "13:integer_negative")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .check(CheckType.SENSITIVE_TO_ARG, "the composed identifier must depend on the sequence number", "2", "data:seq")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010998")
    void case_UTAPI_010998() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010998",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedHistory",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010998", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010998", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010998", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010998")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedHistory::8::ARG::3::-::seq")
                    .mirror("-", "-", "14:integer_zero")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedHistory")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .check(CheckType.SENSITIVE_TO_ARG, "the composed identifier must depend on the sequence number", "2", "data:seq")
                    .build()),
            new TableNameValidatorWrapper());
    }

}

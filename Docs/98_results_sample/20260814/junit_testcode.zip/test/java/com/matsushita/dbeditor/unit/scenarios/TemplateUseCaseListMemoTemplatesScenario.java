package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TemplateUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TemplateUseCase#listMemoTemplates.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TemplateUseCaseListMemoTemplatesScenario {

    @Test
    @DisplayName("UTAPI-012767")
    void case_UTAPI_012767() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012767",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "listMemoTemplates",
                "List<TemplateResponse>",
                new ParamSpec[] {},
                new DataRef[] {},
                OraclePlan.builder("UTAPI-012767")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::listMemoTemplates::1::METHOD::-1::-::-")
                    .mirror("-", "-", "-")
                    .target("-", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.findAll")
                    .expected("the value generated for - is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.findAll", "memoTemplateRepository", "findAll")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.RETURN_COLLECTION_SIZE_MATCHES_STUB, "the result must hold exactly what memoTemplateRepository.findAll returned", "memoTemplateRepository", "findAll")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

}

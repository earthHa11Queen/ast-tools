package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.SqlControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for SqlController#uploadSql.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class SqlControllerUploadSqlScenario {

    @Test
    @DisplayName("UTAPI-001095")
    void case_UTAPI_001095() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001095",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "uploadSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001095", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-001095", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001095")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::uploadSql::5::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.uploadSql")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.uploadSql", "sqlUseCase", "uploadSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.uploadSql must carry the value generated for connectionId", "sqlUseCase", "uploadSql", "0", "data:connectionId")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_EQUALS, "the uploaded file name must be handed to the use case", "sqlUseCase", "uploadSql", "1", "text:fixture.csv")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001096")
    void case_UTAPI_001096() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001096",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "uploadSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001096", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-001096", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001096")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::uploadSql::5::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.uploadSql")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.uploadSql", "sqlUseCase", "uploadSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.uploadSql must carry the value generated for connectionId", "sqlUseCase", "uploadSql", "0", "data:connectionId")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_EQUALS, "the uploaded file name must be handed to the use case", "sqlUseCase", "uploadSql", "1", "text:fixture.csv")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001097")
    void case_UTAPI_001097() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001097",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "uploadSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001097", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-001097", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001097")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::uploadSql::5::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.uploadSql")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.uploadSql", "sqlUseCase", "uploadSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.uploadSql must carry the value generated for connectionId", "sqlUseCase", "uploadSql", "0", "data:connectionId")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_EQUALS, "the uploaded file name must be handed to the use case", "sqlUseCase", "uploadSql", "1", "text:fixture.csv")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001098")
    void case_UTAPI_001098() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001098",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "uploadSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001098", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-001098", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001098")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::uploadSql::5::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.uploadSql")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.uploadSql", "sqlUseCase", "uploadSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.uploadSql must carry the value generated for connectionId", "sqlUseCase", "uploadSql", "0", "data:connectionId")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_EQUALS, "the uploaded file name must be handed to the use case", "sqlUseCase", "uploadSql", "1", "text:fixture.csv")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001099")
    void case_UTAPI_001099() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001099",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "uploadSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001099", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-001099", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001099")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::uploadSql::5::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.uploadSql")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.uploadSql", "sqlUseCase", "uploadSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.uploadSql must carry the value generated for connectionId", "sqlUseCase", "uploadSql", "0", "data:connectionId")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_EQUALS, "the uploaded file name must be handed to the use case", "sqlUseCase", "uploadSql", "1", "text:fixture.csv")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001100")
    void case_UTAPI_001100() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001100",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "uploadSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001100", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-001100", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001100")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::uploadSql::5::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.uploadSql")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.uploadSql", "sqlUseCase", "uploadSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.uploadSql must carry the value generated for connectionId", "sqlUseCase", "uploadSql", "0", "data:connectionId")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_EQUALS, "the uploaded file name must be handed to the use case", "sqlUseCase", "uploadSql", "1", "text:fixture.csv")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001101")
    void case_UTAPI_001101() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001101",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "uploadSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001101", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-001101", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001101")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::uploadSql::5::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.uploadSql")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.uploadSql", "sqlUseCase", "uploadSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.uploadSql must carry the value generated for connectionId", "sqlUseCase", "uploadSql", "0", "data:connectionId")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_EQUALS, "the uploaded file name must be handed to the use case", "sqlUseCase", "uploadSql", "1", "text:fixture.csv")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001102")
    void case_UTAPI_001102() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001102",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "uploadSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001102", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-001102", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001102")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::uploadSql::5::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.uploadSql")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.uploadSql", "sqlUseCase", "uploadSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.uploadSql must carry the value generated for connectionId", "sqlUseCase", "uploadSql", "0", "data:connectionId")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_EQUALS, "the uploaded file name must be handed to the use case", "sqlUseCase", "uploadSql", "1", "text:fixture.csv")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001103")
    void case_UTAPI_001103() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001103",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "uploadSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001103", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-001103", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001103")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::uploadSql::5::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.uploadSql")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.uploadSql", "sqlUseCase", "uploadSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.uploadSql must carry the value generated for connectionId", "sqlUseCase", "uploadSql", "0", "data:connectionId")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_EQUALS, "the uploaded file name must be handed to the use case", "sqlUseCase", "uploadSql", "1", "text:fixture.csv")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001104")
    void case_UTAPI_001104() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001104",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "uploadSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001104", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-001104", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001104")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::uploadSql::5::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.uploadSql")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.uploadSql", "sqlUseCase", "uploadSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.uploadSql must carry the value generated for connectionId", "sqlUseCase", "uploadSql", "0", "data:connectionId")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_EQUALS, "the uploaded file name must be handed to the use case", "sqlUseCase", "uploadSql", "1", "text:fixture.csv")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001105")
    void case_UTAPI_001105() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001105",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "uploadSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001105", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-001105", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001105")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::uploadSql::5::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.uploadSql")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.uploadSql", "sqlUseCase", "uploadSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.uploadSql must carry the value generated for connectionId", "sqlUseCase", "uploadSql", "0", "data:connectionId")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_EQUALS, "the uploaded file name must be handed to the use case", "sqlUseCase", "uploadSql", "1", "text:fixture.csv")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001106")
    void case_UTAPI_001106() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001106",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "uploadSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001106", "file", "TARGET", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-001106", "connectionId", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001106")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::uploadSql::5::ARG::2::-::file")
                    .mirror("-", "1:length_null", "-")
                    .target("file", "file")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.uploadSql")
                    .expected("the value generated for file is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_REQUIRED, "an absent upload cannot be processed", "java.lang.RuntimeException", "data:file")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001107")
    void case_UTAPI_001107() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001107",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "uploadSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001107", "file", "TARGET", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-001107", "connectionId", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001107")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::uploadSql::5::ARG::2::-::file")
                    .mirror("-", "2:length_empty", "-")
                    .target("file", "file")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.uploadSql")
                    .expected("the value generated for file is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.uploadSql", "sqlUseCase", "uploadSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.uploadSql must carry the value generated for connectionId", "sqlUseCase", "uploadSql", "0", "data:connectionId")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SAME, "the uploaded document must be handed on as it was received", "sqlUseCase", "uploadSql", "0", "data:file")
                    .build()),
            new SqlControllerWrapper());
    }

}

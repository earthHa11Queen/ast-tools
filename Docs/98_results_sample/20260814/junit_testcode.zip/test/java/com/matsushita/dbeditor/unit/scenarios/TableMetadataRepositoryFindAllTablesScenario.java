package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableMetadataRepositoryWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableMetadataRepository#findAllTables.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableMetadataRepositoryFindAllTablesScenario {

    @Test
    @DisplayName("UTAPI-008887")
    void case_UTAPI_008887() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008887",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008887", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008887", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008887", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008887", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008887", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008887", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008887", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008887", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008887", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008887", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008887")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008888")
    void case_UTAPI_008888() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008888",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008888", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008888", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008888", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008888", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008888", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008888", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008888", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008888", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008888", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008888", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008888")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008889")
    void case_UTAPI_008889() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008889",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008889", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008889", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008889", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008889", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008889", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008889", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008889", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008889", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008889", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008889", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008889")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008890")
    void case_UTAPI_008890() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008890",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008890", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008890", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008890", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008890", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008890", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008890", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008890", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008890", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008890", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008890", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008890")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008891")
    void case_UTAPI_008891() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008891",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008891", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008891", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008891", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008891", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008891", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008891", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008891", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008891", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008891", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008891", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008891")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008892")
    void case_UTAPI_008892() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008892",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008892", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008892", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008892", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008892", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008892", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008892", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008892", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008892", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008892", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008892", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008892")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008893")
    void case_UTAPI_008893() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008893",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008893", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008893", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008893", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008893", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008893", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008893", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008893", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008893", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008893", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008893", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008893")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008894")
    void case_UTAPI_008894() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008894",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008894", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008894", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008894", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008894", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008894", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008894", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008894", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008894", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008894", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008894", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008894")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008895")
    void case_UTAPI_008895() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008895",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008895", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008895", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008895", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008895", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008895", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008895", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008895", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008895", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008895", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008895", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008895")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008896")
    void case_UTAPI_008896() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008896",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008896", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008896", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008896", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008896", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008896", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008896", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008896", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008896", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008896", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008896", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008896")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008897")
    void case_UTAPI_008897() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008897",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008897", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008897", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008897", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008897", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008897", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008897", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008897", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008897", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008897", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008897", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008897")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008898")
    void case_UTAPI_008898() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008898",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008898", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008898", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008898", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008898", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008898", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008898", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008898", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008898", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008898", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008898", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008898")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008899")
    void case_UTAPI_008899() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008899",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008899", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008899", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008899", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008899", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008899", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008899", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008899", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008899", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008899", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008899", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008899")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008900")
    void case_UTAPI_008900() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008900",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008900", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008900", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008900", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008900", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008900", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008900", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008900", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008900", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008900", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008900", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008900")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008901")
    void case_UTAPI_008901() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008901",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008901", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008901", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008901", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008901", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008901", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008901", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008901", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008901", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008901", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008901", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008901")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008902")
    void case_UTAPI_008902() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008902",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008902", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008902", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008902", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008902", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008902", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008902", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008902", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008902", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008902", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008902", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008902")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008903")
    void case_UTAPI_008903() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008903",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008903", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008903", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008903", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008903", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008903", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008903", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008903", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008903", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008903", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008903", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008903")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008904")
    void case_UTAPI_008904() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008904",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008904", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008904", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008904", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008904", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008904", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008904", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008904", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008904", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008904", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008904", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008904")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008905")
    void case_UTAPI_008905() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008905",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008905", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008905", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008905", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008905", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008905", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008905", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008905", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008905", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008905", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008905", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008905")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008906")
    void case_UTAPI_008906() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008906",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008906", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008906", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008906", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008906", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008906", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008906", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008906", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008906", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008906", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008906", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008906")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008907")
    void case_UTAPI_008907() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008907",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008907", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008907", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008907", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008907", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008907", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008907", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008907", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008907", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008907", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008907", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008907")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008908")
    void case_UTAPI_008908() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008908",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008908", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008908", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008908", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008908", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008908", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008908", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008908", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008908", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008908", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008908", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008908")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008909")
    void case_UTAPI_008909() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008909",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008909", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008909", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008909", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008909", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008909", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008909", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008909", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008909", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008909", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008909", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008909")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008910")
    void case_UTAPI_008910() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008910",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008910", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008910", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008910", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008910", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008910", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008910", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008910", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008910", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008910", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008910", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008910")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008911")
    void case_UTAPI_008911() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008911",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008911", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008911", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008911", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008911", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008911", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008911", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008911", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008911", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008911", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008911", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008911")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008912")
    void case_UTAPI_008912() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008912",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008912", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008912", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008912", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008912", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008912", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008912", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008912", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008912", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008912", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008912", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008912")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008913")
    void case_UTAPI_008913() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008913",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008913", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008913", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008913", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008913", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008913", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008913", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008913", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008913", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008913", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008913", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008913")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008914")
    void case_UTAPI_008914() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008914",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008914", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008914", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008914", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008914", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008914", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008914", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008914", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008914", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008914", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008914", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008914")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008915")
    void case_UTAPI_008915() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008915",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008915", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008915", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008915", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008915", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008915", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008915", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008915", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008915", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008915", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008915", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008915")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008916")
    void case_UTAPI_008916() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008916",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008916", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008916", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008916", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008916", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008916", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008916", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008916", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008916", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008916", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008916", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008916")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008917")
    void case_UTAPI_008917() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008917",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008917", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008917", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008917", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008917", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008917", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008917", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008917", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008917", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008917", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008917", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008917")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008918")
    void case_UTAPI_008918() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008918",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008918", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008918", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008918", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008918", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008918", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008918", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008918", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008918", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008918", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008918", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008918")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008919")
    void case_UTAPI_008919() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008919",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008919", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008919", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008919", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008919", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008919", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008919", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008919", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008919", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008919", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008919", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008919")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008920")
    void case_UTAPI_008920() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008920",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008920", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008920", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008920", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008920", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008920", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008920", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008920", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008920", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008920", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008920", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008920")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008921")
    void case_UTAPI_008921() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008921",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008921", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008921", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008921", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008921", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008921", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008921", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008921", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008921", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008921", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008921", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008921")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008922")
    void case_UTAPI_008922() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008922",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008922", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008922", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008922", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008922", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008922", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008922", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008922", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008922", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008922", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008922", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008922")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008923")
    void case_UTAPI_008923() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008923",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008923", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008923", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008923", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008923", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008923", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008923", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008923", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008923", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008923", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008923", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008923")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008924")
    void case_UTAPI_008924() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008924",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008924", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008924", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008924", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008924", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008924", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008924", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008924", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008924", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008924", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008924", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008924")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008925")
    void case_UTAPI_008925() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008925",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008925", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008925", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008925", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008925", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008925", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008925", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008925", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008925", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008925", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008925", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008925")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008926")
    void case_UTAPI_008926() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008926",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008926", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008926", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008926", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008926", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008926", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008926", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008926", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008926", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008926", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008926", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008926")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008927")
    void case_UTAPI_008927() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008927",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008927", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008927", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008927", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008927", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008927", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008927", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008927", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008927", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008927", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008927", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008927")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008928")
    void case_UTAPI_008928() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008928",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008928", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008928", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008928", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008928", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008928", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008928", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008928", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008928", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008928", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008928", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008928")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008929")
    void case_UTAPI_008929() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008929",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008929", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008929", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008929", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008929", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008929", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008929", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008929", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008929", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008929", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008929", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008929")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008930")
    void case_UTAPI_008930() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008930",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008930", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008930", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008930", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008930", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008930", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008930", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008930", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008930", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008930", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008930", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008930")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008931")
    void case_UTAPI_008931() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008931",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008931", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008931", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008931", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008931", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008931", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008931", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008931", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008931", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008931", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008931", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008931")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008932")
    void case_UTAPI_008932() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008932",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008932", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008932", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008932", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008932", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008932", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008932", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008932", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008932", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008932", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008932", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008932")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008933")
    void case_UTAPI_008933() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008933",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008933", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008933", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008933", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008933", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008933", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008933", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008933", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008933", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008933", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008933", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008933")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008934")
    void case_UTAPI_008934() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008934",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008934", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008934", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008934", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008934", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008934", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008934", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008934", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008934", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008934", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008934", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008934")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008935")
    void case_UTAPI_008935() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008935",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008935", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008935", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008935", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008935", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008935", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008935", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008935", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008935", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008935", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008935", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008935")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008936")
    void case_UTAPI_008936() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008936",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008936", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008936", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008936", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008936", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008936", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008936", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008936", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008936", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008936", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008936", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008936")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008937")
    void case_UTAPI_008937() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008937",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008937", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008937", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008937", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008937", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008937", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008937", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008937", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008937", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008937", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008937", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008937")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008938")
    void case_UTAPI_008938() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008938",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008938", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008938", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008938", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008938", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008938", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008938", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008938", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008938", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008938", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008938", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008938")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008939")
    void case_UTAPI_008939() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008939",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008939", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008939", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008939", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008939", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008939", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008939", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008939", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008939", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008939", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008939", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008939")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008940")
    void case_UTAPI_008940() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008940",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008940", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008940", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008940", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008940", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008940", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008940", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008940", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008940", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008940", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008940", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008940")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008941")
    void case_UTAPI_008941() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008941",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008941", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008941", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008941", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008941", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008941", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008941", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008941", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008941", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008941", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008941", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008941")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008942")
    void case_UTAPI_008942() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008942",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008942", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008942", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008942", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008942", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008942", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008942", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008942", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008942", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008942", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008942", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008942")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008943")
    void case_UTAPI_008943() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008943",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008943", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008943", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008943", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008943", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008943", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008943", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008943", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008943", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008943", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008943", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008943")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008944")
    void case_UTAPI_008944() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008944",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008944", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008944", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008944", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008944", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008944", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008944", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008944", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008944", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008944", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008944", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008944")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008945")
    void case_UTAPI_008945() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008945",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008945", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008945", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008945", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008945", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008945", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008945", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008945", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008945", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008945", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008945", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008945")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008946")
    void case_UTAPI_008946() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008946",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008946", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008946", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008946", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008946", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008946", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008946", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008946", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008946", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008946", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008946", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008946")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008947")
    void case_UTAPI_008947() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008947",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008947", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008947", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008947", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008947", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008947", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008947", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008947", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008947", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008947", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008947", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008947")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008948")
    void case_UTAPI_008948() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008948",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008948", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008948", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008948", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008948", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008948", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008948", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008948", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008948", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008948", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008948", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008948")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008949")
    void case_UTAPI_008949() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008949",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008949", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008949", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008949", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008949", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008949", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008949", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008949", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008949", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008949", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008949", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008949")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008950")
    void case_UTAPI_008950() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008950",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008950", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008950", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008950", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008950", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008950", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008950", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008950", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008950", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008950", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008950", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008950")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008951")
    void case_UTAPI_008951() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008951",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008951", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008951", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008951", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008951", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008951", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008951", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008951", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008951", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008951", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008951", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008951")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008952")
    void case_UTAPI_008952() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008952",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008952", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008952", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008952", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008952", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008952", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008952", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008952", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008952", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008952", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008952", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008952")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008953")
    void case_UTAPI_008953() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008953",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008953", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008953", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008953", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008953", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008953", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008953", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008953", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008953", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008953", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008953", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008953")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008954")
    void case_UTAPI_008954() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008954",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008954", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008954", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008954", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008954", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008954", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008954", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008954", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008954", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008954", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008954", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008954")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008955")
    void case_UTAPI_008955() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008955",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008955", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008955", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008955", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008955", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008955", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008955", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008955", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008955", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008955", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008955", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008955")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008956")
    void case_UTAPI_008956() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008956",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008956", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008956", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008956", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008956", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008956", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008956", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008956", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008956", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008956", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008956", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008956")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008957")
    void case_UTAPI_008957() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008957",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008957", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008957", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008957", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008957", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008957", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008957", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008957", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008957", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008957", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008957", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008957")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008958")
    void case_UTAPI_008958() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008958",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008958", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008958", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008958", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008958", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008958", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008958", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008958", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008958", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008958", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008958", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008958")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008959")
    void case_UTAPI_008959() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008959",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008959", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008959", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008959", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008959", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008959", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008959", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008959", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008959", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008959", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008959", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008959")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008960")
    void case_UTAPI_008960() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008960",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008960", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008960", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008960", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008960", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008960", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008960", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008960", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008960", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008960", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008960", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008960")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008961")
    void case_UTAPI_008961() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008961",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008961", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008961", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008961", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008961", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008961", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008961", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008961", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008961", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008961", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008961", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008961")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008962")
    void case_UTAPI_008962() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008962",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008962", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008962", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008962", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008962", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008962", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008962", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008962", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008962", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008962", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008962", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008962")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008963")
    void case_UTAPI_008963() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008963",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008963", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008963", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008963", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008963", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008963", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008963", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008963", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008963", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008963", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008963", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008963")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008964")
    void case_UTAPI_008964() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008964",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008964", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008964", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008964", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008964", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008964", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008964", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008964", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008964", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008964", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008964", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008964")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008965")
    void case_UTAPI_008965() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008965",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008965", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008965", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008965", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008965", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008965", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008965", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008965", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008965", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008965", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008965", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008965")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008966")
    void case_UTAPI_008966() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008966",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008966", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008966", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008966", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008966", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008966", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008966", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008966", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008966", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008966", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008966", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008966")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008967")
    void case_UTAPI_008967() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008967",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008967", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008967", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008967", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008967", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008967", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008967", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008967", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008967", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008967", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008967", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008967")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008968")
    void case_UTAPI_008968() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008968",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008968", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008968", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008968", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008968", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008968", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008968", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008968", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008968", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008968", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008968", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008968")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008969")
    void case_UTAPI_008969() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008969",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008969", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008969", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008969", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008969", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008969", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008969", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008969", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008969", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008969", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008969", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008969")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008970")
    void case_UTAPI_008970() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008970",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008970", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008970", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008970", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008970", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008970", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008970", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008970", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008970", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008970", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008970", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008970")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008971")
    void case_UTAPI_008971() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008971",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008971", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008971", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008971", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008971", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008971", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008971", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008971", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008971", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008971", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008971", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008971")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008972")
    void case_UTAPI_008972() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008972",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008972", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008972", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008972", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008972", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008972", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008972", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008972", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008972", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008972", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008972", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008972")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008973")
    void case_UTAPI_008973() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008973",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008973", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008973", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008973", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008973", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008973", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008973", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008973", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008973", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008973", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008973", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008973")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008974")
    void case_UTAPI_008974() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008974",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008974", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008974", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008974", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008974", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008974", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008974", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008974", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008974", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008974", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008974", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008974")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008975")
    void case_UTAPI_008975() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008975",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008975", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008975", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008975", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008975", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008975", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008975", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008975", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008975", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008975", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008975", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008975")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008976")
    void case_UTAPI_008976() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008976",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008976", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008976", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008976", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008976", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008976", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008976", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008976", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008976", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008976", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008976", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008976")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008977")
    void case_UTAPI_008977() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008977",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008977", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008977", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008977", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008977", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008977", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008977", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008977", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008977", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008977", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008977", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008977")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008978")
    void case_UTAPI_008978() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008978",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008978", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008978", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008978", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008978", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008978", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008978", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008978", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008978", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008978", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008978", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008978")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008979")
    void case_UTAPI_008979() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008979",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008979", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008979", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008979", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008979", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008979", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008979", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008979", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008979", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008979", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008979", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008979")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008980")
    void case_UTAPI_008980() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008980",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008980", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008980", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008980", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008980", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008980", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008980", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008980", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008980", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008980", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008980", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008980")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008981")
    void case_UTAPI_008981() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008981",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008981", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008981", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008981", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008981", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008981", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008981", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008981", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008981", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008981", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008981", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008981")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008982")
    void case_UTAPI_008982() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008982",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008982", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008982", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008982", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008982", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008982", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008982", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008982", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008982", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008982", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008982", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008982")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008983")
    void case_UTAPI_008983() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008983",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008983", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008983", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008983", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008983", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008983", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008983", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008983", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008983", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008983", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008983", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008983")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008984")
    void case_UTAPI_008984() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008984",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008984", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008984", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008984", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008984", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008984", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008984", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008984", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008984", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008984", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008984", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008984")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008985")
    void case_UTAPI_008985() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008985",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008985", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008985", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008985", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008985", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008985", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008985", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008985", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008985", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008985", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008985", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008985")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008986")
    void case_UTAPI_008986() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008986",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008986", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008986", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008986", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008986", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008986", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008986", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008986", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008986", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008986", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008986", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008986")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008987")
    void case_UTAPI_008987() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008987",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008987", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008987", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008987", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008987", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008987", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008987", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008987", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008987", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008987", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008987", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008987")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008988")
    void case_UTAPI_008988() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008988",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008988", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008988", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008988", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008988", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008988", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008988", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008988", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008988", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008988", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008988", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008988")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008989")
    void case_UTAPI_008989() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008989",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008989", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008989", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008989", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008989", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008989", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008989", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008989", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008989", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008989", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008989", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008989")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008990")
    void case_UTAPI_008990() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008990",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008990", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008990", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008990", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008990", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008990", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008990", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008990", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008990", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008990", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008990", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008990")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008991")
    void case_UTAPI_008991() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008991",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008991", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008991", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008991", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008991", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008991", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008991", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008991", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008991", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008991", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008991", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008991")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008992")
    void case_UTAPI_008992() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008992",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008992", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008992", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008992", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008992", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008992", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008992", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008992", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008992", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008992", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008992", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008992")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008993")
    void case_UTAPI_008993() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008993",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008993", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008993", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008993", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008993", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008993", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008993", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008993", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008993", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008993", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008993", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008993")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008994")
    void case_UTAPI_008994() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008994",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008994", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008994", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008994", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008994", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008994", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008994", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008994", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008994", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008994", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008994", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008994")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008995")
    void case_UTAPI_008995() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008995",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008995", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008995", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008995", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008995", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008995", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008995", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008995", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008995", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008995", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008995", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008995")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008996")
    void case_UTAPI_008996() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008996",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008996", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008996", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008996", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008996", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008996", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008996", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008996", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008996", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008996", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008996", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008996")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008997")
    void case_UTAPI_008997() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008997",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008997", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008997", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008997", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008997", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008997", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008997", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008997", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008997", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008997", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008997", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008997")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008998")
    void case_UTAPI_008998() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008998",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008998", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008998", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008998", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008998", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008998", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008998", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008998", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008998", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008998", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008998", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008998")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008999")
    void case_UTAPI_008999() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008999",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008999", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008999", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008999", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008999", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008999", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008999", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008999", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008999", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008999", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008999", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008999")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009000")
    void case_UTAPI_009000() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009000",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009000", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009000", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009000", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009000", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009000", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009000", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009000", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009000", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009000", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009000", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-009000")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009001")
    void case_UTAPI_009001() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009001",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009001", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009001", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009001", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009001", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009001", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009001", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009001", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009001", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009001", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009001", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-009001")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009002")
    void case_UTAPI_009002() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009002",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009002", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009002", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009002", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009002", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009002", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009002", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009002", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009002", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009002", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009002", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-009002")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009003")
    void case_UTAPI_009003() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009003",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009003", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009003", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009003", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009003", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009003", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009003", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009003", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009003", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009003", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009003", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-009003")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009004")
    void case_UTAPI_009004() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009004",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009004", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009004", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009004", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009004", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009004", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009004", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009004", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009004", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009004", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009004", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-009004")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009005")
    void case_UTAPI_009005() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009005",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009005", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009005", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009005", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009005", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009005", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009005", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009005", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009005", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009005", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009005", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-009005")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009006")
    void case_UTAPI_009006() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009006",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009006", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009006", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009006", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009006", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009006", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009006", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009006", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009006", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009006", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009006", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-009006")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009007")
    void case_UTAPI_009007() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009007",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009007", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009007", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009007", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009007", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009007", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009007", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009007", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009007", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009007", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009007", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-009007")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009008")
    void case_UTAPI_009008() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009008",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009008", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009008", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009008", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009008", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009008", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009008", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009008", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009008", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009008", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009008", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-009008")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009009")
    void case_UTAPI_009009() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009009",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009009", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009009", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009009", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009009", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009009", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009009", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009009", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009009", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009009", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009009", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-009009")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009010")
    void case_UTAPI_009010() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009010",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009010", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009010", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009010", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009010", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009010", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009010", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009010", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009010", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009010", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009010", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-009010")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009011")
    void case_UTAPI_009011() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009011",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009011", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009011", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009011", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009011", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009011", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009011", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009011", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009011", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009011", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009011", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-009011")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009012")
    void case_UTAPI_009012() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009012",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009012", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009012", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009012", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009012", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009012", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009012", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009012", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009012", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009012", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009012", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-009012")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009013")
    void case_UTAPI_009013() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009013",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009013", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009013", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009013", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009013", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009013", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009013", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009013", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009013", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009013", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009013", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-009013")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009014")
    void case_UTAPI_009014() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009014",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009014", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009014", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009014", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009014", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009014", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009014", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009014", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009014", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009014", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009014", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-009014")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009015")
    void case_UTAPI_009015() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009015",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009015", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009015", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009015", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009015", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009015", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009015", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009015", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009015", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009015", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009015", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-009015")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009016")
    void case_UTAPI_009016() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009016",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009016", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009016", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009016", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009016", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009016", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009016", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009016", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009016", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009016", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009016", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-009016")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009017")
    void case_UTAPI_009017() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009017",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009017", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009017", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009017", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009017", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009017", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009017", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009017", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009017", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009017", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009017", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-009017")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009018")
    void case_UTAPI_009018() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009018",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009018", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009018", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009018", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009018", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009018", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009018", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009018", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009018", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009018", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009018", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-009018")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009019")
    void case_UTAPI_009019() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009019",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009019", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009019", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009019", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009019", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009019", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009019", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009019", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009019", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009019", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009019", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-009019")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009020")
    void case_UTAPI_009020() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009020",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009020", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009020", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009020", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009020", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009020", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009020", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009020", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009020", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009020", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009020", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-009020")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009021")
    void case_UTAPI_009021() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009021",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009021", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009021", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009021", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009021", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009021", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009021", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009021", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009021", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009021", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009021", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-009021")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009022")
    void case_UTAPI_009022() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009022",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009022", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009022", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009022", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009022", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009022", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009022", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009022", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009022", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009022", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009022", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-009022")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009023")
    void case_UTAPI_009023() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009023",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009023", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009023", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009023", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009023", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009023", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009023", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009023", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009023", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009023", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009023", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-009023")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009024")
    void case_UTAPI_009024() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009024",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009024", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009024", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009024", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009024", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009024", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009024", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009024", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009024", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009024", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009024", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-009024")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009025")
    void case_UTAPI_009025() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009025",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009025", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009025", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009025", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009025", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009025", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009025", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009025", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009025", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009025", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009025", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-009025")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009026")
    void case_UTAPI_009026() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009026",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009026", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009026", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009026", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009026", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009026", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009026", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009026", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009026", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009026", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009026", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-009026")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009027")
    void case_UTAPI_009027() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009027",
                "com.matsushita.dbeditor.domain.repository.TableMetadataRepository",
                "findAllTables",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009027", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009027", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009027", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009027", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009027", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009027", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009027", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009027", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009027", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009027", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-009027")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMetadataRepository.java::TableMetadataRepository::findAllTables::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMetadataRepositoryWrapper());
    }

}

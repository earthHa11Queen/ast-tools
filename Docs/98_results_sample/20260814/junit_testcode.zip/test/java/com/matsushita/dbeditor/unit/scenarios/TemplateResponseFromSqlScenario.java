package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TemplateResponseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TemplateResponse#fromSql.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TemplateResponseFromSqlScenario {

    @Test
    @DisplayName("UTAPI-010683")
    void case_UTAPI_010683() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010683",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010683", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010683", "t.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010683", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010683", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010683", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010683")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "1:length_null", "-")
                    .target("t.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010684")
    void case_UTAPI_010684() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010684",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010684", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010684", "t.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010684", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010684", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010684", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010684")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "2:length_empty", "-")
                    .target("t.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010685")
    void case_UTAPI_010685() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010685",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010685", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010685", "t.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010685", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010685", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010685", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010685")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "3:length_min", "-")
                    .target("t.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010686")
    void case_UTAPI_010686() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010686",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010686", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010686", "t.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010686", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010686", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010686", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010686")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("t.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010687")
    void case_UTAPI_010687() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010687",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010687", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010687", "t.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010687", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010687", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010687", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010687")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "5:length_max", "-")
                    .target("t.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010688")
    void case_UTAPI_010688() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010688",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010688", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010688", "t.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010688", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010688", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010688", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010688")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("t.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010689")
    void case_UTAPI_010689() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010689",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010689", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010689", "t.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010689", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010689", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010689", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010689")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("t.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010690")
    void case_UTAPI_010690() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010690",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010690", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010690", "t.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010690", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010690", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010690", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010690")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::contentSql")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("t.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010691")
    void case_UTAPI_010691() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010691",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010691", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010691", "t.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010691", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010691", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010691", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010691")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::contentSql")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("t.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010692")
    void case_UTAPI_010692() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010692",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010692", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010692", "t.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010692", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010692", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010692", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010692")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::contentSql")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("t.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010693")
    void case_UTAPI_010693() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010693",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010693", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010693", "t.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010693", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010693", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010693", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010693")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("t.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010694")
    void case_UTAPI_010694() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010694",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010694", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010694", "t.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010694", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010694", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010694", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010694")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("t.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010695")
    void case_UTAPI_010695() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010695",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010695", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010695", "t.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010695", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010695", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010695", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010695")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "-", "56:space")
                    .target("t.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010696")
    void case_UTAPI_010696() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010696",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010696", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010696", "t.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010696", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010696", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010696", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010696")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("t.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010697")
    void case_UTAPI_010697() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010697",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010697", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010697", "t.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010697", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010697", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010697", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010697")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("t.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010698")
    void case_UTAPI_010698() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010698",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010698", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010698", "t.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010698", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010698", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010698", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010698")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "-", "59:tab")
                    .target("t.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010699")
    void case_UTAPI_010699() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010699",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010699", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010699", "t.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010699", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010699", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010699", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010699")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "-", "60:control_character_null")
                    .target("t.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010700")
    void case_UTAPI_010700() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010700",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010700", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010700", "t.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010700", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010700", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010700", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010700")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("t.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010701")
    void case_UTAPI_010701() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010701",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010701", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010701", "t.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010701", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010701", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010701", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010701")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("t.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010702")
    void case_UTAPI_010702() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010702",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010702", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010702", "t.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010702", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010702", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010702", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010702")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("t.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010703")
    void case_UTAPI_010703() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010703",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010703", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010703", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010703", "t.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010703", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010703", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010703")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("t.createdTimestamp", "SqlTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010704")
    void case_UTAPI_010704() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010704",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010704", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010704", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010704", "t.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010704", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010704", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010704")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("t.createdTimestamp", "SqlTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010705")
    void case_UTAPI_010705() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010705",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010705", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010705", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010705", "t.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010705", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010705", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010705")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("t.createdTimestamp", "SqlTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010706")
    void case_UTAPI_010706() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010706",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010706", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010706", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010706", "t.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010706", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010706", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010706")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("t.createdTimestamp", "SqlTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010707")
    void case_UTAPI_010707() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010707",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010707", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010707", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010707", "t.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010707", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010707", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010707")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("t.createdTimestamp", "SqlTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010708")
    void case_UTAPI_010708() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010708",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010708", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010708", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010708", "t.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010708", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010708", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010708")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("t.createdTimestamp", "SqlTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010709")
    void case_UTAPI_010709() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010709",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010709", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010709", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010709", "t.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010709", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010709", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010709")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("t.createdTimestamp", "SqlTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010710")
    void case_UTAPI_010710() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010710",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010710", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010710", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010710", "t.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010710", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010710", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010710")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("t.createdTimestamp", "SqlTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010711")
    void case_UTAPI_010711() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010711",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010711", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010711", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010711", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010711", "t.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010711", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010711")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::n")
                    .mirror("-", "1:length_null", "-")
                    .target("t.n", "SqlTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010712")
    void case_UTAPI_010712() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010712",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010712", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010712", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010712", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010712", "t.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010712", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010712")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("t.n", "SqlTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010713")
    void case_UTAPI_010713() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010713",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010713", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010713", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010713", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010713", "t.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010713", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010713")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::n")
                    .mirror("-", "3:length_min", "-")
                    .target("t.n", "SqlTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010714")
    void case_UTAPI_010714() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010714",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010714", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010714", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010714", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010714", "t.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010714", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010714")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("t.n", "SqlTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010715")
    void case_UTAPI_010715() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010715",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010715", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010715", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010715", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010715", "t.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010715", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010715")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::n")
                    .mirror("-", "5:length_max", "-")
                    .target("t.n", "SqlTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010716")
    void case_UTAPI_010716() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010716",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010716", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010716", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010716", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010716", "t.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010716", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010716")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("t.n", "SqlTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010717")
    void case_UTAPI_010717() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010717",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010717", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010717", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010717", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010717", "t.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010717", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010717")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("t.n", "SqlTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010718")
    void case_UTAPI_010718() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010718",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010718", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010718", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010718", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010718", "t.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010718", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010718")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("t.n", "SqlTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010719")
    void case_UTAPI_010719() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010719",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010719", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010719", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010719", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010719", "t.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010719", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010719")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("t.n", "SqlTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010720")
    void case_UTAPI_010720() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010720",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010720", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010720", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010720", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010720", "t.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010720", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010720")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("t.n", "SqlTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010721")
    void case_UTAPI_010721() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010721",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010721", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010721", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010721", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010721", "t.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010721", "t.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010721")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("t.n", "SqlTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010722")
    void case_UTAPI_010722() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010722",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010722", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010722", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010722", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010722", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010722", "t.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010722")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "1:length_null", "-")
                    .target("t.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010723")
    void case_UTAPI_010723() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010723",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010723", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010723", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010723", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010723", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010723", "t.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010723")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "2:length_empty", "-")
                    .target("t.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010724")
    void case_UTAPI_010724() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010724",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010724", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010724", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010724", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010724", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010724", "t.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010724")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "3:length_min", "-")
                    .target("t.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010725")
    void case_UTAPI_010725() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010725",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010725", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010725", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010725", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010725", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010725", "t.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010725")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("t.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010726")
    void case_UTAPI_010726() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010726",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010726", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010726", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010726", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010726", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010726", "t.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010726")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "5:length_max", "-")
                    .target("t.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010727")
    void case_UTAPI_010727() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010727",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010727", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010727", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010727", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010727", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010727", "t.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010727")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("t.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010728")
    void case_UTAPI_010728() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010728",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010728", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010728", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010728", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010728", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010728", "t.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010728")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("t.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010729")
    void case_UTAPI_010729() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010729",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010729", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010729", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010729", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010729", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010729", "t.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010729")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::titleSql")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("t.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010730")
    void case_UTAPI_010730() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010730",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010730", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010730", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010730", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010730", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010730", "t.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010730")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::titleSql")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("t.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010731")
    void case_UTAPI_010731() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010731",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010731", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010731", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010731", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010731", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010731", "t.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010731")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::titleSql")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("t.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010732")
    void case_UTAPI_010732() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010732",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010732", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010732", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010732", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010732", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010732", "t.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010732")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::titleSql")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("t.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010733")
    void case_UTAPI_010733() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010733",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010733", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010733", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010733", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010733", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010733", "t.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010733")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("t.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010734")
    void case_UTAPI_010734() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010734",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010734", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010734", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010734", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010734", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010734", "t.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010734")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("t.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010735")
    void case_UTAPI_010735() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010735",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010735", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010735", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010735", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010735", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010735", "t.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010735")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "-", "56:space")
                    .target("t.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010736")
    void case_UTAPI_010736() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010736",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010736", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010736", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010736", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010736", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010736", "t.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010736")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("t.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010737")
    void case_UTAPI_010737() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010737",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010737", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010737", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010737", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010737", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010737", "t.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010737")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("t.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010738")
    void case_UTAPI_010738() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010738",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010738", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010738", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010738", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010738", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010738", "t.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010738")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "-", "59:tab")
                    .target("t.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010739")
    void case_UTAPI_010739() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010739",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010739", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010739", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010739", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010739", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010739", "t.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010739")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "-", "60:control_character_null")
                    .target("t.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010740")
    void case_UTAPI_010740() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010740",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010740", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010740", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010740", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010740", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010740", "t.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010740")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("t.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010741")
    void case_UTAPI_010741() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010741",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010741", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010741", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010741", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010741", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010741", "t.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010741")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("t.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010742")
    void case_UTAPI_010742() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010742",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromSql",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "SqlTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010742", "t", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-010742", "t.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010742", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010742", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010742", "t.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010742")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromSql::2::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("t.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromSql")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleSql", "getTitle", "data:t.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentSql", "getContent", "data:t.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

}

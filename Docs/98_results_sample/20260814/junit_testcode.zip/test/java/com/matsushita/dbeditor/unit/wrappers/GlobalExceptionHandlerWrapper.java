package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Operation wrapper for GlobalExceptionHandler.
 */
public final class GlobalExceptionHandlerWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.infrastructure.exception.GlobalExceptionHandler";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.infrastructure.exception.GlobalExceptionHandler";
    private static final String[] DEP_NAMES = new String[] {};
    private static final String[] DEP_TYPES = new String[] {};
    private static final String[] TYPES_handleIllegalArgument = new String[] {"IllegalArgumentException"};
    private static final String[] TYPES_handleRuntime = new String[] {"RuntimeException"};

    public GlobalExceptionHandlerWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, false);
    }

    /** ResponseEntity<Map<String,String>> handleIllegalArgument(ex) */
    public ExecutionResult handleIllegalArgument(Object[] args) {
        return invoke("handleIllegalArgument", TYPES_handleIllegalArgument, args);
    }

    /** ResponseEntity<Map<String,String>> handleRuntime(ex) */
    public ExecutionResult handleRuntime(Object[] args) {
        return invoke("handleRuntime", TYPES_handleRuntime, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("handleIllegalArgument".equals(operation)) {
            return handleIllegalArgument(args);
        } else if ("handleRuntime".equals(operation)) {
            return handleRuntime(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

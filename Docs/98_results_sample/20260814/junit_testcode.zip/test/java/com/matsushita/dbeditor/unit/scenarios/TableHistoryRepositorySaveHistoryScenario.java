package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableHistoryRepositoryWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableHistoryRepository#saveHistory.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableHistoryRepositorySaveHistoryScenario {

    @Test
    @DisplayName("UTAPI-008586")
    void case_UTAPI_008586() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008586",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008586", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008586", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008586", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008586", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008586", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008586", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008586", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008586", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008586", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008586", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008586", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008586", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008586", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008586", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008586", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008586", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008586")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008587")
    void case_UTAPI_008587() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008587",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008587", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008587", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008587", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008587", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008587", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008587", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008587", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008587", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008587", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008587", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008587", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008587", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008587", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008587", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008587", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008587", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008587")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008588")
    void case_UTAPI_008588() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008588",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008588", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008588", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008588", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008588", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008588", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008588", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008588", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008588", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008588", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008588", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008588", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008588", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008588", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008588", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008588", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008588", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008588")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008589")
    void case_UTAPI_008589() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008589",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008589", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008589", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008589", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008589", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008589", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008589", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008589", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008589", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008589", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008589", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008589", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008589", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008589", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008589", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008589", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008589", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008589")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008590")
    void case_UTAPI_008590() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008590",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008590", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008590", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008590", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008590", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008590", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008590", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008590", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008590", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008590", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008590", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008590", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008590", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008590", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008590", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008590", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008590", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008590")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008591")
    void case_UTAPI_008591() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008591",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008591", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008591", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008591", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008591", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008591", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008591", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008591", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008591", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008591", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008591", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008591", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008591", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008591", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008591", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008591", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008591", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008591")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008592")
    void case_UTAPI_008592() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008592",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008592", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008592", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008592", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008592", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008592", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008592", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008592", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008592", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008592", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008592", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008592", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008592", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008592", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008592", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008592", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008592", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008592")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008593")
    void case_UTAPI_008593() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008593",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008593", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008593", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008593", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008593", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008593", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008593", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008593", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008593", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008593", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008593", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008593", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008593", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008593", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008593", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008593", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008593", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008593")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008594")
    void case_UTAPI_008594() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008594",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008594", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008594", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008594", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008594", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008594", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008594", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008594", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008594", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008594", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008594", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008594", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008594", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008594", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008594", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008594", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008594", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008594")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008595")
    void case_UTAPI_008595() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008595",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008595", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008595", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008595", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008595", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008595", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008595", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008595", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008595", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008595", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008595", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008595", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008595", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008595", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008595", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008595", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008595", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008595")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008596")
    void case_UTAPI_008596() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008596",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008596", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008596", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008596", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008596", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008596", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008596", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008596", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008596", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008596", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008596", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008596", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008596", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008596", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008596", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008596", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008596", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008596")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008597")
    void case_UTAPI_008597() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008597",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008597", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008597", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008597", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008597", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008597", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008597", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008597", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008597", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008597", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008597", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008597", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008597", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008597", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008597", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008597", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008597", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008597")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008598")
    void case_UTAPI_008598() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008598",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008598", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008598", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008598", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008598", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008598", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008598", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008598", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008598", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008598", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008598", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008598", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008598", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008598", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008598", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008598", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008598", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008598")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008599")
    void case_UTAPI_008599() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008599",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008599", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008599", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008599", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008599", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008599", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008599", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008599", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008599", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008599", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008599", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008599", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008599", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008599", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008599", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008599", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008599", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008599")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008600")
    void case_UTAPI_008600() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008600",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008600", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008600", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008600", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008600", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008600", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008600", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008600", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008600", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008600", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008600", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008600", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008600", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008600", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008600", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008600", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008600", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008600")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008601")
    void case_UTAPI_008601() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008601",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008601", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008601", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008601", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008601", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008601", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008601", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008601", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008601", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008601", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008601", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008601", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008601", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008601", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008601", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008601", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008601", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008601")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008602")
    void case_UTAPI_008602() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008602",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008602", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008602", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008602", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008602", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008602", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008602", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008602", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008602", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008602", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008602", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008602", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008602", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008602", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008602", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008602", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008602", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008602")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008603")
    void case_UTAPI_008603() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008603",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008603", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008603", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008603", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008603", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008603", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008603", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008603", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008603", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008603", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008603", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008603", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008603", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008603", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008603", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008603", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008603", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008603")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008604")
    void case_UTAPI_008604() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008604",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008604", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008604", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008604", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008604", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008604", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008604", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008604", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008604", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008604", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008604", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008604", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008604", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008604", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008604", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008604", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008604", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008604")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008605")
    void case_UTAPI_008605() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008605",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008605", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008605", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008605", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008605", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008605", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008605", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008605", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008605", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008605", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008605", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008605", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008605", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008605", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008605", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008605", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008605", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008605")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008606")
    void case_UTAPI_008606() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008606",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008606", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008606", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008606", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008606", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008606", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008606", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008606", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008606", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008606", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008606", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008606", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008606", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008606", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008606", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008606", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008606", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008606")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008607")
    void case_UTAPI_008607() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008607",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008607", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008607", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008607", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008607", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008607", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008607", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008607", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008607", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008607", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008607", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008607", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008607", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008607", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008607", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008607", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008607", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008607")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008608")
    void case_UTAPI_008608() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008608",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008608", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008608", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008608", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008608", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008608", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008608", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008608", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008608", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008608", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008608", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008608", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008608", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008608", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008608", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008608", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008608", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008608")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008609")
    void case_UTAPI_008609() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008609",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008609", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008609", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008609", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008609", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008609", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008609", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008609", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008609", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008609", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008609", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008609", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008609", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008609", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008609", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008609", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008609", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008609")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008610")
    void case_UTAPI_008610() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008610",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008610", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008610", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008610", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008610", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008610", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008610", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008610", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008610", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008610", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008610", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008610", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008610", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008610", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008610", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008610", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008610", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008610")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008611")
    void case_UTAPI_008611() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008611",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008611", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008611", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008611", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008611", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008611", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008611", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008611", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008611", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008611", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008611", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008611", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008611", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008611", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008611", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008611", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008611", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008611")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008612")
    void case_UTAPI_008612() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008612",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008612", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008612", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008612", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008612", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008612", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008612", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008612", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008612", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008612", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008612", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008612", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008612", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008612", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008612", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008612", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008612", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008612")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008613")
    void case_UTAPI_008613() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008613",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008613", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008613", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008613", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008613", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008613", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008613", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008613", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008613", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008613", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008613", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008613", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008613", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008613", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008613", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008613", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008613", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008613")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008614")
    void case_UTAPI_008614() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008614",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008614", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008614", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008614", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008614", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008614", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008614", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008614", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008614", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008614", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008614", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008614", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008614", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008614", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008614", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008614", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008614", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008614")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008615")
    void case_UTAPI_008615() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008615",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008615", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008615", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008615", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008615", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008615", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008615", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008615", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008615", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008615", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008615", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008615", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008615", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008615", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008615", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008615", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008615", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008615")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008616")
    void case_UTAPI_008616() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008616",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008616", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008616", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008616", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008616", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008616", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008616", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008616", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008616", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008616", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008616", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008616", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008616", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008616", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008616", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008616", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008616", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008616")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008617")
    void case_UTAPI_008617() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008617",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008617", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008617", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008617", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008617", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008617", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008617", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008617", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008617", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008617", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008617", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008617", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008617", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008617", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008617", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008617", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008617", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008617")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008618")
    void case_UTAPI_008618() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008618",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008618", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008618", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008618", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008618", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008618", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008618", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008618", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008618", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008618", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008618", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008618", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008618", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008618", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008618", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008618", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008618", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008618")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008619")
    void case_UTAPI_008619() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008619",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008619", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008619", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008619", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008619", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008619", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008619", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008619", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008619", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008619", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008619", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008619", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008619", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008619", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008619", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008619", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008619", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008619")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008620")
    void case_UTAPI_008620() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008620",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008620", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008620", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008620", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008620", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008620", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008620", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008620", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008620", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008620", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008620", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008620", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008620", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008620", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008620", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008620", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008620", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008620")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008621")
    void case_UTAPI_008621() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008621",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008621", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008621", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008621", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008621", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008621", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008621", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008621", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008621", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008621", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008621", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008621", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008621", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008621", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008621", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008621", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008621", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008621")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008622")
    void case_UTAPI_008622() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008622",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008622", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008622", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008622", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008622", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008622", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008622", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008622", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008622", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008622", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008622", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008622", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008622", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008622", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008622", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008622", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008622", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008622")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008623")
    void case_UTAPI_008623() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008623",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008623", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008623", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008623", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008623", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008623", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008623", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008623", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008623", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008623", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008623", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008623", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008623", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008623", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008623", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008623", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008623", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008623")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008624")
    void case_UTAPI_008624() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008624",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008624", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008624", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008624", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008624", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008624", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008624", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008624", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008624", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008624", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008624", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008624", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008624", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008624", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008624", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008624", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008624", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008624")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008625")
    void case_UTAPI_008625() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008625",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008625", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008625", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008625", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008625", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008625", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008625", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008625", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008625", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008625", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008625", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008625", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008625", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008625", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008625", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008625", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008625", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008625")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008626")
    void case_UTAPI_008626() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008626",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008626", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008626", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008626", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008626", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008626", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008626", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008626", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008626", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008626", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008626", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008626", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008626", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008626", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008626", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008626", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008626", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008626")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008627")
    void case_UTAPI_008627() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008627",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008627", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008627", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008627", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008627", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008627", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008627", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008627", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008627", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008627", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008627", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008627", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008627", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008627", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008627", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008627", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008627", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008627")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008628")
    void case_UTAPI_008628() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008628",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008628", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008628", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008628", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008628", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008628", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008628", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008628", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008628", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008628", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008628", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008628", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008628", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008628", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008628", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008628", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008628", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008628")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008629")
    void case_UTAPI_008629() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008629",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008629", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008629", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008629", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008629", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008629", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008629", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008629", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008629", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008629", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008629", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008629", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008629", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008629", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008629", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008629", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008629", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008629")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008630")
    void case_UTAPI_008630() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008630",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008630", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008630", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008630", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008630", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008630", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008630", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008630", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008630", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008630", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008630", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008630", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008630", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008630", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008630", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008630", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008630", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008630")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008631")
    void case_UTAPI_008631() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008631",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008631", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008631", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008631", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008631", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008631", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008631", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008631", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008631", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008631", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008631", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008631", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008631", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008631", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008631", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008631", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008631", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008631")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008632")
    void case_UTAPI_008632() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008632",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008632", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008632", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008632", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008632", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008632", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008632", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008632", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008632", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008632", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008632", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008632", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008632", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008632", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008632", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008632", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008632", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008632")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008633")
    void case_UTAPI_008633() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008633",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008633", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008633", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008633", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008633", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008633", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008633", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008633", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008633", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008633", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008633", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008633", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008633", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008633", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008633", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008633", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008633", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008633")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008634")
    void case_UTAPI_008634() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008634",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008634", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008634", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008634", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008634", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008634", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008634", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008634", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008634", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008634", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008634", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008634", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008634", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008634", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008634", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008634", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008634", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008634")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008635")
    void case_UTAPI_008635() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008635",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008635", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008635", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008635", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008635", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008635", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008635", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008635", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008635", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008635", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008635", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008635", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008635", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008635", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008635", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008635", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008635", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008635")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008636")
    void case_UTAPI_008636() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008636",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008636", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008636", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008636", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008636", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008636", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008636", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008636", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008636", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008636", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008636", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008636", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008636", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008636", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008636", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008636", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008636", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008636")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008637")
    void case_UTAPI_008637() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008637",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008637", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008637", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008637", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008637", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008637", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008637", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008637", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008637", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008637", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008637", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008637", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008637", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008637", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008637", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008637", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008637", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008637")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008638")
    void case_UTAPI_008638() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008638",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008638", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008638", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008638", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008638", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008638", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008638", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008638", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008638", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008638", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008638", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008638", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008638", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008638", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008638", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008638", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008638", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008638")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008639")
    void case_UTAPI_008639() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008639",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008639", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008639", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008639", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008639", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008639", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008639", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008639", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008639", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008639", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008639", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008639", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008639", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008639", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008639", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008639", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008639", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008639")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008640")
    void case_UTAPI_008640() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008640",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008640", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008640", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008640", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008640", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008640", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008640", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008640", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008640", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008640", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008640", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008640", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008640", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008640", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008640", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008640", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008640", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008640")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008641")
    void case_UTAPI_008641() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008641",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008641", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008641", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008641", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008641", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008641", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008641", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008641", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008641", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008641", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008641", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008641", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008641", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008641", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008641", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008641", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008641", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008641")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008642")
    void case_UTAPI_008642() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008642",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008642", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008642", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008642", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008642", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008642", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008642", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008642", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008642", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008642", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008642", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008642", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008642", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008642", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008642", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008642", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008642", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008642")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008643")
    void case_UTAPI_008643() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008643",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008643", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008643", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008643", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008643", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008643", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008643", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008643", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008643", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008643", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008643", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008643", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008643", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008643", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008643", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008643", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008643", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008643")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008644")
    void case_UTAPI_008644() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008644",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008644", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008644", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008644", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008644", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008644", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008644", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008644", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008644", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008644", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008644", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008644", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008644", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008644", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008644", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008644", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008644", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008644")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008645")
    void case_UTAPI_008645() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008645",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008645", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008645", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008645", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008645", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008645", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008645", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008645", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008645", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008645", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008645", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008645", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008645", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008645", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008645", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008645", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008645", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008645")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008646")
    void case_UTAPI_008646() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008646",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008646", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008646", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008646", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008646", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008646", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008646", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008646", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008646", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008646", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008646", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008646", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008646", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008646", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008646", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008646", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008646", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008646")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008647")
    void case_UTAPI_008647() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008647",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008647", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008647", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008647", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008647", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008647", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008647", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008647", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008647", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008647", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008647", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008647", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008647", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008647", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008647", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008647", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008647", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008647")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008648")
    void case_UTAPI_008648() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008648",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008648", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008648", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008648", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008648", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008648", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008648", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008648", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008648", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008648", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008648", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008648", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008648", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008648", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008648", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008648", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008648", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008648")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008649")
    void case_UTAPI_008649() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008649",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008649", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008649", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008649", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008649", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008649", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008649", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008649", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008649", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008649", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008649", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008649", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008649", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008649", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008649", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008649", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008649", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008649")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008650")
    void case_UTAPI_008650() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008650",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008650", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008650", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008650", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008650", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008650", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008650", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008650", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008650", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008650", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008650", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008650", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008650", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008650", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008650", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008650", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008650", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008650")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008651")
    void case_UTAPI_008651() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008651",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008651", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008651", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008651", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008651", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008651", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008651", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008651", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008651", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008651", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008651", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008651", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008651", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008651", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008651", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008651", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008651", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008651")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008652")
    void case_UTAPI_008652() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008652",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008652", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008652", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008652", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008652", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008652", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008652", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008652", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008652", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008652", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008652", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008652", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008652", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008652", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008652", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008652", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008652", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008652")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008653")
    void case_UTAPI_008653() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008653",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008653", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008653", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008653", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008653", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008653", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008653", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008653", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008653", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008653", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008653", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008653", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008653", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008653", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008653", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008653", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008653", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008653")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008654")
    void case_UTAPI_008654() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008654",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008654", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008654", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008654", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008654", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008654", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008654", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008654", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008654", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008654", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008654", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008654", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008654", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008654", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008654", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008654", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008654", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008654")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008655")
    void case_UTAPI_008655() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008655",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008655", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008655", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008655", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008655", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008655", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008655", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008655", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008655", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008655", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008655", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008655", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008655", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008655", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008655", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008655", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008655", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008655")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008656")
    void case_UTAPI_008656() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008656",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008656", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008656", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008656", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008656", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008656", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008656", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008656", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008656", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008656", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008656", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008656", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008656", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008656", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008656", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008656", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008656", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008656")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008657")
    void case_UTAPI_008657() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008657",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008657", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008657", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008657", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008657", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008657", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008657", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008657", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008657", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008657", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008657", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008657", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008657", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008657", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008657", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008657", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008657", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008657")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008658")
    void case_UTAPI_008658() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008658",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008658", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008658", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008658", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008658", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008658", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008658", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008658", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008658", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008658", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008658", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008658", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008658", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008658", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008658", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008658", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008658", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008658")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008659")
    void case_UTAPI_008659() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008659",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008659", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008659", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008659", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008659", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008659", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008659", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008659", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008659", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008659", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008659", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008659", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008659", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008659", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008659", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008659", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008659", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008659")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008660")
    void case_UTAPI_008660() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008660",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008660", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008660", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008660", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008660", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008660", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008660", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008660", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008660", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008660", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008660", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008660", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008660", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008660", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008660", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008660", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008660", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008660")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008661")
    void case_UTAPI_008661() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008661",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008661", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008661", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008661", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008661", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008661", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008661", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008661", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008661", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008661", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008661", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008661", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008661", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008661", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008661", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008661", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008661", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008661")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008662")
    void case_UTAPI_008662() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008662",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008662", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008662", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008662", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008662", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008662", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008662", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008662", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008662", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008662", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008662", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008662", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008662", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008662", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008662", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008662", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008662", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008662")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008663")
    void case_UTAPI_008663() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008663",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008663", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008663", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008663", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008663", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008663", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008663", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008663", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008663", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008663", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008663", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008663", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008663", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008663", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008663", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008663", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008663", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008663")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008664")
    void case_UTAPI_008664() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008664",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008664", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008664", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008664", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008664", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008664", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008664", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008664", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008664", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008664", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008664", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008664", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008664", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008664", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008664", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008664", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008664", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008664")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008665")
    void case_UTAPI_008665() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008665",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008665", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008665", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008665", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008665", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008665", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008665", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008665", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008665", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008665", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008665", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008665", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008665", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008665", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008665", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008665", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008665", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008665")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008666")
    void case_UTAPI_008666() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008666",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008666", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008666", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008666", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008666", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008666", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008666", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008666", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008666", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008666", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008666", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008666", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008666", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008666", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008666", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008666", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008666", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008666")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008667")
    void case_UTAPI_008667() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008667",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008667", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008667", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008667", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008667", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008667", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008667", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008667", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008667", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008667", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008667", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008667", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008667", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008667", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008667", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008667", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008667", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008667")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008668")
    void case_UTAPI_008668() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008668",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008668", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008668", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008668", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008668", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008668", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008668", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008668", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008668", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008668", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008668", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008668", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008668", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008668", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008668", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008668", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008668", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008668")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008669")
    void case_UTAPI_008669() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008669",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008669", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008669", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008669", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008669", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008669", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008669", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008669", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008669", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008669", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008669", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008669", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008669", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008669", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008669", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008669", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008669", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008669")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008670")
    void case_UTAPI_008670() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008670",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008670", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008670", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008670", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008670", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008670", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008670", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008670", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008670", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008670", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008670", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008670", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008670", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008670", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008670", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008670", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008670", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008670")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008671")
    void case_UTAPI_008671() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008671",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008671", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008671", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008671", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008671", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008671", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008671", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008671", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008671", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008671", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008671", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008671", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008671", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008671", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008671", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008671", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008671", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008671")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008672")
    void case_UTAPI_008672() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008672",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008672", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008672", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008672", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008672", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008672", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008672", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008672", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008672", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008672", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008672", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008672", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008672", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008672", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008672", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008672", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008672", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008672")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008673")
    void case_UTAPI_008673() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008673",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008673", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008673", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008673", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008673", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008673", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008673", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008673", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008673", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008673", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008673", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008673", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008673", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008673", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008673", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008673", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008673", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008673")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008674")
    void case_UTAPI_008674() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008674",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008674", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008674", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008674", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008674", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008674", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008674", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008674", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008674", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008674", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008674", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008674", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008674", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008674", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008674", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008674", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008674", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008674")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008675")
    void case_UTAPI_008675() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008675",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008675", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008675", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008675", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008675", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008675", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008675", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008675", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008675", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008675", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008675", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008675", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008675", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008675", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008675", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008675", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008675", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008675")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008676")
    void case_UTAPI_008676() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008676",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008676", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008676", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008676", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008676", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008676", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008676", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008676", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008676", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008676", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008676", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008676", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008676", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008676", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008676", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008676", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008676", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008676")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008677")
    void case_UTAPI_008677() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008677",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008677", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008677", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008677", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008677", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008677", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008677", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008677", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008677", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008677", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008677", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008677", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008677", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008677", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008677", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008677", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008677", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008677")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008678")
    void case_UTAPI_008678() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008678",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008678", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008678", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008678", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008678", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008678", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008678", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008678", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008678", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008678", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008678", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008678", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008678", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008678", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008678", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008678", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008678", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008678")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008679")
    void case_UTAPI_008679() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008679",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008679", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008679", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008679", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008679", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008679", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008679", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008679", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008679", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008679", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008679", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008679", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008679", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008679", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008679", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008679", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008679", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008679")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008680")
    void case_UTAPI_008680() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008680",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008680", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008680", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008680", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008680", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008680", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008680", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008680", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008680", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008680", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008680", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008680", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008680", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008680", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008680", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008680", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008680", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008680")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008681")
    void case_UTAPI_008681() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008681",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008681", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008681", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008681", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008681", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008681", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008681", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008681", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008681", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008681", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008681", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008681", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008681", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008681", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008681", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008681", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008681", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008681")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008682")
    void case_UTAPI_008682() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008682",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008682", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008682", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008682", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008682", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008682", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008682", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008682", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008682", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008682", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008682", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008682", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008682", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008682", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008682", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008682", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008682", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008682")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008683")
    void case_UTAPI_008683() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008683",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008683", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008683", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008683", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008683", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008683", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008683", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008683", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008683", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008683", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008683", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008683", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008683", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008683", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008683", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008683", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008683", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008683")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008684")
    void case_UTAPI_008684() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008684",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008684", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008684", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008684", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008684", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008684", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008684", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008684", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008684", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008684", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008684", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008684", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008684", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008684", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008684", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008684", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008684", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008684")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008685")
    void case_UTAPI_008685() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008685",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008685", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008685", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008685", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008685", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008685", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008685", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008685", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008685", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008685", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008685", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008685", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008685", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008685", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008685", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008685", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008685", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008685")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008686")
    void case_UTAPI_008686() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008686",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008686", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008686", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008686", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008686", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008686", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008686", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008686", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008686", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008686", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008686", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008686", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008686", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008686", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008686", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008686", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008686", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008686")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008687")
    void case_UTAPI_008687() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008687",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008687", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008687", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008687", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008687", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008687", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008687", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008687", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008687", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008687", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008687", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008687", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008687", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008687", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008687", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008687", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008687", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008687")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008688")
    void case_UTAPI_008688() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008688",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008688", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008688", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008688", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008688", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008688", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008688", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008688", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008688", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008688", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008688", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008688", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008688", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008688", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008688", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008688", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008688", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008688")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008689")
    void case_UTAPI_008689() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008689",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008689", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008689", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008689", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008689", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008689", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008689", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008689", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008689", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008689", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008689", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008689", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008689", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008689", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008689", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008689", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008689", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008689")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008690")
    void case_UTAPI_008690() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008690",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008690", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008690", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008690", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008690", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008690", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008690", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008690", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008690", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008690", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008690", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008690", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008690", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008690", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008690", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008690", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008690", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008690")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008691")
    void case_UTAPI_008691() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008691",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008691", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008691", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008691", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008691", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008691", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008691", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008691", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008691", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008691", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008691", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008691", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008691", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008691", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008691", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008691", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008691", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008691")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008692")
    void case_UTAPI_008692() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008692",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008692", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008692", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008692", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008692", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008692", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008692", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008692", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008692", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008692", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008692", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008692", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008692", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008692", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008692", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008692", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008692", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008692")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008693")
    void case_UTAPI_008693() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008693",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008693", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008693", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008693", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008693", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008693", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008693", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008693", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008693", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008693", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008693", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008693", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008693", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008693", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008693", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008693", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008693", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008693")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008694")
    void case_UTAPI_008694() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008694",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008694", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008694", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008694", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008694", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008694", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008694", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008694", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008694", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008694", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008694", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008694", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008694", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008694", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008694", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008694", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008694", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008694")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008695")
    void case_UTAPI_008695() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008695",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008695", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008695", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008695", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008695", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008695", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008695", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008695", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008695", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008695", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008695", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008695", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008695", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008695", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008695", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008695", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008695", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008695")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008696")
    void case_UTAPI_008696() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008696",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008696", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008696", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008696", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008696", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008696", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008696", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008696", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008696", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008696", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008696", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008696", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008696", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008696", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008696", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008696", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008696", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008696")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008697")
    void case_UTAPI_008697() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008697",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008697", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008697", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008697", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008697", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008697", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008697", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008697", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008697", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008697", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008697", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008697", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008697", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008697", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008697", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008697", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008697", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008697")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008698")
    void case_UTAPI_008698() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008698",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008698", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008698", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008698", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008698", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008698", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008698", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008698", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008698", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008698", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008698", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008698", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008698", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008698", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008698", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008698", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008698", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008698")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008699")
    void case_UTAPI_008699() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008699",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008699", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008699", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008699", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008699", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008699", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008699", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008699", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008699", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008699", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008699", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008699", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008699", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008699", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008699", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008699", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008699", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008699")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008700")
    void case_UTAPI_008700() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008700",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008700", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008700", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008700", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008700", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008700", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008700", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008700", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008700", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008700", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008700", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008700", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008700", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008700", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008700", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008700", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008700", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008700")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008701")
    void case_UTAPI_008701() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008701",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008701", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008701", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008701", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008701", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008701", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008701", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008701", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008701", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008701", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008701", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008701", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008701", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008701", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008701", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008701", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008701", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008701")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008702")
    void case_UTAPI_008702() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008702",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008702", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008702", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008702", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008702", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008702", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008702", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008702", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008702", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008702", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008702", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008702", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008702", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008702", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008702", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008702", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008702", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008702")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008703")
    void case_UTAPI_008703() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008703",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008703", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008703", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008703", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008703", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008703", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008703", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008703", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008703", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008703", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008703", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008703", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008703", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008703", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008703", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008703", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008703", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008703")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008704")
    void case_UTAPI_008704() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008704",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008704", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008704", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008704", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008704", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008704", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008704", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008704", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008704", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008704", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008704", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008704", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008704", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008704", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008704", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008704", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008704", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008704")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008705")
    void case_UTAPI_008705() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008705",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008705", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008705", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008705", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008705", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008705", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008705", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008705", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008705", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008705", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008705", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008705", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008705", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008705", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008705", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008705", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008705", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008705")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008706")
    void case_UTAPI_008706() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008706",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008706", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008706", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008706", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008706", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008706", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008706", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008706", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008706", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008706", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008706", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008706", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008706", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008706", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008706", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008706", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008706", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008706")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008707")
    void case_UTAPI_008707() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008707",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008707", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008707", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008707", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008707", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008707", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008707", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008707", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008707", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008707", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008707", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008707", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008707", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008707", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008707", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008707", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008707", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008707")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008708")
    void case_UTAPI_008708() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008708",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008708", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008708", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008708", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008708", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008708", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008708", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008708", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008708", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008708", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008708", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008708", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008708", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008708", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008708", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008708", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008708", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008708")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008709")
    void case_UTAPI_008709() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008709",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008709", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008709", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008709", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008709", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008709", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008709", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008709", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008709", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008709", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008709", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008709", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008709", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008709", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008709", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008709", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008709", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008709")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008710")
    void case_UTAPI_008710() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008710",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008710", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008710", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008710", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008710", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008710", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008710", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008710", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008710", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008710", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008710", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008710", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008710", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008710", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008710", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008710", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008710", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008710")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008711")
    void case_UTAPI_008711() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008711",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008711", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008711", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008711", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008711", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008711", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008711", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008711", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008711", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008711", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008711", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008711", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008711", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008711", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008711", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008711", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008711", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008711")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008712")
    void case_UTAPI_008712() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008712",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008712", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008712", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008712", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008712", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008712", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008712", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008712", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008712", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008712", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008712", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008712", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008712", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008712", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008712", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008712", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008712", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008712")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008713")
    void case_UTAPI_008713() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008713",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008713", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008713", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008713", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008713", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008713", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008713", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008713", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008713", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008713", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008713", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008713", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008713", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008713", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008713", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008713", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008713", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008713")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008714")
    void case_UTAPI_008714() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008714",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008714", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008714", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008714", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008714", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008714", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008714", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008714", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008714", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008714", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008714", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008714", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008714", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008714", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008714", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008714", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008714", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008714")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008715")
    void case_UTAPI_008715() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008715",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008715", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008715", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008715", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008715", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008715", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008715", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008715", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008715", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008715", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008715", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008715", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008715", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008715", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008715", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008715", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008715", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008715")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008716")
    void case_UTAPI_008716() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008716",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008716", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008716", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008716", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008716", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008716", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008716", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008716", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008716", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008716", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008716", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008716", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008716", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008716", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008716", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008716", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008716", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008716")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008717")
    void case_UTAPI_008717() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008717",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008717", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008717", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008717", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008717", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008717", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008717", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008717", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008717", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008717", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008717", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008717", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008717", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008717", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008717", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008717", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008717", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008717")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008718")
    void case_UTAPI_008718() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008718",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008718", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008718", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008718", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008718", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008718", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008718", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008718", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008718", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008718", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008718", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008718", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008718", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008718", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008718", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008718", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008718", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008718")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008719")
    void case_UTAPI_008719() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008719",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008719", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008719", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008719", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008719", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008719", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008719", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008719", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008719", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008719", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008719", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008719", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008719", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008719", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008719", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008719", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008719", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008719")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008720")
    void case_UTAPI_008720() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008720",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008720", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008720", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008720", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008720", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008720", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008720", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008720", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008720", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008720", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008720", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008720", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008720", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008720", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008720", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008720", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008720", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008720")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008721")
    void case_UTAPI_008721() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008721",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008721", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008721", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008721", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008721", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008721", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008721", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008721", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008721", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008721", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008721", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008721", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008721", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008721", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008721", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008721", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008721", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008721")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008722")
    void case_UTAPI_008722() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008722",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008722", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008722", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008722", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008722", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008722", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008722", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008722", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008722", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008722", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008722", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008722", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008722", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008722", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008722", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008722", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008722", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008722")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008723")
    void case_UTAPI_008723() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008723",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008723", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008723", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008723", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008723", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008723", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008723", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008723", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008723", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008723", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008723", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008723", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008723", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008723", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008723", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008723", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008723", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008723")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008724")
    void case_UTAPI_008724() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008724",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008724", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008724", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008724", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008724", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008724", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008724", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008724", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008724", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008724", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008724", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008724", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008724", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008724", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008724", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008724", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008724", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008724")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008725")
    void case_UTAPI_008725() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008725",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008725", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008725", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008725", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008725", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008725", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008725", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008725", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008725", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008725", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008725", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008725", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008725", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008725", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008725", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008725", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008725", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008725")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008726")
    void case_UTAPI_008726() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008726",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008726", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008726", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008726", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008726", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008726", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008726", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008726", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008726", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008726", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008726", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008726", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008726", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008726", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008726", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008726", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008726", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008726")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008727")
    void case_UTAPI_008727() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008727",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008727", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008727", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008727", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008727", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008727", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008727", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008727", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008727", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008727", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008727", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008727", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008727", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008727", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008727", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008727", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008727", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008727")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008728")
    void case_UTAPI_008728() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008728",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008728", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008728", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008728", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008728", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008728", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008728", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008728", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008728", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008728", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008728", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008728", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008728", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008728", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008728", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008728", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008728", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008728")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008729")
    void case_UTAPI_008729() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008729",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008729", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008729", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008729", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008729", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008729", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008729", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008729", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008729", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008729", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008729", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008729", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008729", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008729", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008729", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008729", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008729", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008729")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008730")
    void case_UTAPI_008730() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008730",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008730", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008730", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008730", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008730", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008730", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008730", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008730", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008730", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008730", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008730", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008730", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008730", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008730", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008730", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008730", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008730", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008730")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008731")
    void case_UTAPI_008731() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008731",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008731", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008731", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008731", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008731", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008731", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008731", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008731", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008731", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008731", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008731", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008731", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008731", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008731", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008731", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008731", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008731", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008731")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008732")
    void case_UTAPI_008732() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008732",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008732", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008732", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008732", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008732", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008732", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008732", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008732", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008732", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008732", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008732", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008732", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008732", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008732", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008732", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008732", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008732", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008732")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008733")
    void case_UTAPI_008733() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008733",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008733", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008733", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008733", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008733", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008733", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008733", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008733", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008733", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008733", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008733", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008733", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008733", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008733", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008733", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008733", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008733", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008733")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008734")
    void case_UTAPI_008734() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008734",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008734", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008734", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008734", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008734", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008734", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008734", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008734", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008734", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008734", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008734", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008734", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008734", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008734", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008734", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008734", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008734", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008734")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008735")
    void case_UTAPI_008735() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008735",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008735", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008735", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008735", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008735", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008735", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008735", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008735", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008735", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008735", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008735", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008735", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008735", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008735", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008735", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008735", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008735", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008735")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008736")
    void case_UTAPI_008736() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008736",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008736", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008736", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008736", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008736", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008736", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008736", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008736", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008736", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008736", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008736", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008736", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008736", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008736", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008736", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008736", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008736", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008736")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008737")
    void case_UTAPI_008737() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008737",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008737", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008737", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008737", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008737", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008737", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008737", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008737", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008737", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008737", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008737", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008737", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008737", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008737", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008737", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008737", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008737", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008737")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008738")
    void case_UTAPI_008738() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008738",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008738", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008738", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008738", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008738", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008738", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008738", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008738", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008738", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008738", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008738", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008738", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008738", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008738", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008738", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008738", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008738", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008738")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008739")
    void case_UTAPI_008739() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008739",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008739", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008739", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008739", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008739", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008739", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008739", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008739", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008739", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008739", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008739", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008739", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008739", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008739", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008739", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008739", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008739", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008739")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008740")
    void case_UTAPI_008740() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008740",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008740", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008740", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008740", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008740", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008740", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008740", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008740", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008740", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008740", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008740", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008740", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008740", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008740", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008740", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008740", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008740", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008740")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008741")
    void case_UTAPI_008741() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008741",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008741", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008741", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008741", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008741", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008741", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008741", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008741", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008741", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008741", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008741", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008741", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008741", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008741", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008741", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008741", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008741", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008741")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008742")
    void case_UTAPI_008742() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008742",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008742", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008742", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008742", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008742", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008742", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008742", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008742", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008742", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008742", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008742", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008742", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008742", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008742", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008742", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008742", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008742", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008742")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008743")
    void case_UTAPI_008743() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008743",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008743", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008743", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008743", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008743", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008743", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008743", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008743", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008743", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008743", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008743", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008743", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008743", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008743", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008743", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008743", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008743", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008743")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008744")
    void case_UTAPI_008744() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008744",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008744", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008744", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008744", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008744", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008744", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008744", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008744", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008744", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008744", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008744", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008744", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008744", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008744", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008744", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008744", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008744", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008744")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008745")
    void case_UTAPI_008745() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008745",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008745", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008745", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008745", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008745", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008745", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008745", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008745", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008745", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008745", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008745", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008745", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008745", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008745", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008745", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008745", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008745", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008745")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008746")
    void case_UTAPI_008746() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008746",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008746", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008746", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008746", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008746", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008746", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008746", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008746", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008746", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008746", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008746", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008746", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008746", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008746", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008746", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008746", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008746", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008746")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008747")
    void case_UTAPI_008747() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008747",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008747", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008747", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008747", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008747", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008747", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008747", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008747", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008747", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008747", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008747", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008747", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008747", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008747", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008747", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008747", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008747", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008747")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008748")
    void case_UTAPI_008748() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008748",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008748", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008748", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008748", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008748", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008748", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008748", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008748", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008748", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008748", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008748", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008748", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008748", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008748", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008748", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008748", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008748", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008748")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008749")
    void case_UTAPI_008749() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008749",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008749", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008749", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008749", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008749", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008749", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008749", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008749", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008749", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008749", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008749", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008749", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008749", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008749", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008749", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008749", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008749", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008749")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008750")
    void case_UTAPI_008750() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008750",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008750", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008750", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008750", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008750", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008750", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008750", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008750", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008750", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008750", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008750", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008750", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008750", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008750", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008750", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008750", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008750", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008750")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008751")
    void case_UTAPI_008751() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008751",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008751", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008751", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008751", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008751", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008751", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008751", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008751", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008751", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008751", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008751", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008751", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008751", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008751", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008751", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008751", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008751", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008751")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008752")
    void case_UTAPI_008752() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008752",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008752", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008752", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008752", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008752", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008752", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008752", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008752", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008752", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008752", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008752", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008752", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008752", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008752", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008752", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008752", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008752", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008752")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008753")
    void case_UTAPI_008753() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008753",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008753", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008753", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008753", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008753", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008753", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008753", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008753", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008753", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008753", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008753", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008753", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008753", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008753", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008753", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008753", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008753", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008753")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008754")
    void case_UTAPI_008754() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008754",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008754", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008754", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008754", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008754", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008754", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008754", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008754", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008754", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008754", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008754", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008754", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008754", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008754", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008754", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008754", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008754", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008754")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008755")
    void case_UTAPI_008755() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008755",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008755", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008755", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008755", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008755", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008755", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008755", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008755", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008755", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008755", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008755", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008755", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008755", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008755", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008755", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008755", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008755", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008755")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008756")
    void case_UTAPI_008756() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008756",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008756", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008756", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008756", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008756", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008756", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008756", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008756", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008756", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008756", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008756", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008756", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008756", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008756", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008756", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008756", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008756", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008756")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008757")
    void case_UTAPI_008757() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008757",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008757", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008757", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008757", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008757", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008757", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008757", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008757", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008757", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008757", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008757", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008757", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008757", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008757", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008757", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008757", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008757", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008757")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008758")
    void case_UTAPI_008758() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008758",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008758", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008758", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008758", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008758", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008758", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008758", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008758", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008758", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008758", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008758", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008758", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008758", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008758", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008758", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008758", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008758", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008758")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008759")
    void case_UTAPI_008759() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008759",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008759", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008759", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008759", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008759", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008759", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008759", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008759", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008759", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008759", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008759", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008759", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008759", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008759", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008759", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008759", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008759", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008759")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008760")
    void case_UTAPI_008760() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008760",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008760", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008760", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008760", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008760", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008760", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008760", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008760", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008760", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008760", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008760", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008760", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008760", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008760", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008760", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008760", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008760", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008760")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008761")
    void case_UTAPI_008761() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008761",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008761", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008761", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008761", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008761", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008761", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008761", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008761", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008761", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008761", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008761", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008761", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008761", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008761", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008761", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008761", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008761", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008761")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008762")
    void case_UTAPI_008762() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008762",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008762", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008762", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008762", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008762", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008762", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008762", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008762", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008762", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008762", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008762", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008762", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008762", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008762", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008762", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008762", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008762", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008762")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008763")
    void case_UTAPI_008763() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008763",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008763", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008763", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008763", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008763", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008763", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008763", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008763", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008763", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008763", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008763", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008763", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008763", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008763", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008763", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008763", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008763", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008763")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008764")
    void case_UTAPI_008764() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008764",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008764", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008764", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008764", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008764", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008764", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008764", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008764", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008764", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008764", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008764", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008764", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008764", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008764", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008764", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008764", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008764", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008764")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008765")
    void case_UTAPI_008765() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008765",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008765", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008765", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008765", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008765", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008765", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008765", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008765", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008765", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008765", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008765", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008765", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008765", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008765", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008765", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008765", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008765", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008765")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008766")
    void case_UTAPI_008766() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008766",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008766", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008766", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008766", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008766", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008766", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008766", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008766", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008766", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008766", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008766", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008766", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008766", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008766", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008766", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008766", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008766", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008766")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008767")
    void case_UTAPI_008767() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008767",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008767", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008767", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008767", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008767", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008767", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008767", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008767", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008767", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008767", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008767", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008767", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008767", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008767", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008767", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008767", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008767", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008767")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008768")
    void case_UTAPI_008768() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008768",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008768", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008768", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008768", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008768", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008768", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008768", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008768", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008768", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008768", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008768", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008768", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008768", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008768", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008768", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008768", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008768", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008768")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008769")
    void case_UTAPI_008769() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008769",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008769", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008769", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008769", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008769", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008769", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008769", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008769", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008769", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008769", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008769", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008769", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008769", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008769", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008769", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008769", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008769", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008769")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::4::-::records")
                    .mirror("-", "1:length_null", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for records reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for records must reach the executed statement unchanged", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008770")
    void case_UTAPI_008770() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008770",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008770", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008770", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008770", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008770", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008770", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008770", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008770", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008770", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008770", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008770", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008770", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008770", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008770", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008770", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008770", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008770", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008770")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::4::-::records")
                    .mirror("-", "2:length_empty", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for records reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for records must reach the executed statement unchanged", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008771")
    void case_UTAPI_008771() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008771",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008771", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008771", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008771", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008771", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008771", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008771", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008771", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008771", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008771", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008771", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008771", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008771", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008771", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008771", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008771", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008771", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008771")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::4::-::records")
                    .mirror("-", "3:length_min", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for records reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for records must reach the executed statement unchanged", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008772")
    void case_UTAPI_008772() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008772",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008772", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008772", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008772", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008772", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008772", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008772", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008772", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008772", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008772", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008772", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008772", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008772", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008772", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008772", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008772", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008772", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008772")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::4::-::records")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for records reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for records must reach the executed statement unchanged", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008773")
    void case_UTAPI_008773() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008773",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008773", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008773", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008773", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008773", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008773", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008773", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008773", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008773", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008773", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008773", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008773", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008773", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008773", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008773", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008773", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008773", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008773")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::4::-::records")
                    .mirror("-", "5:length_max", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for records reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for records must reach the executed statement unchanged", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008774")
    void case_UTAPI_008774() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008774",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008774", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008774", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008774", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008774", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008774", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008774", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008774", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008774", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008774", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008774", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008774", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008774", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008774", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008774", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008774", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008774", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008774")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::4::-::records")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for records reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for records must reach the executed statement unchanged", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008775")
    void case_UTAPI_008775() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008775",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008775", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008775", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008775", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008775", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008775", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008775", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008775", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008775", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008775", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008775", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008775", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-008775", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-008775", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008775", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-008775", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008775", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008775")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::saveHistory::1::ARG::4::-::records")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for records reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for records must reach the executed statement unchanged", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

}

package com.matsushita.dbeditor.utils;

/**
 * Result of one SUT operation executed through a Wrapper.
 */
public final class ExecutionResult {

    private final Object returnValue;
    private final Throwable thrown;

    private ExecutionResult(Object returnValue, Throwable thrown) {
        this.returnValue = returnValue;
        this.thrown = thrown;
    }

    public static ExecutionResult returned(Object value) {
        return new ExecutionResult(value, null);
    }

    public static ExecutionResult threw(Throwable t) {
        return new ExecutionResult(null, t);
    }

    public Object returnValue() {
        return returnValue;
    }

    public Throwable thrown() {
        return thrown;
    }

    public boolean isException() {
        return thrown != null;
    }
}

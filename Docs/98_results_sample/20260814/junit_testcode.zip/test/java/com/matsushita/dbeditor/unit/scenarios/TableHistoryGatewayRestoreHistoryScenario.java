package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableHistoryGatewayWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableHistoryGateway#restoreHistory.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableHistoryGatewayRestoreHistoryScenario {

    @Test
    @DisplayName("UTAPI-004303")
    void case_UTAPI_004303() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004303",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004303", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004303", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004303", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004303", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004303", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004303", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004303", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004303", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004303", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004303", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004303", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004303", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004303", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004303")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004304")
    void case_UTAPI_004304() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004304",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004304", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004304", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004304", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004304", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004304", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004304", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004304", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004304", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004304", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004304", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004304", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004304", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004304", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004304")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004305")
    void case_UTAPI_004305() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004305",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004305", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004305", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004305", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004305", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004305", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004305", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004305", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004305", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004305", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004305", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004305", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004305", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004305", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004305")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004306")
    void case_UTAPI_004306() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004306",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004306", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004306", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004306", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004306", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004306", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004306", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004306", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004306", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004306", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004306", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004306", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004306", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004306", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004306")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004307")
    void case_UTAPI_004307() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004307",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004307", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004307", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004307", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004307", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004307", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004307", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004307", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004307", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004307", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004307", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004307", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004307", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004307", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004307")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004308")
    void case_UTAPI_004308() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004308",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004308", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004308", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004308", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004308", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004308", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004308", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004308", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004308", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004308", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004308", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004308", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004308", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004308", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004308")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004309")
    void case_UTAPI_004309() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004309",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004309", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004309", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004309", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004309", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004309", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004309", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004309", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004309", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004309", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004309", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004309", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004309", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004309", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004309")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004310")
    void case_UTAPI_004310() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004310",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004310", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004310", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004310", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004310", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004310", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004310", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004310", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004310", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004310", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004310", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004310", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004310", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004310", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004310")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004311")
    void case_UTAPI_004311() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004311",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004311", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004311", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004311", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004311", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004311", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004311", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004311", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004311", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004311", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004311", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004311", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004311", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004311", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004311")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004312")
    void case_UTAPI_004312() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004312",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004312", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004312", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004312", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004312", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004312", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004312", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004312", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004312", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004312", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004312", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004312", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004312", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004312", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004312")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004313")
    void case_UTAPI_004313() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004313",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004313", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004313", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004313", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004313", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004313", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004313", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004313", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004313", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004313", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004313", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004313", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004313", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004313", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004313")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004314")
    void case_UTAPI_004314() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004314",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004314", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004314", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004314", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004314", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004314", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004314", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004314", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004314", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004314", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004314", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004314", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004314", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004314", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004314")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004315")
    void case_UTAPI_004315() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004315",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004315", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004315", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004315", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004315", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004315", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004315", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004315", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004315", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004315", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004315", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004315", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004315", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004315", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004315")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004316")
    void case_UTAPI_004316() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004316",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004316", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004316", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004316", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004316", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004316", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004316", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004316", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004316", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004316", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004316", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004316", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004316", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004316", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004316")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004317")
    void case_UTAPI_004317() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004317",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004317", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004317", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004317", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004317", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004317", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004317", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004317", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004317", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004317", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004317", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004317", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004317", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004317", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004317")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004318")
    void case_UTAPI_004318() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004318",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004318", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004318", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004318", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004318", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004318", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004318", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004318", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004318", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004318", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004318", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004318", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004318", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004318", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004318")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004319")
    void case_UTAPI_004319() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004319",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004319", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004319", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004319", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004319", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004319", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004319", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004319", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004319", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004319", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004319", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004319", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004319", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004319", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004319")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004320")
    void case_UTAPI_004320() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004320",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004320", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004320", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004320", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004320", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004320", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004320", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004320", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004320", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004320", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004320", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004320", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004320", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004320", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004320")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004321")
    void case_UTAPI_004321() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004321",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004321", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004321", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004321", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004321", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004321", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004321", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004321", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004321", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004321", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004321", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004321", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004321", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004321", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004321")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004322")
    void case_UTAPI_004322() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004322",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004322", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004322", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004322", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004322", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004322", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004322", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004322", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004322", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004322", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004322", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004322", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004322", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004322", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004322")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004323")
    void case_UTAPI_004323() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004323",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004323", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004323", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004323", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004323", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004323", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004323", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004323", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004323", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004323", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004323", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004323", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004323", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004323", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004323")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004324")
    void case_UTAPI_004324() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004324",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004324", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004324", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004324", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004324", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004324", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004324", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004324", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004324", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004324", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004324", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004324", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004324", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004324", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004324")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004325")
    void case_UTAPI_004325() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004325",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004325", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004325", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004325", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004325", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004325", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004325", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004325", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004325", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004325", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004325", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004325", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004325", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004325", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004325")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004326")
    void case_UTAPI_004326() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004326",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004326", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004326", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004326", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004326", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004326", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004326", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004326", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004326", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004326", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004326", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004326", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004326", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004326", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004326")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004327")
    void case_UTAPI_004327() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004327",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004327", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004327", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004327", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004327", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004327", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004327", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004327", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004327", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004327", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004327", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004327", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004327", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004327", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004327")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004328")
    void case_UTAPI_004328() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004328",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004328", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004328", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004328", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004328", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004328", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004328", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004328", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004328", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004328", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004328", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004328", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004328", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004328", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004328")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004329")
    void case_UTAPI_004329() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004329",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004329", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004329", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004329", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004329", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004329", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004329", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004329", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004329", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004329", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004329", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004329", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004329", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004329", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004329")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004330")
    void case_UTAPI_004330() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004330",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004330", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004330", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004330", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004330", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004330", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004330", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004330", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004330", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004330", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004330", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004330", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004330", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004330", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004330")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004331")
    void case_UTAPI_004331() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004331",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004331", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004331", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004331", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004331", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004331", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004331", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004331", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004331", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004331", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004331", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004331", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004331", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004331", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004331")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004332")
    void case_UTAPI_004332() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004332",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004332", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004332", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004332", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004332", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004332", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004332", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004332", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004332", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004332", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004332", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004332", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004332", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004332", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004332")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004333")
    void case_UTAPI_004333() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004333",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004333", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004333", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004333", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004333", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004333", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004333", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004333", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004333", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004333", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004333", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004333", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004333", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004333", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004333")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004334")
    void case_UTAPI_004334() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004334",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004334", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004334", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004334", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004334", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004334", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004334", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004334", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004334", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004334", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004334", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004334", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004334", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004334", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004334")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004335")
    void case_UTAPI_004335() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004335",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004335", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004335", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004335", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004335", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004335", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004335", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004335", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004335", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004335", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004335", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004335", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004335", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004335", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004335")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004336")
    void case_UTAPI_004336() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004336",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004336", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004336", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004336", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004336", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004336", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004336", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004336", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004336", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004336", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004336", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004336", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004336", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004336", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004336")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004337")
    void case_UTAPI_004337() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004337",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004337", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004337", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004337", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004337", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004337", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004337", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004337", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004337", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004337", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004337", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004337", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004337", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004337", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004337")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004338")
    void case_UTAPI_004338() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004338",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004338", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004338", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004338", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004338", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004338", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004338", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004338", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004338", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004338", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004338", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004338", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004338", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004338", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004338")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004339")
    void case_UTAPI_004339() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004339",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004339", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004339", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004339", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004339", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004339", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004339", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004339", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004339", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004339", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004339", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004339", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004339", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004339", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004339")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004340")
    void case_UTAPI_004340() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004340",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004340", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004340", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004340", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004340", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004340", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004340", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004340", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004340", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004340", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004340", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004340", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004340", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004340", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004340")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004341")
    void case_UTAPI_004341() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004341",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004341", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004341", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004341", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004341", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004341", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004341", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004341", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004341", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004341", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004341", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004341", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004341", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004341", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004341")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004342")
    void case_UTAPI_004342() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004342",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004342", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004342", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004342", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004342", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004342", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004342", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004342", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004342", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004342", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004342", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004342", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004342", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004342", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004342")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004343")
    void case_UTAPI_004343() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004343",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004343", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004343", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004343", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004343", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004343", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004343", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004343", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004343", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004343", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004343", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004343", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004343", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004343", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004343")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004344")
    void case_UTAPI_004344() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004344",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004344", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004344", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004344", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004344", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004344", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004344", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004344", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004344", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004344", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004344", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004344", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004344", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004344", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004344")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004345")
    void case_UTAPI_004345() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004345",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004345", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004345", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004345", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004345", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004345", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004345", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004345", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004345", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004345", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004345", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004345", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004345", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004345", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004345")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004346")
    void case_UTAPI_004346() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004346",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004346", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004346", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004346", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004346", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004346", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004346", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004346", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004346", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004346", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004346", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004346", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004346", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004346", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004346")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004347")
    void case_UTAPI_004347() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004347",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004347", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004347", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004347", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004347", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004347", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004347", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004347", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004347", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004347", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004347", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004347", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004347", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004347", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004347")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004348")
    void case_UTAPI_004348() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004348",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004348", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004348", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004348", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004348", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004348", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004348", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004348", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004348", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004348", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004348", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004348", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004348", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004348", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004348")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004349")
    void case_UTAPI_004349() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004349",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004349", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004349", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004349", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004349", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004349", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004349", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004349", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004349", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004349", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004349", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004349", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004349", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004349", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004349")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004350")
    void case_UTAPI_004350() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004350",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004350", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004350", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004350", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004350", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004350", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004350", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004350", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004350", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004350", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004350", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004350", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004350", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004350", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004350")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004351")
    void case_UTAPI_004351() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004351",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004351", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004351", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004351", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004351", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004351", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004351", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004351", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004351", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004351", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004351", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004351", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004351", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004351", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004351")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004352")
    void case_UTAPI_004352() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004352",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004352", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004352", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004352", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004352", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004352", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004352", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004352", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004352", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004352", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004352", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004352", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004352", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004352", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004352")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004353")
    void case_UTAPI_004353() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004353",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004353", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004353", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004353", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004353", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004353", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004353", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004353", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004353", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004353", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004353", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004353", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004353", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004353", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004353")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004354")
    void case_UTAPI_004354() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004354",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004354", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004354", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004354", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004354", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004354", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004354", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004354", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004354", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004354", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004354", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004354", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004354", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004354", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004354")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004355")
    void case_UTAPI_004355() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004355",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004355", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004355", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004355", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004355", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004355", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004355", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004355", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004355", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004355", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004355", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004355", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004355", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004355", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004355")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004356")
    void case_UTAPI_004356() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004356",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004356", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004356", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004356", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004356", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004356", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004356", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004356", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004356", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004356", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004356", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004356", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004356", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004356", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004356")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004357")
    void case_UTAPI_004357() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004357",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004357", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004357", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004357", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004357", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004357", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004357", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004357", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004357", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004357", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004357", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004357", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004357", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004357", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004357")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004358")
    void case_UTAPI_004358() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004358",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004358", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004358", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004358", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004358", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004358", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004358", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004358", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004358", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004358", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004358", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004358", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004358", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004358", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004358")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004359")
    void case_UTAPI_004359() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004359",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004359", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004359", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004359", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004359", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004359", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004359", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004359", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004359", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004359", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004359", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004359", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004359", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004359", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004359")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004360")
    void case_UTAPI_004360() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004360",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004360", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004360", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004360", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004360", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004360", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004360", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004360", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004360", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004360", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004360", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004360", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004360", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004360", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004360")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004361")
    void case_UTAPI_004361() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004361",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004361", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004361", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004361", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004361", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004361", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004361", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004361", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004361", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004361", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004361", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004361", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004361", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004361", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004361")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004362")
    void case_UTAPI_004362() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004362",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004362", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004362", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004362", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004362", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004362", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004362", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004362", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004362", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004362", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004362", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004362", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004362", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004362", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004362")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004363")
    void case_UTAPI_004363() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004363",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004363", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004363", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004363", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004363", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004363", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004363", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004363", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004363", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004363", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004363", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004363", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004363", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004363", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004363")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004364")
    void case_UTAPI_004364() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004364",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004364", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004364", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004364", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004364", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004364", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004364", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004364", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004364", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004364", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004364", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004364", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004364", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004364", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004364")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004365")
    void case_UTAPI_004365() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004365",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004365", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004365", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004365", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004365", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004365", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004365", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004365", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004365", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004365", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004365", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004365", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004365", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004365", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004365")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004366")
    void case_UTAPI_004366() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004366",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004366", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004366", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004366", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004366", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004366", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004366", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004366", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004366", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004366", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004366", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004366", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004366", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004366", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004366")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004367")
    void case_UTAPI_004367() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004367",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004367", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004367", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004367", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004367", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004367", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004367", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004367", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004367", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004367", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004367", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004367", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004367", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004367", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004367")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004368")
    void case_UTAPI_004368() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004368",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004368", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004368", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004368", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004368", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004368", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004368", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004368", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004368", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004368", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004368", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004368", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004368", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004368", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004368")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004369")
    void case_UTAPI_004369() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004369",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004369", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004369", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004369", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004369", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004369", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004369", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004369", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004369", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004369", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004369", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004369", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004369", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004369", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004369")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004370")
    void case_UTAPI_004370() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004370",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004370", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004370", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004370", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004370", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004370", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004370", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004370", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004370", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004370", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004370", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004370", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004370", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004370", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004370")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004371")
    void case_UTAPI_004371() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004371",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004371", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004371", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004371", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004371", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004371", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004371", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004371", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004371", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004371", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004371", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004371", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004371", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004371", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004371")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004372")
    void case_UTAPI_004372() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004372",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004372", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004372", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004372", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004372", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004372", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004372", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004372", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004372", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004372", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004372", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004372", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004372", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004372", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004372")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004373")
    void case_UTAPI_004373() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004373",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004373", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004373", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004373", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004373", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004373", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004373", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004373", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004373", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004373", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004373", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004373", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004373", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004373", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004373")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004374")
    void case_UTAPI_004374() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004374",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004374", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004374", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004374", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004374", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004374", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004374", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004374", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004374", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004374", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004374", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004374", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004374", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004374", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004374")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004375")
    void case_UTAPI_004375() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004375",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004375", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004375", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004375", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004375", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004375", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004375", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004375", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004375", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004375", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004375", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004375", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004375", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004375", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004375")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004376")
    void case_UTAPI_004376() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004376",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004376", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004376", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004376", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004376", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004376", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004376", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004376", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004376", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004376", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004376", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004376", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004376", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004376", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004376")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004377")
    void case_UTAPI_004377() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004377",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004377", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004377", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004377", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004377", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004377", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004377", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004377", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004377", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004377", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004377", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004377", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004377", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004377", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004377")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004378")
    void case_UTAPI_004378() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004378",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004378", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004378", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004378", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004378", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004378", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004378", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004378", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004378", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004378", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004378", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004378", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004378", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004378", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004378")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004379")
    void case_UTAPI_004379() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004379",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004379", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004379", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004379", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004379", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004379", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004379", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004379", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004379", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004379", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004379", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004379", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004379", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004379", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004379")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004380")
    void case_UTAPI_004380() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004380",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004380", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004380", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004380", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004380", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004380", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004380", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004380", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004380", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004380", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004380", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004380", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004380", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004380", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004380")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004381")
    void case_UTAPI_004381() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004381",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004381", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004381", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004381", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004381", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004381", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004381", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004381", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004381", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004381", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004381", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004381", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004381", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004381", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004381")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004382")
    void case_UTAPI_004382() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004382",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004382", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004382", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004382", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004382", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004382", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004382", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004382", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004382", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004382", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004382", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004382", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004382", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004382", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004382")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004383")
    void case_UTAPI_004383() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004383",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004383", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004383", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004383", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004383", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004383", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004383", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004383", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004383", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004383", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004383", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004383", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004383", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004383", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004383")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004384")
    void case_UTAPI_004384() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004384",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004384", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004384", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004384", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004384", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004384", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004384", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004384", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004384", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004384", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004384", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004384", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004384", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004384", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004384")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004385")
    void case_UTAPI_004385() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004385",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004385", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004385", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004385", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004385", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004385", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004385", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004385", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004385", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004385", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004385", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004385", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004385", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004385", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004385")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004386")
    void case_UTAPI_004386() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004386",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004386", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004386", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004386", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004386", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004386", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004386", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004386", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004386", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004386", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004386", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004386", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004386", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004386", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004386")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004387")
    void case_UTAPI_004387() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004387",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004387", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004387", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004387", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004387", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004387", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004387", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004387", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004387", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004387", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004387", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004387", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004387", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004387", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004387")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004388")
    void case_UTAPI_004388() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004388",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004388", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004388", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004388", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004388", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004388", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004388", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004388", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004388", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004388", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004388", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004388", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004388", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004388", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004388")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004389")
    void case_UTAPI_004389() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004389",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004389", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004389", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004389", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004389", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004389", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004389", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004389", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004389", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004389", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004389", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004389", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004389", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004389", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004389")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004390")
    void case_UTAPI_004390() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004390",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004390", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004390", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004390", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004390", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004390", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004390", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004390", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004390", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004390", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004390", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004390", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004390", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004390", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004390")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004391")
    void case_UTAPI_004391() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004391",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004391", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004391", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004391", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004391", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004391", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004391", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004391", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004391", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004391", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004391", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004391", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004391", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004391", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004391")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004392")
    void case_UTAPI_004392() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004392",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004392", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004392", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004392", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004392", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004392", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004392", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004392", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004392", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004392", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004392", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004392", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004392", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004392", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004392")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004393")
    void case_UTAPI_004393() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004393",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004393", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004393", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004393", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004393", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004393", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004393", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004393", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004393", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004393", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004393", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004393", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004393", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004393", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004393")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004394")
    void case_UTAPI_004394() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004394",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004394", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004394", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004394", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004394", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004394", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004394", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004394", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004394", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004394", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004394", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004394", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004394", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004394", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004394")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004395")
    void case_UTAPI_004395() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004395",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004395", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004395", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004395", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004395", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004395", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004395", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004395", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004395", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004395", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004395", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004395", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004395", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004395", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004395")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004396")
    void case_UTAPI_004396() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004396",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004396", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004396", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004396", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004396", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004396", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004396", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004396", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004396", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004396", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004396", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004396", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004396", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004396", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004396")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004397")
    void case_UTAPI_004397() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004397",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004397", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004397", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004397", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004397", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004397", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004397", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004397", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004397", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004397", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004397", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004397", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004397", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004397", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004397")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004398")
    void case_UTAPI_004398() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004398",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004398", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004398", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004398", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004398", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004398", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004398", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004398", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004398", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004398", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004398", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004398", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004398", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004398", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004398")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004399")
    void case_UTAPI_004399() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004399",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004399", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004399", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004399", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004399", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004399", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004399", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004399", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004399", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004399", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004399", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004399", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004399", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004399", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004399")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004400")
    void case_UTAPI_004400() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004400",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004400", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004400", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004400", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004400", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004400", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004400", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004400", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004400", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004400", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004400", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004400", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004400", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004400", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004400")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004401")
    void case_UTAPI_004401() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004401",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004401", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004401", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004401", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004401", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004401", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004401", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004401", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004401", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004401", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004401", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004401", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004401", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004401", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004401")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004402")
    void case_UTAPI_004402() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004402",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004402", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004402", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004402", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004402", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004402", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004402", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004402", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004402", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004402", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004402", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004402", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004402", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004402", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004402")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004403")
    void case_UTAPI_004403() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004403",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004403", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004403", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004403", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004403", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004403", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004403", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004403", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004403", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004403", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004403", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004403", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004403", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004403", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004403")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004404")
    void case_UTAPI_004404() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004404",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004404", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004404", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004404", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004404", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004404", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004404", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004404", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004404", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004404", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004404", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004404", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004404", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004404", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004404")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004405")
    void case_UTAPI_004405() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004405",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004405", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004405", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004405", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004405", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004405", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004405", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004405", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004405", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004405", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004405", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004405", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004405", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004405", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004405")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004406")
    void case_UTAPI_004406() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004406",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004406", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004406", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004406", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004406", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004406", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004406", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004406", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004406", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004406", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004406", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004406", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004406", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004406", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004406")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004407")
    void case_UTAPI_004407() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004407",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004407", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004407", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004407", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004407", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004407", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004407", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004407", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004407", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004407", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004407", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004407", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004407", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004407", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004407")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004408")
    void case_UTAPI_004408() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004408",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004408", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004408", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004408", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004408", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004408", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004408", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004408", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004408", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004408", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004408", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004408", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004408", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004408", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004408")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004409")
    void case_UTAPI_004409() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004409",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004409", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004409", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004409", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004409", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004409", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004409", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004409", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004409", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004409", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004409", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004409", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004409", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004409", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004409")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004410")
    void case_UTAPI_004410() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004410",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004410", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004410", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004410", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004410", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004410", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004410", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004410", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004410", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004410", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004410", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004410", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004410", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004410", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004410")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004411")
    void case_UTAPI_004411() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004411",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004411", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004411", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004411", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004411", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004411", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004411", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004411", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004411", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004411", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004411", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004411", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004411", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004411", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004411")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004412")
    void case_UTAPI_004412() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004412",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004412", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004412", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004412", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004412", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004412", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004412", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004412", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004412", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004412", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004412", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004412", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004412", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004412", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004412")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004413")
    void case_UTAPI_004413() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004413",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004413", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004413", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004413", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004413", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004413", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004413", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004413", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004413", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004413", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004413", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004413", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004413", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004413", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004413")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004414")
    void case_UTAPI_004414() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004414",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004414", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004414", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004414", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004414", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004414", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004414", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004414", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004414", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004414", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004414", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004414", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004414", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004414", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004414")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004415")
    void case_UTAPI_004415() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004415",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004415", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004415", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004415", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004415", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004415", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004415", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004415", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004415", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004415", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004415", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004415", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004415", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004415", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004415")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004416")
    void case_UTAPI_004416() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004416",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004416", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004416", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004416", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004416", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004416", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004416", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004416", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004416", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004416", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004416", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004416", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004416", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004416", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004416")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004417")
    void case_UTAPI_004417() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004417",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004417", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004417", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004417", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004417", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004417", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004417", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004417", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004417", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004417", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004417", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004417", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004417", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004417", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004417")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004418")
    void case_UTAPI_004418() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004418",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004418", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004418", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004418", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004418", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004418", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004418", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004418", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004418", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004418", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004418", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004418", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004418", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004418", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004418")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004419")
    void case_UTAPI_004419() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004419",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004419", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004419", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004419", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004419", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004419", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004419", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004419", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004419", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004419", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004419", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004419", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004419", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004419", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004419")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004420")
    void case_UTAPI_004420() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004420",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004420", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004420", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004420", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004420", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004420", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004420", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004420", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004420", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004420", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004420", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004420", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004420", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004420", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004420")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004421")
    void case_UTAPI_004421() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004421",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004421", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004421", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004421", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004421", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004421", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004421", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004421", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004421", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004421", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004421", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004421", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004421", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004421", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004421")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004422")
    void case_UTAPI_004422() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004422",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004422", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004422", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004422", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004422", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004422", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004422", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004422", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004422", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004422", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004422", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004422", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004422", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004422", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004422")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004423")
    void case_UTAPI_004423() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004423",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004423", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004423", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004423", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004423", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004423", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004423", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004423", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004423", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004423", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004423", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004423", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004423", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004423", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004423")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004424")
    void case_UTAPI_004424() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004424",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004424", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004424", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004424", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004424", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004424", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004424", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004424", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004424", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004424", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004424", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004424", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004424", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004424", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004424")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004425")
    void case_UTAPI_004425() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004425",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004425", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004425", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004425", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004425", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004425", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004425", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004425", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004425", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004425", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004425", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004425", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004425", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004425", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004425")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004426")
    void case_UTAPI_004426() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004426",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004426", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004426", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004426", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004426", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004426", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004426", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004426", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004426", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004426", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004426", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004426", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004426", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004426", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004426")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004427")
    void case_UTAPI_004427() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004427",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004427", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004427", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004427", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004427", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004427", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004427", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004427", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004427", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004427", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004427", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004427", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004427", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004427", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004427")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004428")
    void case_UTAPI_004428() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004428",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004428", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004428", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004428", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004428", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004428", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004428", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004428", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004428", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004428", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004428", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004428", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004428", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004428", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004428")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004429")
    void case_UTAPI_004429() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004429",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004429", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004429", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004429", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004429", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004429", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004429", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004429", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004429", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004429", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004429", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004429", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004429", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004429", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004429")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004430")
    void case_UTAPI_004430() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004430",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004430", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004430", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004430", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004430", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004430", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004430", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004430", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004430", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004430", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004430", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004430", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004430", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004430", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004430")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004431")
    void case_UTAPI_004431() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004431",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004431", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004431", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004431", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004431", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004431", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004431", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004431", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004431", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004431", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004431", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004431", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004431", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004431", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004431")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004432")
    void case_UTAPI_004432() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004432",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004432", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004432", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004432", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004432", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004432", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004432", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004432", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004432", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004432", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004432", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004432", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004432", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004432", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004432")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004433")
    void case_UTAPI_004433() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004433",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004433", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004433", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004433", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004433", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004433", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004433", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004433", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004433", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004433", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004433", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004433", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004433", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004433", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004433")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004434")
    void case_UTAPI_004434() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004434",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004434", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004434", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004434", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004434", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004434", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004434", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004434", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004434", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004434", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004434", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004434", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004434", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004434", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004434")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004435")
    void case_UTAPI_004435() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004435",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004435", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004435", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004435", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004435", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004435", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004435", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004435", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004435", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004435", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004435", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004435", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004435", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004435", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004435")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004436")
    void case_UTAPI_004436() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004436",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004436", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004436", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004436", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004436", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004436", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004436", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004436", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004436", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004436", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004436", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004436", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004436", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004436", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004436")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004437")
    void case_UTAPI_004437() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004437",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004437", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004437", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004437", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004437", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004437", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004437", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004437", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004437", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004437", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004437", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004437", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004437", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004437", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004437")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004438")
    void case_UTAPI_004438() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004438",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004438", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004438", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004438", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004438", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004438", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004438", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004438", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004438", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004438", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004438", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004438", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004438", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004438", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004438")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004439")
    void case_UTAPI_004439() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004439",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004439", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004439", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004439", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004439", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004439", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004439", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004439", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004439", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004439", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004439", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004439", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004439", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004439", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004439")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004440")
    void case_UTAPI_004440() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004440",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004440", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004440", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004440", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004440", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004440", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004440", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004440", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004440", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004440", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004440", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004440", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004440", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004440", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004440")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004441")
    void case_UTAPI_004441() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004441",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004441", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004441", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004441", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004441", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004441", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004441", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004441", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004441", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004441", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004441", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004441", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004441", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004441", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004441")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004442")
    void case_UTAPI_004442() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004442",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004442", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004442", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004442", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004442", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004442", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004442", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004442", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004442", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004442", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004442", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004442", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004442", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004442", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004442")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004443")
    void case_UTAPI_004443() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004443",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004443", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004443", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004443", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004443", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004443", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004443", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004443", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004443", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004443", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004443", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004443", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004443", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004443", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004443")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004444")
    void case_UTAPI_004444() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004444",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004444", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004444", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004444", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004444", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004444", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004444", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004444", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004444", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004444", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004444", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004444", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004444", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004444", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004444")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004445")
    void case_UTAPI_004445() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004445",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004445", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004445", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004445", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004445", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004445", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004445", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004445", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004445", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004445", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004445", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004445", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004445", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004445", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004445")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004446")
    void case_UTAPI_004446() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004446",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004446", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004446", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004446", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004446", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004446", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004446", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004446", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004446", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004446", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004446", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004446", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004446", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004446", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004446")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004447")
    void case_UTAPI_004447() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004447",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004447", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004447", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004447", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004447", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004447", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004447", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004447", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004447", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004447", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004447", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004447", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004447", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004447", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004447")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004448")
    void case_UTAPI_004448() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004448",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004448", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004448", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004448", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004448", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004448", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004448", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004448", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004448", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004448", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004448", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004448", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004448", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004448", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004448")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004449")
    void case_UTAPI_004449() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004449",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004449", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004449", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004449", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004449", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004449", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004449", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004449", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004449", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004449", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004449", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004449", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004449", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004449", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004449")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004450")
    void case_UTAPI_004450() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004450",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004450", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004450", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004450", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004450", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004450", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004450", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004450", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004450", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004450", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004450", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004450", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004450", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004450", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004450")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004451")
    void case_UTAPI_004451() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004451",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004451", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004451", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004451", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004451", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004451", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004451", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004451", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004451", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004451", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004451", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004451", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004451", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004451", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004451")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004452")
    void case_UTAPI_004452() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004452",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004452", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004452", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004452", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004452", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004452", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004452", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004452", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004452", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004452", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004452", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004452", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004452", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004452", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004452")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004453")
    void case_UTAPI_004453() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004453",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004453", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004453", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004453", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004453", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004453", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004453", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004453", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004453", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004453", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004453", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004453", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004453", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004453", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004453")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004454")
    void case_UTAPI_004454() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004454",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004454", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004454", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004454", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004454", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004454", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004454", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004454", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004454", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004454", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004454", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004454", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004454", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004454", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004454")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004455")
    void case_UTAPI_004455() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004455",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004455", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004455", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004455", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004455", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004455", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004455", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004455", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004455", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004455", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004455", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004455", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004455", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004455", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004455")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004456")
    void case_UTAPI_004456() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004456",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004456", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004456", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004456", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004456", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004456", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004456", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004456", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004456", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004456", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004456", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004456", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004456", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004456", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004456")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004457")
    void case_UTAPI_004457() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004457",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004457", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004457", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004457", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004457", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004457", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004457", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004457", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004457", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004457", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004457", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004457", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004457", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004457", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004457")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004458")
    void case_UTAPI_004458() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004458",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004458", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004458", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004458", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004458", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004458", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004458", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004458", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004458", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004458", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004458", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004458", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004458", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004458", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004458")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004459")
    void case_UTAPI_004459() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004459",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004459", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004459", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004459", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004459", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004459", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004459", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004459", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004459", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004459", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004459", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004459", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004459", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004459", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004459")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004460")
    void case_UTAPI_004460() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004460",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004460", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004460", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004460", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004460", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004460", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004460", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004460", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004460", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004460", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004460", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004460", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004460", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004460", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004460")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004461")
    void case_UTAPI_004461() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004461",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004461", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004461", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004461", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004461", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004461", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004461", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004461", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004461", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004461", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004461", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004461", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004461", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004461", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004461")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004462")
    void case_UTAPI_004462() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004462",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004462", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004462", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004462", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004462", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004462", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004462", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004462", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004462", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004462", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004462", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004462", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004462", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004462", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004462")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004463")
    void case_UTAPI_004463() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004463",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004463", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004463", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004463", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004463", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004463", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004463", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004463", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004463", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004463", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004463", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004463", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004463", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004463", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004463")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004464")
    void case_UTAPI_004464() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004464",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004464", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004464", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004464", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004464", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004464", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004464", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004464", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004464", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004464", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004464", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004464", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004464", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004464", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004464")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004465")
    void case_UTAPI_004465() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004465",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004465", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004465", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004465", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004465", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004465", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004465", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004465", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004465", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004465", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004465", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004465", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004465", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004465", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004465")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004466")
    void case_UTAPI_004466() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004466",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004466", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004466", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004466", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004466", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004466", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004466", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004466", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004466", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004466", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004466", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004466", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004466", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004466", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004466")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004467")
    void case_UTAPI_004467() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004467",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004467", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004467", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004467", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004467", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004467", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004467", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004467", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004467", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004467", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004467", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004467", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004467", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004467", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004467")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004468")
    void case_UTAPI_004468() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004468",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004468", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004468", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004468", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004468", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004468", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004468", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004468", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004468", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004468", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004468", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004468", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004468", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004468", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004468")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004469")
    void case_UTAPI_004469() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004469",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004469", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004469", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004469", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004469", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004469", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004469", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004469", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004469", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004469", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004469", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004469", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004469", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004469", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004469")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004470")
    void case_UTAPI_004470() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004470",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004470", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004470", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004470", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004470", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004470", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004470", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004470", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004470", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004470", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004470", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004470", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004470", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004470", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004470")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004471")
    void case_UTAPI_004471() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004471",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004471", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004471", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004471", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004471", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004471", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004471", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004471", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004471", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004471", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004471", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004471", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004471", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004471", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004471")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004472")
    void case_UTAPI_004472() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004472",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004472", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004472", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004472", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004472", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004472", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004472", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004472", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004472", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004472", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004472", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004472", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004472", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004472", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004472")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004473")
    void case_UTAPI_004473() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004473",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004473", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004473", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004473", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004473", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004473", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004473", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004473", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004473", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004473", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004473", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004473", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004473", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004473", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004473")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004474")
    void case_UTAPI_004474() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004474",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004474", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004474", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004474", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004474", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004474", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004474", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004474", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004474", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004474", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004474", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004474", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004474", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004474", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004474")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004475")
    void case_UTAPI_004475() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004475",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004475", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004475", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004475", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004475", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004475", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004475", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004475", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004475", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004475", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004475", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004475", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004475", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004475", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004475")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004476")
    void case_UTAPI_004476() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004476",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004476", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004476", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004476", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004476", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004476", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004476", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004476", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004476", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004476", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004476", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004476", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004476", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004476", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004476")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004477")
    void case_UTAPI_004477() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004477",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004477", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004477", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004477", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004477", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004477", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004477", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004477", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004477", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004477", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004477", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004477", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004477", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004477", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004477")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004478")
    void case_UTAPI_004478() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004478",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004478", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004478", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004478", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004478", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004478", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004478", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004478", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004478", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004478", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004478", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004478", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004478", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004478", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004478")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004479")
    void case_UTAPI_004479() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004479",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004479", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004479", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004479", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004479", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004479", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004479", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004479", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004479", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004479", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004479", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004479", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004479", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004479", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004479")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004480")
    void case_UTAPI_004480() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004480",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004480", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004480", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004480", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004480", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004480", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004480", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004480", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004480", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004480", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004480", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004480", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004480", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004480", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004480")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004481")
    void case_UTAPI_004481() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004481",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004481", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004481", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004481", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004481", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004481", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004481", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004481", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004481", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004481", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004481", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004481", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004481", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004481", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004481")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004482")
    void case_UTAPI_004482() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004482",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004482", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004482", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004482", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004482", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004482", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004482", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004482", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004482", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004482", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004482", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004482", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004482", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004482", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004482")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004483")
    void case_UTAPI_004483() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004483",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004483", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004483", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004483", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004483", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004483", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004483", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004483", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004483", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004483", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004483", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004483", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004483", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004483", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004483")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004484")
    void case_UTAPI_004484() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004484",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004484", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004484", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004484", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004484", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004484", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004484", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004484", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004484", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004484", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004484", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004484", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004484", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004484", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004484")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004485")
    void case_UTAPI_004485() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004485",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004485", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004485", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004485", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004485", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004485", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004485", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004485", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004485", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004485", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004485", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004485", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004485", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004485", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004485")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004486")
    void case_UTAPI_004486() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004486",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004486", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004486", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004486", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004486", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004486", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004486", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004486", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004486", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004486", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004486", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004486", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004486", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004486", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004486")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::4::-::seq")
                    .mirror("-", "1:length_null", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004487")
    void case_UTAPI_004487() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004487",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004487", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004487", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004487", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004487", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004487", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004487", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004487", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004487", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004487", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004487", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004487", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004487", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004487", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004487")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::4::-::seq")
                    .mirror("-", "2:length_empty", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004488")
    void case_UTAPI_004488() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004488",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004488", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004488", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004488", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004488", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004488", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004488", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004488", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004488", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004488", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004488", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004488", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004488", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004488", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004488")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::4::-::seq")
                    .mirror("-", "3:length_min", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004489")
    void case_UTAPI_004489() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004489",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004489", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004489", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004489", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004489", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004489", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004489", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004489", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004489", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004489", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004489", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004489", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004489", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004489", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004489")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::4::-::seq")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004490")
    void case_UTAPI_004490() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004490",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004490", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004490", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004490", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004490", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004490", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004490", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004490", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004490", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004490", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004490", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004490", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004490", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004490", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004490")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::4::-::seq")
                    .mirror("-", "5:length_max", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004491")
    void case_UTAPI_004491() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004491",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004491", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004491", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004491", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004491", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004491", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004491", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004491", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004491", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004491", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004491", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004491", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004491", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004491", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004491")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::4::-::seq")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004492")
    void case_UTAPI_004492() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004492",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004492", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004492", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004492", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004492", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004492", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004492", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004492", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004492", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004492", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004492", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004492", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004492", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004492", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004492")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::4::-::seq")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004493")
    void case_UTAPI_004493() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004493",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004493", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004493", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004493", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004493", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004493", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004493", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004493", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004493", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004493", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004493", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004493", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004493", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004493", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004493")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::4::-::seq")
                    .mirror("46:hw_integer", "-", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004494")
    void case_UTAPI_004494() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004494",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004494", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004494", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004494", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004494", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004494", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004494", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004494", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004494", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004494", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004494", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004494", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004494", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004494", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004494")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::4::-::seq")
                    .mirror("-", "-", "12:integer_positive")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004495")
    void case_UTAPI_004495() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004495",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004495", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004495", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004495", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004495", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004495", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004495", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004495", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004495", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004495", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004495", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004495", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004495", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004495", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004495")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::4::-::seq")
                    .mirror("-", "-", "13:integer_negative")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004496")
    void case_UTAPI_004496() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004496",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004496", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004496", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004496", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004496", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004496", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004496", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004496", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004496", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004496", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004496", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004496", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004496", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004496", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004496")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::restoreHistory::6::ARG::4::-::seq")
                    .mirror("-", "-", "14:integer_zero")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

}

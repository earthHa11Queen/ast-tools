package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Operation wrapper for HealthController.
 */
public final class HealthControllerWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.adapter.controller.HealthController";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.adapter.controller.HealthController";
    private static final String[] DEP_NAMES = new String[] {};
    private static final String[] DEP_TYPES = new String[] {};
    private static final String[] TYPES_health = new String[] {};

    public HealthControllerWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, false);
    }

    /** ResponseEntity<Map<String,String>> health() */
    public ExecutionResult health(Object[] args) {
        return invoke("health", TYPES_health, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("health".equals(operation)) {
            return health(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

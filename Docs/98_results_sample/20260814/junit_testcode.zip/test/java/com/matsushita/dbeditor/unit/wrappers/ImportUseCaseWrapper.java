package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Operation wrapper for ImportUseCase.
 */
public final class ImportUseCaseWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.usecase.file.ImportUseCase";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.usecase.file.ImportUseCase";
    private static final String[] DEP_NAMES = new String[] {"connectionSettingRepository", "importRepository"};
    private static final String[] DEP_TYPES = new String[] {"ConnectionSettingRepository", "ImportRepository"};
    private static final String[] TYPES_applyMapping = new String[] {"Integer", "String", "String", "Map<String, String>", "List<Map<String, String>>"};
    private static final String[] TYPES_createTableAndImport = new String[] {"Integer", "String", "String", "List<String>", "List<String>", "List<Map<String, String>>"};
    private static final String[] TYPES_csvAutoMapping = new String[] {"Integer", "String", "String", "MultipartFile"};
    private static final String[] TYPES_excelSheetAutoMapping = new String[] {"Integer", "String", "String", "MultipartFile", "int"};
    private static final String[] TYPES_getConnection = new String[] {"Integer"};
    private static final String[] TYPES_getExcelSheetNames = new String[] {"MultipartFile"};
    private static final String[] TYPES_normalize = new String[] {"String"};
    private static final String[] TYPES_parseCsv = new String[] {"InputStream"};
    private static final String[] TYPES_splitCsvLine = new String[] {"String"};

    public ImportUseCaseWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, false);
    }

    /** void applyMapping(connectionId, tableName, schemaName, mapping, rows) */
    public ExecutionResult applyMapping(Object[] args) {
        return invoke("applyMapping", TYPES_applyMapping, args);
    }

    /** void createTableAndImport(connectionId, tableName, schemaName, columns, columnTypes, rows) */
    public ExecutionResult createTableAndImport(Object[] args) {
        return invoke("createTableAndImport", TYPES_createTableAndImport, args);
    }

    /** AutoMappingResponse csvAutoMapping(connectionId, tableName, schemaName, file) */
    public ExecutionResult csvAutoMapping(Object[] args) {
        return invoke("csvAutoMapping", TYPES_csvAutoMapping, args);
    }

    /** AutoMappingResponse excelSheetAutoMapping(connectionId, tableName, schemaName, file, sheetIndex) */
    public ExecutionResult excelSheetAutoMapping(Object[] args) {
        return invoke("excelSheetAutoMapping", TYPES_excelSheetAutoMapping, args);
    }

    /** ConnectionSetting getConnection(connectionId) */
    public ExecutionResult getConnection(Object[] args) {
        return invoke("getConnection", TYPES_getConnection, args);
    }

    /** List<String> getExcelSheetNames(file) */
    public ExecutionResult getExcelSheetNames(Object[] args) {
        return invoke("getExcelSheetNames", TYPES_getExcelSheetNames, args);
    }

    /** String normalize(s) */
    public ExecutionResult normalize(Object[] args) {
        return invoke("normalize", TYPES_normalize, args);
    }

    /** List<String[]> parseCsv(is) */
    public ExecutionResult parseCsv(Object[] args) {
        return invoke("parseCsv", TYPES_parseCsv, args);
    }

    /** String[] splitCsvLine(line) */
    public ExecutionResult splitCsvLine(Object[] args) {
        return invoke("splitCsvLine", TYPES_splitCsvLine, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("applyMapping".equals(operation)) {
            return applyMapping(args);
        } else if ("createTableAndImport".equals(operation)) {
            return createTableAndImport(args);
        } else if ("csvAutoMapping".equals(operation)) {
            return csvAutoMapping(args);
        } else if ("excelSheetAutoMapping".equals(operation)) {
            return excelSheetAutoMapping(args);
        } else if ("getConnection".equals(operation)) {
            return getConnection(args);
        } else if ("getExcelSheetNames".equals(operation)) {
            return getExcelSheetNames(args);
        } else if ("normalize".equals(operation)) {
            return normalize(args);
        } else if ("parseCsv".equals(operation)) {
            return parseCsv(args);
        } else if ("splitCsvLine".equals(operation)) {
            return splitCsvLine(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

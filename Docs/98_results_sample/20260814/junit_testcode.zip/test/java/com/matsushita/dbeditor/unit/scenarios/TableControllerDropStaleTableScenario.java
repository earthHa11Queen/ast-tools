package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableController#dropStaleTable.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableControllerDropStaleTableScenario {

    @Test
    @DisplayName("UTAPI-001368")
    void case_UTAPI_001368() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001368",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001368", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001368", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001368", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001368")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001369")
    void case_UTAPI_001369() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001369",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001369", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001369", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001369", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001369")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001370")
    void case_UTAPI_001370() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001370",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001370", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001370", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001370", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001370")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001371")
    void case_UTAPI_001371() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001371",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001371", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001371", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001371", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001371")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001372")
    void case_UTAPI_001372() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001372",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001372", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001372", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001372", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001372")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001373")
    void case_UTAPI_001373() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001373",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001373", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001373", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001373", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001373")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001374")
    void case_UTAPI_001374() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001374",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001374", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001374", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001374", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001374")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001375")
    void case_UTAPI_001375() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001375",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001375", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001375", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001375", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001375")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001376")
    void case_UTAPI_001376() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001376",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001376", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001376", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001376", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001376")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001377")
    void case_UTAPI_001377() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001377",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001377", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001377", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001377", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001377")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001378")
    void case_UTAPI_001378() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001378",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001378", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001378", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001378", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001378")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001379")
    void case_UTAPI_001379() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001379",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001379", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001379", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001379", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001379")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::2::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001380")
    void case_UTAPI_001380() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001380",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001380", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001380", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001380", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001380")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::2::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001381")
    void case_UTAPI_001381() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001381",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001381", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001381", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001381", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001381")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::2::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001382")
    void case_UTAPI_001382() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001382",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001382", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001382", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001382", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001382")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::2::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001383")
    void case_UTAPI_001383() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001383",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001383", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001383", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001383", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001383")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::2::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001384")
    void case_UTAPI_001384() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001384",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001384", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001384", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001384", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001384")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::2::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001385")
    void case_UTAPI_001385() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001385",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001385", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001385", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001385", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001385")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::2::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001386")
    void case_UTAPI_001386() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001386",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001386", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001386", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001386", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001386")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::2::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001387")
    void case_UTAPI_001387() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001387",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001387", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001387", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001387", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001387")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::2::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001388")
    void case_UTAPI_001388() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001388",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001388", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001388", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001388", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001388")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::2::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001389")
    void case_UTAPI_001389() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001389",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001389", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001389", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001389", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001389")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::2::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001390")
    void case_UTAPI_001390() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001390",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001390", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001390", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001390", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001390")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::2::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001391")
    void case_UTAPI_001391() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001391",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001391", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001391", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001391", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001391")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::2::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001392")
    void case_UTAPI_001392() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001392",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001392", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001392", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001392", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001392")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::2::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001393")
    void case_UTAPI_001393() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001393",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001393", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001393", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001393", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001393")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::2::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001394")
    void case_UTAPI_001394() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001394",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001394", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001394", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001394", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001394")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::2::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001395")
    void case_UTAPI_001395() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001395",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001395", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001395", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001395", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001395")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::2::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001396")
    void case_UTAPI_001396() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001396",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001396", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001396", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001396", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001396")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::2::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001397")
    void case_UTAPI_001397() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001397",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001397", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001397", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001397", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001397")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::2::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001398")
    void case_UTAPI_001398() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001398",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001398", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001398", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001398", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001398")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::2::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001399")
    void case_UTAPI_001399() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001399",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001399", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001399", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001399", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001399")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::2::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001400")
    void case_UTAPI_001400() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001400",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001400", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001400", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001400", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001400")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::3::-::schema")
                    .mirror("-", "1:length_null", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001401")
    void case_UTAPI_001401() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001401",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001401", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001401", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001401", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001401")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::3::-::schema")
                    .mirror("-", "2:length_empty", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001402")
    void case_UTAPI_001402() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001402",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001402", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001402", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001402", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001402")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::3::-::schema")
                    .mirror("-", "3:length_min", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001403")
    void case_UTAPI_001403() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001403",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001403", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001403", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001403", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001403")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::3::-::schema")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001404")
    void case_UTAPI_001404() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001404",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001404", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001404", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001404", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001404")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::3::-::schema")
                    .mirror("-", "5:length_max", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001405")
    void case_UTAPI_001405() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001405",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001405", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001405", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001405", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001405")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::3::-::schema")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001406")
    void case_UTAPI_001406() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001406",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001406", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001406", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001406", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001406")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::3::-::schema")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001407")
    void case_UTAPI_001407() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001407",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001407", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001407", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001407", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001407")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::3::-::schema")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001408")
    void case_UTAPI_001408() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001408",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001408", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001408", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001408", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001408")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::3::-::schema")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001409")
    void case_UTAPI_001409() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001409",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001409", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001409", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001409", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001409")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::3::-::schema")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001410")
    void case_UTAPI_001410() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001410",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001410", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001410", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001410", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001410")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::3::-::schema")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001411")
    void case_UTAPI_001411() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001411",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001411", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001411", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001411", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001411")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::3::-::schema")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001412")
    void case_UTAPI_001412() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001412",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001412", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001412", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001412", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001412")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::3::-::schema")
                    .mirror("-", "-", "56:space")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001413")
    void case_UTAPI_001413() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001413",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001413", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001413", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001413", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001413")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::3::-::schema")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001414")
    void case_UTAPI_001414() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001414",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001414", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001414", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001414", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001414")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::3::-::schema")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001415")
    void case_UTAPI_001415() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001415",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001415", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001415", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001415", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001415")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::3::-::schema")
                    .mirror("-", "-", "59:tab")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001416")
    void case_UTAPI_001416() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001416",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001416", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001416", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001416", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001416")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::3::-::schema")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001417")
    void case_UTAPI_001417() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001417",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001417", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001417", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001417", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001417")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::3::-::schema")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001418")
    void case_UTAPI_001418() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001418",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001418", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001418", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001418", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001418")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::3::-::schema")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001419")
    void case_UTAPI_001419() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001419",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "dropStaleTable",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001419", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001419", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001419", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001419")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::dropStaleTable::2::ARG::3::-::schema")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.dropStaleTable")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.dropStaleTable", "tableRecordUseCase", "dropStaleTable")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.dropStaleTable must carry the value generated for connectionId", "tableRecordUseCase", "dropStaleTable", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.dropStaleTable must carry the value generated for schema", "tableRecordUseCase", "dropStaleTable", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.dropStaleTable must carry the value generated for tableName", "tableRecordUseCase", "dropStaleTable", "2", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

}

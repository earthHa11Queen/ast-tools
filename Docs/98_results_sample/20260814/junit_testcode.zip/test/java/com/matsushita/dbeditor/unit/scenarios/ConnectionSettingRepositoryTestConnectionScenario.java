package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ConnectionSettingRepositoryWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ConnectionSettingRepository#testConnection.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ConnectionSettingRepositoryTestConnectionScenario {

    @Test
    @DisplayName("UTAPI-006187")
    void case_UTAPI_006187() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006187",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006187", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006187", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006187", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006187", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006187", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006187")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::1::-::host")
                    .mirror("-", "1:length_null", "-")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006188")
    void case_UTAPI_006188() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006188",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006188", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006188", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006188", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006188", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006188", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006188")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::1::-::host")
                    .mirror("-", "2:length_empty", "-")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006189")
    void case_UTAPI_006189() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006189",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006189", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006189", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006189", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006189", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006189", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006189")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::1::-::host")
                    .mirror("-", "3:length_min", "-")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006190")
    void case_UTAPI_006190() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006190",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006190", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006190", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006190", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006190", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006190", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006190")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::1::-::host")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006191")
    void case_UTAPI_006191() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006191",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006191", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006191", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006191", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006191", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006191", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006191")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::1::-::host")
                    .mirror("-", "5:length_max", "-")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006192")
    void case_UTAPI_006192() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006192",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006192", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006192", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006192", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006192", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006192", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006192")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::1::-::host")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006193")
    void case_UTAPI_006193() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006193",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006193", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006193", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006193", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006193", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006193", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006193")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::1::-::host")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006194")
    void case_UTAPI_006194() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006194",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006194", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006194", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006194", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006194", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006194", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006194")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::1::-::host")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006195")
    void case_UTAPI_006195() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006195",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006195", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006195", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006195", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006195", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006195", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006195")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::1::-::host")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006196")
    void case_UTAPI_006196() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006196",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006196", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006196", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006196", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006196", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006196", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006196")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::1::-::host")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006197")
    void case_UTAPI_006197() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006197",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006197", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006197", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006197", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006197", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006197", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006197")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::1::-::host")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006198")
    void case_UTAPI_006198() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006198",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006198", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006198", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006198", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006198", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006198", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006198")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::1::-::host")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006199")
    void case_UTAPI_006199() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006199",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006199", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006199", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006199", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006199", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006199", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006199")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::1::-::host")
                    .mirror("-", "-", "56:space")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006200")
    void case_UTAPI_006200() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006200",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006200", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006200", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006200", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006200", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006200", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006200")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::1::-::host")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006201")
    void case_UTAPI_006201() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006201",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006201", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006201", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006201", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006201", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006201", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006201")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::1::-::host")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006202")
    void case_UTAPI_006202() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006202",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006202", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006202", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006202", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006202", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006202", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006202")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::1::-::host")
                    .mirror("-", "-", "59:tab")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006203")
    void case_UTAPI_006203() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006203",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006203", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006203", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006203", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006203", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006203", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006203")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::1::-::host")
                    .mirror("-", "-", "60:control_character_null")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006204")
    void case_UTAPI_006204() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006204",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006204", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006204", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006204", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006204", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006204", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006204")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::1::-::host")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006205")
    void case_UTAPI_006205() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006205",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006205", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006205", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006205", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006205", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006205", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006205")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::1::-::host")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006206")
    void case_UTAPI_006206() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006206",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006206", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006206", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006206", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006206", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006206", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006206")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::1::-::host")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006207")
    void case_UTAPI_006207() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006207",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006207", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006207", "port", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006207", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006207", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006207", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006207")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::2::-::port")
                    .mirror("-", "1:length_null", "-")
                    .target("port", "port")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006208")
    void case_UTAPI_006208() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006208",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006208", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006208", "port", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006208", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006208", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006208", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006208")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::2::-::port")
                    .mirror("-", "2:length_empty", "-")
                    .target("port", "port")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006209")
    void case_UTAPI_006209() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006209",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006209", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006209", "port", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006209", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006209", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006209", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006209")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::2::-::port")
                    .mirror("-", "3:length_min", "-")
                    .target("port", "port")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006210")
    void case_UTAPI_006210() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006210",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006210", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006210", "port", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006210", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006210", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006210", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006210")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::2::-::port")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("port", "port")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006211")
    void case_UTAPI_006211() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006211",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006211", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006211", "port", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006211", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006211", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006211", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006211")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::2::-::port")
                    .mirror("-", "5:length_max", "-")
                    .target("port", "port")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006212")
    void case_UTAPI_006212() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006212",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006212", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006212", "port", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006212", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006212", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006212", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006212")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::2::-::port")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("port", "port")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006213")
    void case_UTAPI_006213() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006213",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006213", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006213", "port", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006213", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006213", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006213", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006213")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::2::-::port")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("port", "port")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006214")
    void case_UTAPI_006214() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006214",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006214", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006214", "port", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006214", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006214", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006214", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006214")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::2::-::port")
                    .mirror("46:hw_integer", "-", "-")
                    .target("port", "port")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006215")
    void case_UTAPI_006215() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006215",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006215", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006215", "port", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006215", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006215", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006215", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006215")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::2::-::port")
                    .mirror("-", "-", "12:integer_positive")
                    .target("port", "port")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006216")
    void case_UTAPI_006216() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006216",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006216", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006216", "port", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006216", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006216", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006216", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006216")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::2::-::port")
                    .mirror("-", "-", "13:integer_negative")
                    .target("port", "port")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006217")
    void case_UTAPI_006217() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006217",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006217", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006217", "port", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006217", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006217", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006217", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006217")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::2::-::port")
                    .mirror("-", "-", "14:integer_zero")
                    .target("port", "port")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006218")
    void case_UTAPI_006218() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006218",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006218", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006218", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006218", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006218", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006218", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006218")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::3::-::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006219")
    void case_UTAPI_006219() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006219",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006219", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006219", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006219", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006219", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006219", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006219")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::3::-::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006220")
    void case_UTAPI_006220() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006220",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006220", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006220", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006220", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006220", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006220", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006220")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::3::-::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006221")
    void case_UTAPI_006221() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006221",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006221", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006221", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006221", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006221", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006221", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006221")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::3::-::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006222")
    void case_UTAPI_006222() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006222",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006222", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006222", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006222", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006222", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006222", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006222")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::3::-::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006223")
    void case_UTAPI_006223() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006223",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006223", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006223", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006223", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006223", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006223", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006223")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::3::-::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006224")
    void case_UTAPI_006224() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006224",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006224", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006224", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006224", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006224", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006224", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006224")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::3::-::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006225")
    void case_UTAPI_006225() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006225",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006225", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006225", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006225", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006225", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006225", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006225")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::3::-::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006226")
    void case_UTAPI_006226() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006226",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006226", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006226", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006226", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006226", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006226", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006226")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::3::-::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006227")
    void case_UTAPI_006227() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006227",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006227", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006227", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006227", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006227", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006227", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006227")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::3::-::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006228")
    void case_UTAPI_006228() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006228",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006228", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006228", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006228", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006228", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006228", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006228")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::3::-::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006229")
    void case_UTAPI_006229() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006229",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006229", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006229", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006229", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006229", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006229", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006229")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::3::-::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006230")
    void case_UTAPI_006230() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006230",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006230", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006230", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006230", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006230", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006230", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006230")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::3::-::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006231")
    void case_UTAPI_006231() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006231",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006231", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006231", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006231", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006231", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006231", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006231")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::3::-::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006232")
    void case_UTAPI_006232() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006232",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006232", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006232", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006232", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006232", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006232", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006232")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::3::-::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006233")
    void case_UTAPI_006233() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006233",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006233", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006233", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006233", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006233", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006233", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006233")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::3::-::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006234")
    void case_UTAPI_006234() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006234",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006234", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006234", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006234", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006234", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006234", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006234")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::3::-::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006235")
    void case_UTAPI_006235() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006235",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006235", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006235", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006235", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006235", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006235", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006235")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::3::-::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006236")
    void case_UTAPI_006236() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006236",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006236", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006236", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006236", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006236", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006236", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006236")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::3::-::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006237")
    void case_UTAPI_006237() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006237",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006237", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006237", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006237", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006237", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006237", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006237")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::3::-::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006238")
    void case_UTAPI_006238() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006238",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006238", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006238", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006238", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006238", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006238", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006238")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::3::-::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006239")
    void case_UTAPI_006239() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006239",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006239", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006239", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006239", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006239", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006239", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006239")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::4::-::username")
                    .mirror("-", "1:length_null", "-")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006240")
    void case_UTAPI_006240() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006240",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006240", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006240", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006240", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006240", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006240", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006240")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::4::-::username")
                    .mirror("-", "2:length_empty", "-")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006241")
    void case_UTAPI_006241() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006241",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006241", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006241", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006241", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006241", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006241", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006241")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::4::-::username")
                    .mirror("-", "3:length_min", "-")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006242")
    void case_UTAPI_006242() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006242",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006242", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006242", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006242", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006242", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006242", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006242")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::4::-::username")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006243")
    void case_UTAPI_006243() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006243",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006243", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006243", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006243", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006243", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006243", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006243")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::4::-::username")
                    .mirror("-", "5:length_max", "-")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006244")
    void case_UTAPI_006244() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006244",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006244", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006244", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006244", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006244", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006244", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006244")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::4::-::username")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006245")
    void case_UTAPI_006245() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006245",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006245", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006245", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006245", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006245", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006245", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006245")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::4::-::username")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006246")
    void case_UTAPI_006246() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006246",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006246", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006246", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006246", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006246", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006246", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006246")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::4::-::username")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006247")
    void case_UTAPI_006247() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006247",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006247", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006247", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006247", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006247", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006247", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006247")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::4::-::username")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006248")
    void case_UTAPI_006248() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006248",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006248", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006248", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006248", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006248", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006248", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006248")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::4::-::username")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006249")
    void case_UTAPI_006249() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006249",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006249", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006249", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006249", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006249", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006249", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006249")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::4::-::username")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006250")
    void case_UTAPI_006250() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006250",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006250", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006250", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006250", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006250", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006250", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006250")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::4::-::username")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006251")
    void case_UTAPI_006251() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006251",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006251", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006251", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006251", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006251", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006251", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006251")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::4::-::username")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006252")
    void case_UTAPI_006252() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006252",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006252", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006252", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006252", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006252", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006252", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006252")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::4::-::username")
                    .mirror("-", "-", "56:space")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006253")
    void case_UTAPI_006253() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006253",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006253", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006253", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006253", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006253", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006253", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006253")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::4::-::username")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006254")
    void case_UTAPI_006254() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006254",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006254", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006254", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006254", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006254", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006254", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006254")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::4::-::username")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006255")
    void case_UTAPI_006255() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006255",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006255", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006255", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006255", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006255", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006255", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006255")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::4::-::username")
                    .mirror("-", "-", "59:tab")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006256")
    void case_UTAPI_006256() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006256",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006256", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006256", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006256", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006256", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006256", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006256")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::4::-::username")
                    .mirror("-", "-", "60:control_character_null")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006257")
    void case_UTAPI_006257() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006257",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006257", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006257", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006257", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006257", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006257", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006257")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::4::-::username")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006258")
    void case_UTAPI_006258() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006258",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006258", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006258", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006258", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006258", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006258", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006258")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::4::-::username")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006259")
    void case_UTAPI_006259() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006259",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006259", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006259", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006259", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006259", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006259", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006259")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::4::-::username")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006260")
    void case_UTAPI_006260() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006260",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006260", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006260", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006260", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006260", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006260", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006260")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::5::-::password")
                    .mirror("-", "1:length_null", "-")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006261")
    void case_UTAPI_006261() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006261",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006261", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006261", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006261", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006261", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006261", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006261")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::5::-::password")
                    .mirror("-", "2:length_empty", "-")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006262")
    void case_UTAPI_006262() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006262",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006262", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006262", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006262", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006262", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006262", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006262")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::5::-::password")
                    .mirror("-", "3:length_min", "-")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006263")
    void case_UTAPI_006263() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006263",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006263", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006263", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006263", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006263", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006263", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006263")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::5::-::password")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006264")
    void case_UTAPI_006264() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006264",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006264", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006264", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006264", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006264", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006264", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006264")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::5::-::password")
                    .mirror("-", "5:length_max", "-")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006265")
    void case_UTAPI_006265() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006265",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006265", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006265", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006265", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006265", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006265", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006265")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::5::-::password")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006266")
    void case_UTAPI_006266() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006266",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006266", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006266", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006266", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006266", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006266", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006266")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::5::-::password")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006267")
    void case_UTAPI_006267() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006267",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006267", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006267", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006267", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006267", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006267", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006267")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::5::-::password")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006268")
    void case_UTAPI_006268() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006268",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006268", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006268", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006268", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006268", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006268", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006268")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::5::-::password")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006269")
    void case_UTAPI_006269() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006269",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006269", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006269", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006269", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006269", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006269", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006269")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::5::-::password")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006270")
    void case_UTAPI_006270() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006270",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006270", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006270", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006270", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006270", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006270", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006270")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::5::-::password")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006271")
    void case_UTAPI_006271() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006271",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006271", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006271", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006271", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006271", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006271", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006271")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::5::-::password")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006272")
    void case_UTAPI_006272() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006272",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006272", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006272", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006272", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006272", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006272", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006272")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::5::-::password")
                    .mirror("-", "-", "56:space")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006273")
    void case_UTAPI_006273() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006273",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006273", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006273", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006273", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006273", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006273", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006273")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::5::-::password")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006274")
    void case_UTAPI_006274() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006274",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006274", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006274", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006274", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006274", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006274", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006274")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::5::-::password")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006275")
    void case_UTAPI_006275() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006275",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006275", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006275", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006275", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006275", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006275", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006275")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::5::-::password")
                    .mirror("-", "-", "59:tab")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006276")
    void case_UTAPI_006276() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006276",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006276", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006276", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006276", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006276", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006276", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006276")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::5::-::password")
                    .mirror("-", "-", "60:control_character_null")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006277")
    void case_UTAPI_006277() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006277",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006277", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006277", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006277", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006277", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006277", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006277")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::5::-::password")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006278")
    void case_UTAPI_006278() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006278",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006278", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006278", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006278", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006278", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006278", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006278")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::5::-::password")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006279")
    void case_UTAPI_006279() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006279",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006279", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006279", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006279", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006279", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006279", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006279")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::testConnection::6::ARG::5::-::password")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

}

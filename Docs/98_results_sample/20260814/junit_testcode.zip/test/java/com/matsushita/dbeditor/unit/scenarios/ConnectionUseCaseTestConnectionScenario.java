package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ConnectionUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ConnectionUseCase#testConnection.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ConnectionUseCaseTestConnectionScenario {

    @Test
    @DisplayName("UTAPI-011850")
    void case_UTAPI_011850() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011850",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011850", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011850", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011850", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011850", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011850", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011850", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011850", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011850", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011850")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("request.connectionId", "ConnectionTestRequest.connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the parameters handed to the delegated connection test")
                    .expected("because the request carries no connectionId, the connection parameters of the request itself are used for the test")
                    .failure("a stored connection is looked up although none was identified, or a request parameter is dropped or handed to the wrong position")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.NOT_INVOKED, "without a connectionId no stored connection may be looked up", "connectionSettingRepository", "findById", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.ARG_EQUALS, "the host of the request must be used", "connectionSettingRepository", "testConnection", "0", "data:request.dbHost")
                    .check(CheckType.ARG_EQUALS, "the port of the request must be used", "connectionSettingRepository", "testConnection", "1", "data:request.dbPort")
                    .check(CheckType.ARG_EQUALS, "the database name of the request must be used", "connectionSettingRepository", "testConnection", "2", "data:request.databaseName")
                    .check(CheckType.ARG_EQUALS, "the user of the request must be used", "connectionSettingRepository", "testConnection", "3", "data:request.dbUsername")
                    .check(CheckType.ARG_EQUALS, "the password of the request must be used", "connectionSettingRepository", "testConnection", "4", "data:request.dbPassword")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011851")
    void case_UTAPI_011851() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011851",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011851", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011851", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011851", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011851", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011851", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011851", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011851", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011851", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011851")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.connectionId", "ConnectionTestRequest.connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011852")
    void case_UTAPI_011852() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011852",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011852", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011852", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011852", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011852", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011852", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011852", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011852", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011852", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011852")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("request.connectionId", "ConnectionTestRequest.connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011853")
    void case_UTAPI_011853() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011853",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011853", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011853", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011853", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011853", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011853", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011853", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011853", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011853", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011853")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.connectionId", "ConnectionTestRequest.connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011854")
    void case_UTAPI_011854() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011854",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011854", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011854", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011854", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011854", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011854", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011854", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011854", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011854", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011854")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("request.connectionId", "ConnectionTestRequest.connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011855")
    void case_UTAPI_011855() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011855",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011855", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011855", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011855", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011855", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011855", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011855", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011855", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011855", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011855")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.connectionId", "ConnectionTestRequest.connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011856")
    void case_UTAPI_011856() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011856",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011856", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011856", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011856", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011856", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011856", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011856", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011856", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011856", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011856")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.connectionId", "ConnectionTestRequest.connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011857")
    void case_UTAPI_011857() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011857",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011857", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011857", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011857", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011857", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011857", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011857", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011857", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011857", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011857")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("request.connectionId", "ConnectionTestRequest.connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011858")
    void case_UTAPI_011858() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011858",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011858", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011858", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011858", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011858", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011858", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011858", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011858", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011858", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011858")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("request.connectionId", "ConnectionTestRequest.connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011859")
    void case_UTAPI_011859() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011859",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011859", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011859", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011859", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011859", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011859", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011859", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011859", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011859", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011859")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("request.connectionId", "ConnectionTestRequest.connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011860")
    void case_UTAPI_011860() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011860",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011860", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011860", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011860", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011860", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011860", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011860", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011860", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011860", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011860")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("request.connectionId", "ConnectionTestRequest.connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011861")
    void case_UTAPI_011861() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011861",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011861", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011861", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011861", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011861", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011861", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011861", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011861", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011861", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011861")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.databaseName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011862")
    void case_UTAPI_011862() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011862",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011862", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011862", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011862", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011862", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011862", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011862", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011862", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011862", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011862")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.databaseName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011863")
    void case_UTAPI_011863() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011863",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011863", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011863", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011863", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011863", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011863", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011863", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011863", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011863", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011863")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.databaseName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011864")
    void case_UTAPI_011864() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011864",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011864", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011864", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011864", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011864", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011864", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011864", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011864", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011864", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011864")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.databaseName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011865")
    void case_UTAPI_011865() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011865",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011865", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011865", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011865", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011865", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011865", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011865", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011865", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011865", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011865")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.databaseName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011866")
    void case_UTAPI_011866() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011866",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011866", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011866", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011866", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011866", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011866", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011866", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011866", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011866", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011866")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.databaseName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011867")
    void case_UTAPI_011867() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011867",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011867", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011867", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011867", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011867", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011867", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011867", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011867", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011867", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011867")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.databaseName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011868")
    void case_UTAPI_011868() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011868",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011868", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011868", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011868", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011868", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011868", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011868", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011868", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011868", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011868")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.databaseName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011869")
    void case_UTAPI_011869() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011869",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011869", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011869", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011869", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011869", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011869", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011869", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011869", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011869", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011869")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.databaseName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011870")
    void case_UTAPI_011870() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011870",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011870", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011870", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011870", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011870", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011870", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011870", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011870", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011870", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011870")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.databaseName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011871")
    void case_UTAPI_011871() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011871",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011871", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011871", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011871", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011871", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011871", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011871", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011871", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011871", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011871")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.databaseName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011872")
    void case_UTAPI_011872() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011872",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011872", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011872", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011872", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011872", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011872", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011872", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011872", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011872", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011872")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.databaseName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011873")
    void case_UTAPI_011873() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011873",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011873", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011873", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011873", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011873", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011873", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011873", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011873", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011873", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011873")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.databaseName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011874")
    void case_UTAPI_011874() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011874",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011874", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011874", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011874", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011874", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011874", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011874", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011874", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011874", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011874")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.databaseName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011875")
    void case_UTAPI_011875() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011875",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011875", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011875", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011875", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011875", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011875", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011875", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011875", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011875", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011875")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.databaseName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011876")
    void case_UTAPI_011876() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011876",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011876", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011876", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011876", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011876", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011876", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011876", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011876", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011876", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011876")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.databaseName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011877")
    void case_UTAPI_011877() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011877",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011877", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011877", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011877", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011877", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011877", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011877", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011877", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011877", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011877")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.databaseName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011878")
    void case_UTAPI_011878() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011878",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011878", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011878", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011878", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011878", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011878", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011878", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011878", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011878", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011878")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.databaseName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011879")
    void case_UTAPI_011879() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011879",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011879", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011879", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011879", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011879", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011879", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011879", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011879", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011879", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011879")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.databaseName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011880")
    void case_UTAPI_011880() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011880",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011880", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011880", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011880", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011880", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011880", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011880", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011880", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011880", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011880")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.databaseName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011881")
    void case_UTAPI_011881() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011881",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011881", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011881", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011881", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011881", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011881", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011881", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011881", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011881", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011881")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.databaseName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.databaseName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011882")
    void case_UTAPI_011882() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011882",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011882", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011882", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011882", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011882", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011882", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011882", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011882", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011882", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011882")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbHost")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011883")
    void case_UTAPI_011883() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011883",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011883", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011883", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011883", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011883", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011883", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011883", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011883", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011883", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011883")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbHost")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011884")
    void case_UTAPI_011884() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011884",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011884", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011884", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011884", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011884", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011884", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011884", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011884", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011884", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011884")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbHost")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011885")
    void case_UTAPI_011885() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011885",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011885", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011885", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011885", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011885", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011885", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011885", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011885", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011885", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011885")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbHost")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011886")
    void case_UTAPI_011886() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011886",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011886", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011886", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011886", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011886", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011886", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011886", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011886", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011886", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011886")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbHost")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011887")
    void case_UTAPI_011887() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011887",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011887", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011887", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011887", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011887", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011887", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011887", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011887", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011887", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011887")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbHost")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011888")
    void case_UTAPI_011888() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011888",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011888", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011888", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011888", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011888", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011888", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011888", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011888", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011888", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011888")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbHost")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011889")
    void case_UTAPI_011889() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011889",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011889", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011889", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011889", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011889", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011889", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011889", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011889", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011889", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011889")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbHost")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011890")
    void case_UTAPI_011890() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011890",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011890", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011890", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011890", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011890", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011890", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011890", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011890", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011890", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011890")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbHost")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011891")
    void case_UTAPI_011891() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011891",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011891", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011891", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011891", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011891", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011891", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011891", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011891", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011891", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011891")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbHost")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011892")
    void case_UTAPI_011892() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011892",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011892", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011892", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011892", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011892", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011892", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011892", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011892", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011892", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011892")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbHost")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011893")
    void case_UTAPI_011893() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011893",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011893", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011893", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011893", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011893", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011893", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011893", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011893", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011893", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011893")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbHost")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011894")
    void case_UTAPI_011894() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011894",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011894", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011894", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011894", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011894", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011894", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011894", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011894", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011894", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011894")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbHost")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011895")
    void case_UTAPI_011895() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011895",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011895", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011895", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011895", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011895", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011895", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011895", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011895", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011895", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011895")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbHost")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011896")
    void case_UTAPI_011896() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011896",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011896", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011896", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011896", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011896", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011896", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011896", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011896", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011896", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011896")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbHost")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011897")
    void case_UTAPI_011897() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011897",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011897", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011897", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011897", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011897", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011897", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011897", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011897", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011897", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011897")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbHost")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011898")
    void case_UTAPI_011898() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011898",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011898", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011898", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011898", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011898", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011898", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011898", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011898", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011898", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011898")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbHost")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011899")
    void case_UTAPI_011899() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011899",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011899", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011899", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011899", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011899", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011899", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011899", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011899", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011899", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011899")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbHost")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011900")
    void case_UTAPI_011900() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011900",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011900", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011900", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011900", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011900", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011900", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011900", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011900", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011900", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011900")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbHost")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011901")
    void case_UTAPI_011901() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011901",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011901", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011901", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011901", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011901", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011901", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011901", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011901", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011901", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011901")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbHost")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbHost")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011902")
    void case_UTAPI_011902() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011902",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011902", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011902", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011902", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011902", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011902", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011902", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011902", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011902", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011902")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011903")
    void case_UTAPI_011903() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011903",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011903", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011903", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011903", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011903", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011903", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011903", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011903", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011903", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011903")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011904")
    void case_UTAPI_011904() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011904",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011904", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011904", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011904", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011904", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011904", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011904", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011904", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011904", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011904")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011905")
    void case_UTAPI_011905() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011905",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011905", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011905", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011905", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011905", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011905", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011905", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011905", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011905", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011905")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011906")
    void case_UTAPI_011906() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011906",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011906", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011906", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011906", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011906", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011906", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011906", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011906", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011906", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011906")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011907")
    void case_UTAPI_011907() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011907",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011907", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011907", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011907", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011907", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011907", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011907", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011907", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011907", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011907")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011908")
    void case_UTAPI_011908() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011908",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011908", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011908", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011908", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011908", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011908", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011908", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011908", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011908", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011908")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011909")
    void case_UTAPI_011909() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011909",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011909", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011909", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011909", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011909", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011909", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011909", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011909", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011909", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011909")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011910")
    void case_UTAPI_011910() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011910",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011910", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011910", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011910", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011910", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011910", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011910", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011910", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011910", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011910")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011911")
    void case_UTAPI_011911() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011911",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011911", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011911", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011911", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011911", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011911", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011911", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011911", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011911", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011911")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011912")
    void case_UTAPI_011912() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011912",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011912", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011912", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011912", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011912", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011912", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011912", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011912", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011912", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011912")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011913")
    void case_UTAPI_011913() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011913",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011913", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011913", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011913", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011913", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011913", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011913", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011913", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011913", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011913")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011914")
    void case_UTAPI_011914() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011914",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011914", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011914", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011914", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011914", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011914", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011914", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011914", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011914", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011914")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011915")
    void case_UTAPI_011915() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011915",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011915", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011915", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011915", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011915", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011915", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011915", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011915", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011915", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011915")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("-", "-", "56:space")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011916")
    void case_UTAPI_011916() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011916",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011916", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011916", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011916", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011916", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011916", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011916", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011916", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011916", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011916")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011917")
    void case_UTAPI_011917() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011917",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011917", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011917", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011917", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011917", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011917", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011917", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011917", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011917", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011917")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011918")
    void case_UTAPI_011918() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011918",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011918", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011918", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011918", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011918", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011918", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011918", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011918", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011918", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011918")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011919")
    void case_UTAPI_011919() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011919",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011919", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011919", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011919", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011919", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011919", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011919", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011919", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011919", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011919")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011920")
    void case_UTAPI_011920() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011920",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011920", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011920", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011920", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011920", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011920", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011920", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011920", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011920", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011920")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011921")
    void case_UTAPI_011921() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011921",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011921", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011921", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011921", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011921", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011921", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011921", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011921", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011921", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011921")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011922")
    void case_UTAPI_011922() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011922",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011922", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011922", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011922", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011922", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011922", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011922", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011922", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011922", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011922")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbName")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011923")
    void case_UTAPI_011923() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011923",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011923", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011923", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011923", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011923", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011923", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011923", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011923", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011923", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011923")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbPassword")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011924")
    void case_UTAPI_011924() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011924",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011924", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011924", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011924", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011924", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011924", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011924", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011924", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011924", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011924")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbPassword")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011925")
    void case_UTAPI_011925() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011925",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011925", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011925", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011925", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011925", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011925", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011925", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011925", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011925", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011925")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbPassword")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011926")
    void case_UTAPI_011926() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011926",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011926", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011926", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011926", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011926", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011926", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011926", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011926", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011926", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011926")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbPassword")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011927")
    void case_UTAPI_011927() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011927",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011927", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011927", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011927", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011927", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011927", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011927", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011927", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011927", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011927")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbPassword")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011928")
    void case_UTAPI_011928() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011928",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011928", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011928", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011928", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011928", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011928", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011928", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011928", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011928", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011928")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbPassword")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011929")
    void case_UTAPI_011929() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011929",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011929", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011929", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011929", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011929", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011929", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011929", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011929", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011929", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011929")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbPassword")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011930")
    void case_UTAPI_011930() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011930",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011930", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011930", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011930", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011930", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011930", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011930", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011930", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011930", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011930")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbPassword")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011931")
    void case_UTAPI_011931() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011931",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011931", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011931", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011931", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011931", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011931", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011931", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011931", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011931", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011931")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbPassword")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011932")
    void case_UTAPI_011932() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011932",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011932", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011932", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011932", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011932", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011932", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011932", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011932", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011932", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011932")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbPassword")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011933")
    void case_UTAPI_011933() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011933",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011933", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011933", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011933", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011933", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011933", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011933", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011933", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011933", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011933")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbPassword")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011934")
    void case_UTAPI_011934() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011934",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011934", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011934", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011934", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011934", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011934", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011934", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011934", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011934", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011934")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbPassword")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011935")
    void case_UTAPI_011935() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011935",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011935", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011935", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011935", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011935", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011935", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011935", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011935", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011935", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011935")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbPassword")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011936")
    void case_UTAPI_011936() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011936",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011936", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011936", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011936", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011936", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011936", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011936", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011936", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011936", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011936")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbPassword")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011937")
    void case_UTAPI_011937() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011937",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011937", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011937", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011937", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011937", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011937", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011937", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011937", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011937", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011937")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbPassword")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011938")
    void case_UTAPI_011938() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011938",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011938", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011938", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011938", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011938", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011938", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011938", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011938", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011938", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011938")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbPassword")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011939")
    void case_UTAPI_011939() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011939",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011939", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011939", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011939", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011939", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011939", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011939", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011939", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011939", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011939")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbPassword")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011940")
    void case_UTAPI_011940() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011940",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011940", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011940", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011940", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011940", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011940", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011940", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011940", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011940", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011940")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbPassword")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011941")
    void case_UTAPI_011941() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011941",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011941", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011941", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011941", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011941", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011941", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011941", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011941", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011941", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011941")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbPassword")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011942")
    void case_UTAPI_011942() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011942",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011942", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011942", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011942", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011942", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011942", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011942", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011942", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011942", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011942")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbPassword")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbPassword")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011943")
    void case_UTAPI_011943() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011943",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011943", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011943", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011943", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011943", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011943", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011943", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011943", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011943", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011943")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("request.dbPort", "ConnectionTestRequest.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbPort")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011944")
    void case_UTAPI_011944() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011944",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011944", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011944", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011944", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011944", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011944", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011944", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011944", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011944", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011944")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.dbPort", "ConnectionTestRequest.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbPort")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011945")
    void case_UTAPI_011945() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011945",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011945", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011945", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011945", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011945", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011945", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011945", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011945", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011945", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011945")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("request.dbPort", "ConnectionTestRequest.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbPort")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011946")
    void case_UTAPI_011946() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011946",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011946", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011946", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011946", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011946", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011946", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011946", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011946", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011946", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011946")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.dbPort", "ConnectionTestRequest.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbPort")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011947")
    void case_UTAPI_011947() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011947",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011947", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011947", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011947", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011947", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011947", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011947", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011947", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011947", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011947")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("request.dbPort", "ConnectionTestRequest.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbPort")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011948")
    void case_UTAPI_011948() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011948",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011948", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011948", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011948", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011948", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011948", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011948", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011948", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011948", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011948")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.dbPort", "ConnectionTestRequest.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbPort")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011949")
    void case_UTAPI_011949() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011949",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011949", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011949", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011949", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011949", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011949", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011949", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011949", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011949", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011949")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.dbPort", "ConnectionTestRequest.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbPort")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011950")
    void case_UTAPI_011950() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011950",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011950", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011950", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011950", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011950", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011950", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011950", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011950", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011950", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011950")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("request.dbPort", "ConnectionTestRequest.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbPort")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011951")
    void case_UTAPI_011951() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011951",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011951", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011951", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011951", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011951", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011951", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011951", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011951", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011951", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011951")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("request.dbPort", "ConnectionTestRequest.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbPort")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011952")
    void case_UTAPI_011952() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011952",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011952", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011952", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011952", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011952", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011952", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011952", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011952", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011952", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011952")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("request.dbPort", "ConnectionTestRequest.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbPort")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011953")
    void case_UTAPI_011953() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011953",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011953", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011953", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011953", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011953", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011953", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011953", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011953", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011953", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011953")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("request.dbPort", "ConnectionTestRequest.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbPort")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbPort")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011954")
    void case_UTAPI_011954() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011954",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011954", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011954", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011954", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011954", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011954", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011954", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011954", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011954", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011954")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbUsername")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011955")
    void case_UTAPI_011955() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011955",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011955", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011955", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011955", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011955", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011955", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011955", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011955", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011955", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011955")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbUsername")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011956")
    void case_UTAPI_011956() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011956",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011956", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011956", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011956", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011956", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011956", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011956", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011956", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011956", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011956")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbUsername")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011957")
    void case_UTAPI_011957() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011957",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011957", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011957", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011957", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011957", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011957", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011957", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011957", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011957", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011957")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbUsername")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011958")
    void case_UTAPI_011958() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011958",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011958", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011958", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011958", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011958", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011958", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011958", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011958", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011958", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011958")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbUsername")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011959")
    void case_UTAPI_011959() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011959",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011959", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011959", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011959", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011959", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011959", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011959", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011959", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011959", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011959")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbUsername")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011960")
    void case_UTAPI_011960() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011960",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011960", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011960", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011960", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011960", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011960", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011960", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011960", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011960", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011960")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbUsername")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011961")
    void case_UTAPI_011961() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011961",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011961", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011961", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011961", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011961", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011961", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011961", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011961", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011961", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011961")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbUsername")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011962")
    void case_UTAPI_011962() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011962",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011962", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011962", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011962", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011962", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011962", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011962", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011962", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011962", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011962")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbUsername")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011963")
    void case_UTAPI_011963() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011963",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011963", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011963", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011963", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011963", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011963", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011963", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011963", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011963", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011963")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbUsername")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011964")
    void case_UTAPI_011964() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011964",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011964", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011964", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011964", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011964", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011964", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011964", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011964", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011964", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011964")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbUsername")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011965")
    void case_UTAPI_011965() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011965",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011965", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011965", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011965", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011965", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011965", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011965", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011965", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011965", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011965")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbUsername")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011966")
    void case_UTAPI_011966() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011966",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011966", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011966", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011966", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011966", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011966", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011966", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011966", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011966", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011966")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbUsername")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011967")
    void case_UTAPI_011967() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011967",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011967", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011967", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011967", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011967", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011967", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011967", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011967", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011967", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011967")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbUsername")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011968")
    void case_UTAPI_011968() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011968",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011968", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011968", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011968", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011968", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011968", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011968", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011968", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011968", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011968")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbUsername")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011969")
    void case_UTAPI_011969() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011969",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011969", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011969", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011969", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011969", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011969", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011969", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011969", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011969", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011969")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbUsername")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011970")
    void case_UTAPI_011970() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011970",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011970", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011970", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011970", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011970", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011970", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011970", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011970", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011970", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011970")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbUsername")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011971")
    void case_UTAPI_011971() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011971",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011971", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011971", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011971", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011971", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011971", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011971", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011971", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011971", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011971")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbUsername")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011972")
    void case_UTAPI_011972() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011972",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011972", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011972", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011972", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011972", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011972", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011972", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011972", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011972", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011972")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbUsername")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011973")
    void case_UTAPI_011973() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011973",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011973", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011973", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011973", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011973", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011973", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011973", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011973", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011973", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011973")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbUsername")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011974")
    void case_UTAPI_011974() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011974",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011974", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-011974", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011974", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011974", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011974", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011974", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011974", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011974", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011974")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the lookup of the stored connection and the delegated connection test")
                    .expected("because the request carries a connectionId, the stored connection is looked up with exactly that identifier and the test outcome of the repository is reported unchanged")
                    .failure("the identifier is altered, the stored connection is ignored, or an outcome is reported without asking the repository")
                    .assertion("verify the repository interactions with captured arguments and assert the reported outcome")
                    .check(CheckType.INVOKED_ONCE, "the stored connection must be looked up by its identifier", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "the supplied connectionId must be used for the lookup", "connectionSettingRepository", "findById", "0", "data:request.connectionId")
                    .check(CheckType.INVOKED_ONCE, "the connection test must be delegated to the declared repository", "connectionSettingRepository", "testConnection")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the reported outcome must be the one the repository produced", "stub:connectionSettingRepository#testConnection")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 0", "connectionSettingRepository", "testConnection", "0", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 1", "connectionSettingRepository", "testConnection", "1", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 2", "connectionSettingRepository", "testConnection", "2", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 3", "connectionSettingRepository", "testConnection", "3", "data:request.dbUsername")
                    .check(CheckType.ARG_NOT_EQUALS, "the request field must not override the stored connection parameter 4", "connectionSettingRepository", "testConnection", "4", "data:request.dbUsername")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

}

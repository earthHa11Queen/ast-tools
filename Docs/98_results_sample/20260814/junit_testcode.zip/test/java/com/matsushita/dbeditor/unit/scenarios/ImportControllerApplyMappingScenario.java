package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ImportControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ImportController#applyMapping.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ImportControllerApplyMappingScenario {

    @Test
    @DisplayName("UTAPI-000549")
    void case_UTAPI_000549() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000549",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000549", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000549", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000549", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000549", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000549", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000549", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000549", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000549", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000549", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000549", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000549", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000549")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.connectionId", "MappingApplyRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MappingApplyRequest.connectionId classifies this input condition", "MappingApplyRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000550")
    void case_UTAPI_000550() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000550",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000550", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000550", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000550", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000550", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000550", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000550", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000550", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000550", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000550", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000550", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000550", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000550")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("request.connectionId", "MappingApplyRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MappingApplyRequest.connectionId classifies this input condition", "MappingApplyRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000551")
    void case_UTAPI_000551() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000551",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000551", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000551", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000551", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000551", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000551", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000551", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000551", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000551", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000551", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000551", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000551", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000551")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.connectionId", "MappingApplyRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MappingApplyRequest.connectionId classifies this input condition", "MappingApplyRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000552")
    void case_UTAPI_000552() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000552",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000552", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000552", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000552", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000552", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000552", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000552", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000552", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000552", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000552", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000552", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000552", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000552")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("request.connectionId", "MappingApplyRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MappingApplyRequest.connectionId classifies this input condition", "MappingApplyRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000553")
    void case_UTAPI_000553() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000553",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000553", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000553", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000553", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000553", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000553", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000553", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000553", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000553", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000553", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000553", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000553", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000553")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.connectionId", "MappingApplyRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MappingApplyRequest.connectionId classifies this input condition", "MappingApplyRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000554")
    void case_UTAPI_000554() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000554",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000554", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000554", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000554", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000554", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000554", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000554", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000554", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000554", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000554", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000554", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000554", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000554")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.connectionId", "MappingApplyRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MappingApplyRequest.connectionId classifies this input condition", "MappingApplyRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000555")
    void case_UTAPI_000555() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000555",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000555", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000555", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000555", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000555", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000555", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000555", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000555", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000555", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000555", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000555", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000555", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000555")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("request.connectionId", "MappingApplyRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000556")
    void case_UTAPI_000556() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000556",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000556", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000556", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000556", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000556", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000556", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000556", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000556", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000556", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000556", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000556", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000556", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000556")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("request.connectionId", "MappingApplyRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000557")
    void case_UTAPI_000557() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000557",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000557", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000557", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000557", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000557", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000557", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000557", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000557", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000557", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000557", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000557", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000557", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000557")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("request.connectionId", "MappingApplyRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000558")
    void case_UTAPI_000558() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000558",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000558", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000558", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000558", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000558", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000558", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000558", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000558", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000558", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000558", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000558", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000558", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000558")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("request.connectionId", "MappingApplyRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000559")
    void case_UTAPI_000559() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000559",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000559", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000559", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000559", "request.mapping", "TARGET", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000559", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000559", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000559", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000559", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000559", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000559", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000559", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000559", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000559")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::mapping")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.mapping", "MappingApplyRequest.mapping")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.mapping is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MappingApplyRequest.mapping classifies this input condition", "MappingApplyRequest", "mapping", "NotNull", "data:request.mapping")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000560")
    void case_UTAPI_000560() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000560",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000560", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000560", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000560", "request.mapping", "TARGET", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000560", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000560", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000560", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000560", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000560", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000560", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000560", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000560", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000560")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::mapping")
                    .mirror("-", "3:length_min", "-")
                    .target("request.mapping", "MappingApplyRequest.mapping")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.mapping is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MappingApplyRequest.mapping classifies this input condition", "MappingApplyRequest", "mapping", "NotNull", "data:request.mapping")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000561")
    void case_UTAPI_000561() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000561",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000561", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000561", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000561", "request.mapping", "TARGET", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000561", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000561", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000561", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000561", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000561", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000561", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000561", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000561", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000561")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::mapping")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.mapping", "MappingApplyRequest.mapping")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.mapping is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MappingApplyRequest.mapping classifies this input condition", "MappingApplyRequest", "mapping", "NotNull", "data:request.mapping")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000562")
    void case_UTAPI_000562() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000562",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000562", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000562", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000562", "request.mapping", "TARGET", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000562", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000562", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000562", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000562", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000562", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000562", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000562", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000562", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000562")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::mapping")
                    .mirror("-", "5:length_max", "-")
                    .target("request.mapping", "MappingApplyRequest.mapping")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.mapping is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MappingApplyRequest.mapping classifies this input condition", "MappingApplyRequest", "mapping", "NotNull", "data:request.mapping")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000563")
    void case_UTAPI_000563() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000563",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000563", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000563", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000563", "request.mapping", "TARGET", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000563", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000563", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000563", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000563", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000563", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000563", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000563", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000563", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000563")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::mapping")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.mapping", "MappingApplyRequest.mapping")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.mapping is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MappingApplyRequest.mapping classifies this input condition", "MappingApplyRequest", "mapping", "NotNull", "data:request.mapping")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000564")
    void case_UTAPI_000564() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000564",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000564", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000564", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000564", "request.mapping", "TARGET", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000564", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000564", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000564", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000564", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000564", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000564", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000564", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000564", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000564")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::mapping")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.mapping", "MappingApplyRequest.mapping")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.mapping is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MappingApplyRequest.mapping classifies this input condition", "MappingApplyRequest", "mapping", "NotNull", "data:request.mapping")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000565")
    void case_UTAPI_000565() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000565",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000565", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000565", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000565", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000565", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000565", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000565", "request.rows", "TARGET", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000565", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000565", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000565", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000565", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000565", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000565")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::rows")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.rows", "MappingApplyRequest.rows")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.rows is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MappingApplyRequest.rows classifies this input condition", "MappingApplyRequest", "rows", "NotNull", "data:request.rows")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000566")
    void case_UTAPI_000566() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000566",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000566", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000566", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000566", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000566", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000566", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000566", "request.rows", "TARGET", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000566", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000566", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000566", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000566", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000566", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000566")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::rows")
                    .mirror("-", "3:length_min", "-")
                    .target("request.rows", "MappingApplyRequest.rows")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.rows is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MappingApplyRequest.rows classifies this input condition", "MappingApplyRequest", "rows", "NotNull", "data:request.rows")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000567")
    void case_UTAPI_000567() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000567",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000567", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000567", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000567", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000567", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000567", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000567", "request.rows", "TARGET", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000567", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000567", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000567", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000567", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000567", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000567")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::rows")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.rows", "MappingApplyRequest.rows")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.rows is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MappingApplyRequest.rows classifies this input condition", "MappingApplyRequest", "rows", "NotNull", "data:request.rows")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000568")
    void case_UTAPI_000568() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000568",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000568", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000568", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000568", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000568", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000568", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000568", "request.rows", "TARGET", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000568", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000568", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000568", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000568", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000568", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000568")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::rows")
                    .mirror("-", "5:length_max", "-")
                    .target("request.rows", "MappingApplyRequest.rows")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.rows is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MappingApplyRequest.rows classifies this input condition", "MappingApplyRequest", "rows", "NotNull", "data:request.rows")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000569")
    void case_UTAPI_000569() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000569",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000569", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000569", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000569", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000569", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000569", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000569", "request.rows", "TARGET", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000569", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000569", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000569", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000569", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000569", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000569")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::rows")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.rows", "MappingApplyRequest.rows")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.rows is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MappingApplyRequest.rows classifies this input condition", "MappingApplyRequest", "rows", "NotNull", "data:request.rows")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000570")
    void case_UTAPI_000570() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000570",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000570", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000570", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000570", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000570", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000570", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000570", "request.rows", "TARGET", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000570", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000570", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000570", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000570", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000570", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000570")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::rows")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.rows", "MappingApplyRequest.rows")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.rows is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MappingApplyRequest.rows classifies this input condition", "MappingApplyRequest", "rows", "NotNull", "data:request.rows")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000571")
    void case_UTAPI_000571() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000571",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000571", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000571", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000571", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000571", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000571", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000571", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000571", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000571", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000571", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000571", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000571", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000571")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("request.schemaName", "MappingApplyRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000572")
    void case_UTAPI_000572() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000572",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000572", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000572", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000572", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000572", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000572", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000572", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000572", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000572", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000572", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000572", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000572", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000572")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.schemaName", "MappingApplyRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000573")
    void case_UTAPI_000573() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000573",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000573", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000573", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000573", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000573", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000573", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000573", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000573", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000573", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000573", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000573", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000573", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000573")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("request.schemaName", "MappingApplyRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000574")
    void case_UTAPI_000574() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000574",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000574", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000574", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000574", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000574", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000574", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000574", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000574", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000574", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000574", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000574", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000574", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000574")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.schemaName", "MappingApplyRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000575")
    void case_UTAPI_000575() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000575",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000575", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000575", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000575", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000575", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000575", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000575", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000575", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000575", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000575", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000575", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000575", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000575")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("request.schemaName", "MappingApplyRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000576")
    void case_UTAPI_000576() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000576",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000576", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000576", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000576", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000576", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000576", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000576", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000576", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000576", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000576", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000576", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000576", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000576")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.schemaName", "MappingApplyRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000577")
    void case_UTAPI_000577() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000577",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000577", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000577", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000577", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000577", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000577", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000577", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000577", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000577", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000577", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000577", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000577", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000577")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.schemaName", "MappingApplyRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000578")
    void case_UTAPI_000578() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000578",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000578", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000578", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000578", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000578", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000578", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000578", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000578", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000578", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000578", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000578", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000578", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000578")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.schemaName", "MappingApplyRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000579")
    void case_UTAPI_000579() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000579",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000579", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000579", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000579", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000579", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000579", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000579", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000579", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000579", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000579", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000579", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000579", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000579")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.schemaName", "MappingApplyRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000580")
    void case_UTAPI_000580() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000580",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000580", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000580", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000580", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000580", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000580", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000580", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000580", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000580", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000580", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000580", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000580", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000580")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.schemaName", "MappingApplyRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000581")
    void case_UTAPI_000581() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000581",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000581", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000581", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000581", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000581", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000581", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000581", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000581", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000581", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000581", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000581", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000581", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000581")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("request.schemaName", "MappingApplyRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000582")
    void case_UTAPI_000582() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000582",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000582", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000582", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000582", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000582", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000582", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000582", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000582", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000582", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000582", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000582", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000582", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000582")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.schemaName", "MappingApplyRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000583")
    void case_UTAPI_000583() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000583",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000583", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000583", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000583", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000583", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000583", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000583", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000583", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000583", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000583", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000583", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000583", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000583")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.schemaName", "MappingApplyRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000584")
    void case_UTAPI_000584() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000584",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000584", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000584", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000584", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000584", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000584", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000584", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000584", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000584", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000584", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000584", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000584", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000584")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("request.schemaName", "MappingApplyRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000585")
    void case_UTAPI_000585() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000585",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000585", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000585", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000585", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000585", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000585", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000585", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000585", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000585", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000585", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000585", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000585", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000585")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.schemaName", "MappingApplyRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000586")
    void case_UTAPI_000586() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000586",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000586", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000586", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000586", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000586", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000586", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000586", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000586", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000586", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000586", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000586", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000586", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000586")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.schemaName", "MappingApplyRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000587")
    void case_UTAPI_000587() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000587",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000587", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000587", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000587", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000587", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000587", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000587", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000587", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000587", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000587", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000587", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000587", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000587")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("request.schemaName", "MappingApplyRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000588")
    void case_UTAPI_000588() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000588",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000588", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000588", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000588", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000588", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000588", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000588", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000588", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000588", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000588", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000588", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000588", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000588")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.schemaName", "MappingApplyRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000589")
    void case_UTAPI_000589() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000589",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000589", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000589", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000589", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000589", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000589", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000589", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000589", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000589", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000589", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000589", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000589", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000589")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.schemaName", "MappingApplyRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000590")
    void case_UTAPI_000590() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000590",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000590", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000590", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000590", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000590", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000590", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000590", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000590", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000590", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000590", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000590", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000590", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000590")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.schemaName", "MappingApplyRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000591")
    void case_UTAPI_000591() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000591",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000591", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000591", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000591", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000591", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000591", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000591", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000591", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000591", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000591", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000591", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000591", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000591")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.schemaName", "MappingApplyRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000592")
    void case_UTAPI_000592() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000592",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000592", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000592", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000592", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000592", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000592", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000592", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000592", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000592", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000592", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000592", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000592", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000592")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.tableName", "MappingApplyRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MappingApplyRequest.tableName classifies this input condition", "MappingApplyRequest", "tableName", "NotNull", "data:request.tableName")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000593")
    void case_UTAPI_000593() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000593",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000593", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000593", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000593", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000593", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000593", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000593", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000593", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000593", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000593", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000593", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000593", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000593")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("request.tableName", "MappingApplyRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MappingApplyRequest.tableName classifies this input condition", "MappingApplyRequest", "tableName", "NotNull", "data:request.tableName")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000594")
    void case_UTAPI_000594() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000594",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000594", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000594", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000594", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000594", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000594", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000594", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000594", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000594", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000594", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000594", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000594", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000594")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.tableName", "MappingApplyRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MappingApplyRequest.tableName classifies this input condition", "MappingApplyRequest", "tableName", "NotNull", "data:request.tableName")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000595")
    void case_UTAPI_000595() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000595",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000595", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000595", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000595", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000595", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000595", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000595", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000595", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000595", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000595", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000595", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000595", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000595")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("request.tableName", "MappingApplyRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MappingApplyRequest.tableName classifies this input condition", "MappingApplyRequest", "tableName", "NotNull", "data:request.tableName")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000596")
    void case_UTAPI_000596() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000596",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000596", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000596", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000596", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000596", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000596", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000596", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000596", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000596", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000596", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000596", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000596", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000596")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.tableName", "MappingApplyRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MappingApplyRequest.tableName classifies this input condition", "MappingApplyRequest", "tableName", "NotNull", "data:request.tableName")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000597")
    void case_UTAPI_000597() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000597",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000597", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000597", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000597", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000597", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000597", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000597", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000597", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000597", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000597", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000597", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000597", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000597")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.tableName", "MappingApplyRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MappingApplyRequest.tableName classifies this input condition", "MappingApplyRequest", "tableName", "NotNull", "data:request.tableName")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000598")
    void case_UTAPI_000598() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000598",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000598", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000598", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000598", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000598", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000598", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000598", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000598", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000598", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000598", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000598", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000598", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000598")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.tableName", "MappingApplyRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000599")
    void case_UTAPI_000599() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000599",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000599", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000599", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000599", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000599", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000599", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000599", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000599", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000599", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000599", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000599", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000599", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000599")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.tableName", "MappingApplyRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000600")
    void case_UTAPI_000600() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000600",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000600", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000600", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000600", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000600", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000600", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000600", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000600", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000600", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000600", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000600", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000600", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000600")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.tableName", "MappingApplyRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000601")
    void case_UTAPI_000601() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000601",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000601", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000601", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000601", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000601", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000601", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000601", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000601", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000601", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000601", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000601", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000601", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000601")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("request.tableName", "MappingApplyRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000602")
    void case_UTAPI_000602() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000602",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000602", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000602", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000602", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000602", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000602", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000602", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000602", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000602", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000602", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000602", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000602", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000602")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.tableName", "MappingApplyRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000603")
    void case_UTAPI_000603() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000603",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000603", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000603", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000603", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000603", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000603", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000603", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000603", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000603", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000603", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000603", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000603", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000603")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.tableName", "MappingApplyRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000604")
    void case_UTAPI_000604() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000604",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000604", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000604", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000604", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000604", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000604", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000604", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000604", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000604", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000604", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000604", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000604", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000604")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::tableName")
                    .mirror("-", "-", "56:space")
                    .target("request.tableName", "MappingApplyRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000605")
    void case_UTAPI_000605() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000605",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000605", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000605", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000605", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000605", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000605", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000605", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000605", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000605", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000605", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000605", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000605", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000605")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.tableName", "MappingApplyRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000606")
    void case_UTAPI_000606() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000606",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000606", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000606", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000606", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000606", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000606", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000606", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000606", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000606", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000606", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000606", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000606", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000606")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.tableName", "MappingApplyRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000607")
    void case_UTAPI_000607() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000607",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000607", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000607", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000607", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000607", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000607", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000607", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000607", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000607", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000607", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000607", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000607", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000607")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("request.tableName", "MappingApplyRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000608")
    void case_UTAPI_000608() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000608",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000608", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000608", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000608", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000608", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000608", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000608", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000608", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000608", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000608", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000608", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000608", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000608")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.tableName", "MappingApplyRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000609")
    void case_UTAPI_000609() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000609",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000609", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000609", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000609", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000609", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000609", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000609", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000609", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000609", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000609", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000609", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000609", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000609")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.tableName", "MappingApplyRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000610")
    void case_UTAPI_000610() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000610",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000610", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000610", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000610", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000610", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000610", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000610", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000610", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000610", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000610", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000610", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000610", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000610")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.tableName", "MappingApplyRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000611")
    void case_UTAPI_000611() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000611",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "applyMapping",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "MappingApplyRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000611", "request", "NORMAL", "OBJECT", "MappingApplyRequest"),
                    new DataRef("UTAPI-000611", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000611", "request.mapping", "NORMAL", "MAP", "Map<String,String>"),
                    new DataRef("UTAPI-000611", "request.mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000611", "request.mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000611", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000611", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000611", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000611", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000611", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000611", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000611")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::applyMapping::5::FIELD::1::MappingApplyRequest::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.tableName", "MappingApplyRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.applyMapping")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.applyMapping", "importUseCase", "applyMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.applyMapping must carry the value generated for request.connectionId", "importUseCase", "applyMapping", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.applyMapping must carry the value generated for request.tableName", "importUseCase", "applyMapping", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.applyMapping must carry the value generated for request.schemaName", "importUseCase", "applyMapping", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.applyMapping must carry the value generated for request.mapping", "importUseCase", "applyMapping", "3", "data:request.mapping")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.applyMapping must carry the value generated for request.rows", "importUseCase", "applyMapping", "4", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

}

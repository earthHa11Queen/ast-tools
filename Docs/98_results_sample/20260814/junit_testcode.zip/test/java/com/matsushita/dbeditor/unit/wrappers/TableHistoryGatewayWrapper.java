package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Operation wrapper for TableHistoryGateway.
 */
public final class TableHistoryGatewayWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway";
    private static final String[] DEP_NAMES = new String[] {"targetDatabaseConnector"};
    private static final String[] DEP_TYPES = new String[] {"TargetDatabaseConnector"};
    private static final String[] TYPES_ensureHistoryIndex = new String[] {"JdbcTemplate", "String"};
    private static final String[] TYPES_findHistoryList = new String[] {"ConnectionSetting", "String", "String"};
    private static final String[] TYPES_findHistoryRecords = new String[] {"ConnectionSetting", "String", "String", "int"};
    private static final String[] TYPES_nextSeq = new String[] {"JdbcTemplate", "String", "String"};
    private static final String[] TYPES_restoreHistory = new String[] {"ConnectionSetting", "String", "String", "int"};
    private static final String[] TYPES_saveHistory = new String[] {"ConnectionSetting", "String", "String", "List<Map<String, Object>>"};

    public TableHistoryGatewayWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, false);
    }

    /** void ensureHistoryIndex(jdbc, schemaName) */
    public ExecutionResult ensureHistoryIndex(Object[] args) {
        return invoke("ensureHistoryIndex", TYPES_ensureHistoryIndex, args);
    }

    /** List<Map<String,Object>> findHistoryList(setting, schemaName, tableName) */
    public ExecutionResult findHistoryList(Object[] args) {
        return invoke("findHistoryList", TYPES_findHistoryList, args);
    }

    /** List<Map<String,Object>> findHistoryRecords(setting, schemaName, tableName, seq) */
    public ExecutionResult findHistoryRecords(Object[] args) {
        return invoke("findHistoryRecords", TYPES_findHistoryRecords, args);
    }

    /** int nextSeq(jdbc, schemaName, tableName) */
    public ExecutionResult nextSeq(Object[] args) {
        return invoke("nextSeq", TYPES_nextSeq, args);
    }

    /** void restoreHistory(setting, schemaName, tableName, seq) */
    public ExecutionResult restoreHistory(Object[] args) {
        return invoke("restoreHistory", TYPES_restoreHistory, args);
    }

    /** int saveHistory(setting, schemaName, tableName, records) */
    public ExecutionResult saveHistory(Object[] args) {
        return invoke("saveHistory", TYPES_saveHistory, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("ensureHistoryIndex".equals(operation)) {
            return ensureHistoryIndex(args);
        } else if ("findHistoryList".equals(operation)) {
            return findHistoryList(args);
        } else if ("findHistoryRecords".equals(operation)) {
            return findHistoryRecords(args);
        } else if ("nextSeq".equals(operation)) {
            return nextSeq(args);
        } else if ("restoreHistory".equals(operation)) {
            return restoreHistory(args);
        } else if ("saveHistory".equals(operation)) {
            return saveHistory(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

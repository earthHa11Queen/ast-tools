package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Operation wrapper for TemplateUseCase.
 */
public final class TemplateUseCaseWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.usecase.file.TemplateUseCase";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.usecase.file.TemplateUseCase";
    private static final String[] DEP_NAMES = new String[] {"memoTemplateRepository", "sqlTemplateRepository"};
    private static final String[] DEP_TYPES = new String[] {"MemoTemplateRepository", "SqlTemplateRepository"};
    private static final String[] TYPES_deleteMemoTemplate = new String[] {"Integer"};
    private static final String[] TYPES_deleteSqlTemplate = new String[] {"Integer"};
    private static final String[] TYPES_listMemoTemplates = new String[] {};
    private static final String[] TYPES_listSqlTemplates = new String[] {};
    private static final String[] TYPES_saveMemoTemplate = new String[] {"String", "String"};
    private static final String[] TYPES_saveSqlTemplate = new String[] {"String", "String"};

    public TemplateUseCaseWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, false);
    }

    /** void deleteMemoTemplate(n) */
    public ExecutionResult deleteMemoTemplate(Object[] args) {
        return invoke("deleteMemoTemplate", TYPES_deleteMemoTemplate, args);
    }

    /** void deleteSqlTemplate(n) */
    public ExecutionResult deleteSqlTemplate(Object[] args) {
        return invoke("deleteSqlTemplate", TYPES_deleteSqlTemplate, args);
    }

    /** List<TemplateResponse> listMemoTemplates() */
    public ExecutionResult listMemoTemplates(Object[] args) {
        return invoke("listMemoTemplates", TYPES_listMemoTemplates, args);
    }

    /** List<TemplateResponse> listSqlTemplates() */
    public ExecutionResult listSqlTemplates(Object[] args) {
        return invoke("listSqlTemplates", TYPES_listSqlTemplates, args);
    }

    /** TemplateResponse saveMemoTemplate(title, content) */
    public ExecutionResult saveMemoTemplate(Object[] args) {
        return invoke("saveMemoTemplate", TYPES_saveMemoTemplate, args);
    }

    /** TemplateResponse saveSqlTemplate(title, content) */
    public ExecutionResult saveSqlTemplate(Object[] args) {
        return invoke("saveSqlTemplate", TYPES_saveSqlTemplate, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("deleteMemoTemplate".equals(operation)) {
            return deleteMemoTemplate(args);
        } else if ("deleteSqlTemplate".equals(operation)) {
            return deleteSqlTemplate(args);
        } else if ("listMemoTemplates".equals(operation)) {
            return listMemoTemplates(args);
        } else if ("listSqlTemplates".equals(operation)) {
            return listSqlTemplates(args);
        } else if ("saveMemoTemplate".equals(operation)) {
            return saveMemoTemplate(args);
        } else if ("saveSqlTemplate".equals(operation)) {
            return saveSqlTemplate(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

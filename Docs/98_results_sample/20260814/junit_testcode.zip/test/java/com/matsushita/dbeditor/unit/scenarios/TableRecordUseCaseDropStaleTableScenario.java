package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableRecordUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableRecordUseCase#dropStaleTable.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableRecordUseCaseDropStaleTableScenario {

    @Test
    @DisplayName("UTAPI-013322")
    void case_UTAPI_013322() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013322",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013322", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013322", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013322", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013322")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013323")
    void case_UTAPI_013323() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013323",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013323", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013323", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013323", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013323")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013324")
    void case_UTAPI_013324() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013324",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013324", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013324", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013324", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013324")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013325")
    void case_UTAPI_013325() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013325",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013325", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013325", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013325", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013325")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013326")
    void case_UTAPI_013326() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013326",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013326", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013326", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013326", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013326")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013327")
    void case_UTAPI_013327() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013327",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013327", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013327", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013327", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013327")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013328")
    void case_UTAPI_013328() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013328",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013328", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013328", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013328", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013328")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013329")
    void case_UTAPI_013329() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013329",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013329", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013329", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013329", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013329")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013330")
    void case_UTAPI_013330() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013330",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013330", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013330", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013330", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013330")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013331")
    void case_UTAPI_013331() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013331",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013331", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013331", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013331", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013331")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013332")
    void case_UTAPI_013332() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013332",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013332", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013332", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013332", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013332")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013333")
    void case_UTAPI_013333() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013333",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013333", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013333", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013333", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013333")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013334")
    void case_UTAPI_013334() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013334",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013334", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013334", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013334", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013334")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013335")
    void case_UTAPI_013335() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013335",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013335", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013335", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013335", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013335")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013336")
    void case_UTAPI_013336() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013336",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013336", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013336", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013336", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013336")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013337")
    void case_UTAPI_013337() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013337",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013337", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013337", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013337", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013337")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013338")
    void case_UTAPI_013338() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013338",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013338", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013338", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013338", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013338")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013339")
    void case_UTAPI_013339() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013339",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013339", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013339", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013339", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013339")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013340")
    void case_UTAPI_013340() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013340",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013340", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013340", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013340", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013340")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013341")
    void case_UTAPI_013341() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013341",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013341", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013341", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013341", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013341")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013342")
    void case_UTAPI_013342() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013342",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013342", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013342", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013342", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013342")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013343")
    void case_UTAPI_013343() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013343",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013343", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013343", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013343", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013343")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013344")
    void case_UTAPI_013344() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013344",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013344", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013344", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013344", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013344")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013345")
    void case_UTAPI_013345() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013345",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013345", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013345", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013345", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013345")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013346")
    void case_UTAPI_013346() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013346",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013346", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013346", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013346", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013346")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013347")
    void case_UTAPI_013347() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013347",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013347", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013347", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013347", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013347")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013348")
    void case_UTAPI_013348() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013348",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013348", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013348", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013348", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013348")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013349")
    void case_UTAPI_013349() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013349",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013349", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013349", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013349", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013349")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013350")
    void case_UTAPI_013350() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013350",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013350", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013350", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013350", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013350")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013351")
    void case_UTAPI_013351() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013351",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013351", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013351", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013351", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013351")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013352")
    void case_UTAPI_013352() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013352",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013352", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013352", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013352", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013352")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013353")
    void case_UTAPI_013353() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013353",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013353", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013353", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013353", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013353")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013354")
    void case_UTAPI_013354() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013354",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013354", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013354", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013354", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013354")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013355")
    void case_UTAPI_013355() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013355",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013355", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013355", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013355", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013355")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013356")
    void case_UTAPI_013356() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013356",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013356", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013356", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013356", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013356")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013357")
    void case_UTAPI_013357() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013357",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013357", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013357", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013357", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013357")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013358")
    void case_UTAPI_013358() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013358",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013358", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013358", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013358", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013358")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013359")
    void case_UTAPI_013359() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013359",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013359", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013359", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013359", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013359")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013360")
    void case_UTAPI_013360() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013360",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013360", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013360", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013360", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013360")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013361")
    void case_UTAPI_013361() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013361",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013361", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013361", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013361", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013361")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013362")
    void case_UTAPI_013362() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013362",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013362", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013362", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013362", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013362")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013363")
    void case_UTAPI_013363() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013363",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013363", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013363", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013363", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013363")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013364")
    void case_UTAPI_013364() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013364",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013364", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013364", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013364", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013364")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013365")
    void case_UTAPI_013365() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013365",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013365", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013365", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013365", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013365")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013366")
    void case_UTAPI_013366() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013366",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013366", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013366", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013366", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013366")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013367")
    void case_UTAPI_013367() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013367",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013367", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013367", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013367", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013367")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013368")
    void case_UTAPI_013368() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013368",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013368", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013368", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013368", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013368")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013369")
    void case_UTAPI_013369() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013369",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013369", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013369", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013369", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013369")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013370")
    void case_UTAPI_013370() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013370",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013370", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013370", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013370", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013370")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013371")
    void case_UTAPI_013371() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013371",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013371", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013371", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013371", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013371")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013372")
    void case_UTAPI_013372() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013372",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013372", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013372", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013372", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013372")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013373")
    void case_UTAPI_013373() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013373",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013373", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013373", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013373", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013373")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013374")
    void case_UTAPI_013374() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013374",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "dropStaleTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013374", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013374", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013374", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013374")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::dropStaleTable::6::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.dropTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.dropTable", "tableRecordRepository", "dropTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.dropTable must carry the value generated for schemaName", "tableRecordRepository", "dropTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.dropTable must carry the value generated for tableName", "tableRecordRepository", "dropTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ExportControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ExportController#markdown.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ExportControllerMarkdownScenario {

    @Test
    @DisplayName("UTAPI-000496")
    void case_UTAPI_000496() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000496",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000496", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000496", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000496", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000496")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::1::-::name")
                    .mirror("-", "1:length_null", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000497")
    void case_UTAPI_000497() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000497",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000497", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000497", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000497", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000497")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::1::-::name")
                    .mirror("-", "2:length_empty", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000498")
    void case_UTAPI_000498() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000498",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000498", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000498", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000498", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000498")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::1::-::name")
                    .mirror("-", "3:length_min", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000499")
    void case_UTAPI_000499() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000499",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000499", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000499", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000499", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000499")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::1::-::name")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000500")
    void case_UTAPI_000500() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000500",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000500", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000500", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000500", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000500")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::1::-::name")
                    .mirror("-", "5:length_max", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000501")
    void case_UTAPI_000501() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000501",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000501", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000501", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000501", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000501")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::1::-::name")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000502")
    void case_UTAPI_000502() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000502",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000502", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000502", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000502", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000502")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::1::-::name")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000503")
    void case_UTAPI_000503() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000503",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000503", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000503", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000503", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000503")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::1::-::name")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000504")
    void case_UTAPI_000504() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000504",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000504", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000504", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000504", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000504")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::1::-::name")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000505")
    void case_UTAPI_000505() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000505",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000505", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000505", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000505", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000505")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::1::-::name")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000506")
    void case_UTAPI_000506() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000506",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000506", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000506", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000506", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000506")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::1::-::name")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000507")
    void case_UTAPI_000507() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000507",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000507", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000507", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000507", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000507")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::1::-::name")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000508")
    void case_UTAPI_000508() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000508",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000508", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000508", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000508", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000508")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::1::-::name")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000509")
    void case_UTAPI_000509() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000509",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000509", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000509", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000509", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000509")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::1::-::name")
                    .mirror("-", "-", "56:space")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000510")
    void case_UTAPI_000510() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000510",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000510", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000510", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000510", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000510")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::1::-::name")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000511")
    void case_UTAPI_000511() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000511",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000511", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000511", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000511", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000511")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::1::-::name")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000512")
    void case_UTAPI_000512() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000512",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000512", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000512", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000512", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000512")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::1::-::name")
                    .mirror("-", "-", "59:tab")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000513")
    void case_UTAPI_000513() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000513",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000513", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000513", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000513", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000513")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::1::-::name")
                    .mirror("-", "-", "60:control_character_null")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000514")
    void case_UTAPI_000514() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000514",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000514", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000514", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000514", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000514")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::1::-::name")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000515")
    void case_UTAPI_000515() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000515",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000515", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000515", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000515", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000515")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::1::-::name")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000516")
    void case_UTAPI_000516() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000516",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000516", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000516", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000516", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000516")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::1::-::name")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000517")
    void case_UTAPI_000517() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000517",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000517", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000517", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000517", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000517")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::2::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000518")
    void case_UTAPI_000518() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000518",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000518", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000518", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000518", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000518")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::2::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000519")
    void case_UTAPI_000519() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000519",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000519", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000519", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000519", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000519")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::2::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000520")
    void case_UTAPI_000520() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000520",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000520", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000520", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000520", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000520")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::2::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000521")
    void case_UTAPI_000521() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000521",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000521", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000521", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000521", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000521")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::2::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000522")
    void case_UTAPI_000522() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000522",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000522", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000522", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000522", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000522")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::2::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000523")
    void case_UTAPI_000523() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000523",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000523", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000523", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000523", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000523")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::2::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000524")
    void case_UTAPI_000524() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000524",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000524", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000524", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000524", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000524")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::2::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000525")
    void case_UTAPI_000525() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000525",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000525", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000525", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000525", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000525")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::2::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000526")
    void case_UTAPI_000526() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000526",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000526", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000526", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000526", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000526")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::2::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000527")
    void case_UTAPI_000527() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000527",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000527", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000527", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000527", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000527")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::2::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000528")
    void case_UTAPI_000528() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000528",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000528", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000528", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000528", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000528")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::3::-::schema")
                    .mirror("-", "1:length_null", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000529")
    void case_UTAPI_000529() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000529",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000529", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000529", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000529", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000529")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::3::-::schema")
                    .mirror("-", "2:length_empty", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000530")
    void case_UTAPI_000530() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000530",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000530", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000530", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000530", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000530")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::3::-::schema")
                    .mirror("-", "3:length_min", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000531")
    void case_UTAPI_000531() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000531",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000531", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000531", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000531", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000531")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::3::-::schema")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000532")
    void case_UTAPI_000532() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000532",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000532", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000532", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000532", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000532")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::3::-::schema")
                    .mirror("-", "5:length_max", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000533")
    void case_UTAPI_000533() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000533",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000533", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000533", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000533", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000533")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::3::-::schema")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000534")
    void case_UTAPI_000534() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000534",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000534", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000534", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000534", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000534")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::3::-::schema")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000535")
    void case_UTAPI_000535() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000535",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000535", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000535", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000535", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000535")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::3::-::schema")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000536")
    void case_UTAPI_000536() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000536",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000536", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000536", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000536", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000536")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::3::-::schema")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000537")
    void case_UTAPI_000537() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000537",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000537", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000537", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000537", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000537")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::3::-::schema")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000538")
    void case_UTAPI_000538() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000538",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000538", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000538", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000538", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000538")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::3::-::schema")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000539")
    void case_UTAPI_000539() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000539",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000539", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000539", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000539", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000539")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::3::-::schema")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000540")
    void case_UTAPI_000540() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000540",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000540", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000540", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000540", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000540")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::3::-::schema")
                    .mirror("-", "-", "56:space")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000541")
    void case_UTAPI_000541() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000541",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000541", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000541", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000541", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000541")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::3::-::schema")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000542")
    void case_UTAPI_000542() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000542",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000542", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000542", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000542", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000542")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::3::-::schema")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000543")
    void case_UTAPI_000543() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000543",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000543", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000543", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000543", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000543")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::3::-::schema")
                    .mirror("-", "-", "59:tab")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000544")
    void case_UTAPI_000544() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000544",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000544", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000544", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000544", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000544")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::3::-::schema")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000545")
    void case_UTAPI_000545() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000545",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000545", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000545", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000545", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000545")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::3::-::schema")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000546")
    void case_UTAPI_000546() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000546",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000546", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000546", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000546", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000546")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::3::-::schema")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000547")
    void case_UTAPI_000547() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000547",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "markdown",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000547", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000547", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000547", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000547")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::markdown::2::ARG::3::-::schema")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.exportMarkdown")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through exportUseCase.exportMarkdown", "exportUseCase", "exportMarkdown")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.exportMarkdown must carry the value generated for connectionId", "exportUseCase", "exportMarkdown", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.exportMarkdown must carry the value generated for schema", "exportUseCase", "exportMarkdown", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.exportMarkdown must carry the value generated for name", "exportUseCase", "exportMarkdown", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TemplateControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TemplateController#deleteSqlTemplate.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TemplateControllerDeleteSqlTemplateScenario {

    @Test
    @DisplayName("UTAPI-001756")
    void case_UTAPI_001756() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001756",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "deleteSqlTemplate",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001756", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001756")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::deleteSqlTemplate::6::ARG::1::-::n")
                    .mirror("-", "1:length_null", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.deleteSqlTemplate")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.deleteSqlTemplate", "templateUseCase", "deleteSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.deleteSqlTemplate must carry the value generated for n", "templateUseCase", "deleteSqlTemplate", "0", "data:n")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001757")
    void case_UTAPI_001757() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001757",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "deleteSqlTemplate",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001757", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001757")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::deleteSqlTemplate::6::ARG::1::-::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.deleteSqlTemplate")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.deleteSqlTemplate", "templateUseCase", "deleteSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.deleteSqlTemplate must carry the value generated for n", "templateUseCase", "deleteSqlTemplate", "0", "data:n")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001758")
    void case_UTAPI_001758() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001758",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "deleteSqlTemplate",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001758", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001758")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::deleteSqlTemplate::6::ARG::1::-::n")
                    .mirror("-", "3:length_min", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.deleteSqlTemplate")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.deleteSqlTemplate", "templateUseCase", "deleteSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.deleteSqlTemplate must carry the value generated for n", "templateUseCase", "deleteSqlTemplate", "0", "data:n")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001759")
    void case_UTAPI_001759() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001759",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "deleteSqlTemplate",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001759", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001759")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::deleteSqlTemplate::6::ARG::1::-::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.deleteSqlTemplate")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.deleteSqlTemplate", "templateUseCase", "deleteSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.deleteSqlTemplate must carry the value generated for n", "templateUseCase", "deleteSqlTemplate", "0", "data:n")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001760")
    void case_UTAPI_001760() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001760",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "deleteSqlTemplate",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001760", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001760")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::deleteSqlTemplate::6::ARG::1::-::n")
                    .mirror("-", "5:length_max", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.deleteSqlTemplate")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.deleteSqlTemplate", "templateUseCase", "deleteSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.deleteSqlTemplate must carry the value generated for n", "templateUseCase", "deleteSqlTemplate", "0", "data:n")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001761")
    void case_UTAPI_001761() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001761",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "deleteSqlTemplate",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001761", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001761")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::deleteSqlTemplate::6::ARG::1::-::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.deleteSqlTemplate")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.deleteSqlTemplate", "templateUseCase", "deleteSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.deleteSqlTemplate must carry the value generated for n", "templateUseCase", "deleteSqlTemplate", "0", "data:n")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001762")
    void case_UTAPI_001762() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001762",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "deleteSqlTemplate",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001762", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001762")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::deleteSqlTemplate::6::ARG::1::-::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.deleteSqlTemplate")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.deleteSqlTemplate", "templateUseCase", "deleteSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.deleteSqlTemplate must carry the value generated for n", "templateUseCase", "deleteSqlTemplate", "0", "data:n")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001763")
    void case_UTAPI_001763() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001763",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "deleteSqlTemplate",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001763", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001763")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::deleteSqlTemplate::6::ARG::1::-::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.deleteSqlTemplate")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.deleteSqlTemplate", "templateUseCase", "deleteSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.deleteSqlTemplate must carry the value generated for n", "templateUseCase", "deleteSqlTemplate", "0", "data:n")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001764")
    void case_UTAPI_001764() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001764",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "deleteSqlTemplate",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001764", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001764")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::deleteSqlTemplate::6::ARG::1::-::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.deleteSqlTemplate")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.deleteSqlTemplate", "templateUseCase", "deleteSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.deleteSqlTemplate must carry the value generated for n", "templateUseCase", "deleteSqlTemplate", "0", "data:n")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001765")
    void case_UTAPI_001765() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001765",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "deleteSqlTemplate",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001765", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001765")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::deleteSqlTemplate::6::ARG::1::-::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.deleteSqlTemplate")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.deleteSqlTemplate", "templateUseCase", "deleteSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.deleteSqlTemplate must carry the value generated for n", "templateUseCase", "deleteSqlTemplate", "0", "data:n")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001766")
    void case_UTAPI_001766() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001766",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "deleteSqlTemplate",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001766", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001766")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::deleteSqlTemplate::6::ARG::1::-::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.deleteSqlTemplate")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.deleteSqlTemplate", "templateUseCase", "deleteSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.deleteSqlTemplate must carry the value generated for n", "templateUseCase", "deleteSqlTemplate", "0", "data:n")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

}

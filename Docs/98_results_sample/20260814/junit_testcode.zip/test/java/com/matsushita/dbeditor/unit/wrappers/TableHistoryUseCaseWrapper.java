package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Operation wrapper for TableHistoryUseCase.
 */
public final class TableHistoryUseCaseWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase";
    private static final String[] DEP_NAMES = new String[] {"connectionSettingRepository", "tableHistoryRepository"};
    private static final String[] DEP_TYPES = new String[] {"ConnectionSettingRepository", "TableHistoryRepository"};
    private static final String[] TYPES_getConnection = new String[] {"Integer"};
    private static final String[] TYPES_getHistoryList = new String[] {"Integer", "String", "String"};
    private static final String[] TYPES_getHistoryRecords = new String[] {"Integer", "String", "String", "int"};
    private static final String[] TYPES_restoreHistory = new String[] {"Integer", "String", "String", "int"};
    private static final String[] TYPES_saveHistory = new String[] {"Integer", "String", "String", "List<Map<String, Object>>"};

    public TableHistoryUseCaseWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, false);
    }

    /** ConnectionSetting getConnection(connectionId) */
    public ExecutionResult getConnection(Object[] args) {
        return invoke("getConnection", TYPES_getConnection, args);
    }

    /** List<Map<String,Object>> getHistoryList(connectionId, schemaName, tableName) */
    public ExecutionResult getHistoryList(Object[] args) {
        return invoke("getHistoryList", TYPES_getHistoryList, args);
    }

    /** List<Map<String,Object>> getHistoryRecords(connectionId, schemaName, tableName, seq) */
    public ExecutionResult getHistoryRecords(Object[] args) {
        return invoke("getHistoryRecords", TYPES_getHistoryRecords, args);
    }

    /** void restoreHistory(connectionId, schemaName, tableName, seq) */
    public ExecutionResult restoreHistory(Object[] args) {
        return invoke("restoreHistory", TYPES_restoreHistory, args);
    }

    /** int saveHistory(connectionId, schemaName, tableName, records) */
    public ExecutionResult saveHistory(Object[] args) {
        return invoke("saveHistory", TYPES_saveHistory, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("getConnection".equals(operation)) {
            return getConnection(args);
        } else if ("getHistoryList".equals(operation)) {
            return getHistoryList(args);
        } else if ("getHistoryRecords".equals(operation)) {
            return getHistoryRecords(args);
        } else if ("restoreHistory".equals(operation)) {
            return restoreHistory(args);
        } else if ("saveHistory".equals(operation)) {
            return saveHistory(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

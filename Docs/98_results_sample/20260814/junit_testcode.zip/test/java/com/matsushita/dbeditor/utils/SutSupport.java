package com.matsushita.dbeditor.utils;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Map;

import com.matsushita.dbeditor.constants.TestRunConstants;
import com.matsushita.dbeditor.fixtures.SentinelAnswer;
import com.matsushita.dbeditor.fixtures.SentinelRegistry;

/**
 * Construction and invocation support for SUT classes. The SUT is referenced by name and
 * resolved against the real production classes of the target project, so the generated test
 * code never duplicates production signatures.
 */
public final class SutSupport {

    private SutSupport() {
    }

    /**
     * Builds the SUT, injecting a collaborator double for every declared dependency.
     *
     * @param depNames declared dependency field names taken from AST Field Level
     * @param depTypes declared dependency field types taken from AST Field Level
     * @param mocksOut receives the collaborator doubles keyed by dependency field name
     */
    public static Object newSut(String implClassName, String[] depNames, String[] depTypes,
            SentinelRegistry registry, Map<String, Object> mocksOut) {
        Class<?> type = ProjectTypes.load(implClassName);
        if (type.isInterface() || Modifier.isAbstract(type.getModifiers())) {
            throw new HarnessException("Cannot instantiate abstract SUT " + implClassName);
        }
        Constructor<?> chosen = pickConstructor(type);
        if (chosen == null) {
            throw new HarnessException("No usable constructor on " + implClassName);
        }
        chosen.setAccessible(true);
        Class<?>[] paramTypes = chosen.getParameterTypes();
        Object[] args = new Object[paramTypes.length];
        boolean[] used = new boolean[depNames.length];
        for (int i = 0; i < paramTypes.length; i++) {
            Class<?> p = paramTypes[i];
            String matchedName = null;
            for (int d = 0; d < depNames.length; d++) {
                if (!used[d] && TypeSupport.matchesSimpleName(p, depTypes[d])) {
                    matchedName = depNames[d];
                    used[d] = true;
                    break;
                }
            }
            Object value = collaborator(p, registry);
            args[i] = value;
            if (matchedName != null) {
                mocksOut.put(matchedName, value);
            } else if (value != null && org.mockito.Mockito.mockingDetails(value).isMock()) {
                mocksOut.put("ctor" + i + ":" + p.getSimpleName(), value);
            }
        }
        try {
            return chosen.newInstance(args);
        } catch (Exception e) {
            Throwable cause = e instanceof InvocationTargetException ? e.getCause() : e;
            throw new HarnessException("Cannot construct SUT " + implClassName, cause);
        }
    }

    private static Object collaborator(Class<?> type, SentinelRegistry registry) {
        if (type == String.class) {
            return TestRunConstants.DEFAULT_SCHEMA;
        }
        if (type.isPrimitive()) {
            if (type == boolean.class) {
                return Boolean.FALSE;
            }
            if (type == long.class) {
                return Long.valueOf(0L);
            }
            if (type == double.class) {
                return Double.valueOf(0d);
            }
            if (type == float.class) {
                return Float.valueOf(0f);
            }
            if (type == char.class) {
                return Character.valueOf(' ');
            }
            return Integer.valueOf(0);
        }
        if (Number.class.isAssignableFrom(type) || type == Boolean.class || type == Character.class) {
            return null;
        }
        try {
            return org.mockito.Mockito.mock(type, org.mockito.Mockito.withSettings()
                    .defaultAnswer(new SentinelAnswer(registry)));
        } catch (Throwable t) {
            throw new HarnessException("Cannot create collaborator double for " + type.getName(), t);
        }
    }

    private static Constructor<?> pickConstructor(Class<?> type) {
        Constructor<?>[] ctors = type.getDeclaredConstructors();
        Constructor<?> best = null;
        for (int i = 0; i < ctors.length; i++) {
            if (best == null || ctors[i].getParameterCount() > best.getParameterCount()) {
                best = ctors[i];
            }
        }
        return best;
    }

    /** Resolves the target method using the declared argument types from AST Method Level. */
    public static Method resolveMethod(Class<?> owner, String methodName, String[] declaredTypes) {
        Class<?> current = owner;
        Method fallback = null;
        while (current != null && current != Object.class) {
            Method[] methods = current.getDeclaredMethods();
            for (int i = 0; i < methods.length; i++) {
                Method m = methods[i];
                if (!m.getName().equals(methodName)) {
                    continue;
                }
                if (m.getParameterCount() != declaredTypes.length) {
                    continue;
                }
                boolean match = true;
                Class<?>[] p = m.getParameterTypes();
                for (int j = 0; j < p.length; j++) {
                    if (!TypeSupport.matchesSimpleName(p[j], declaredTypes[j])) {
                        match = false;
                        break;
                    }
                }
                if (match) {
                    m.setAccessible(true);
                    return m;
                }
                if (fallback == null) {
                    fallback = m;
                }
            }
            current = current.getSuperclass();
        }
        if (fallback != null) {
            fallback.setAccessible(true);
            return fallback;
        }
        throw new HarnessException("Method not found: " + owner.getName() + "#" + methodName
                + " with declared types " + java.util.Arrays.toString(declaredTypes));
    }

    public static ExecutionResult invoke(Object sut, Class<?> owner, String methodName, String[] declaredTypes,
            Object[] args) {
        Class<?> resolveOn = sut == null ? owner : sut.getClass();
        Method method = resolveMethod(resolveOn, methodName, declaredTypes);
        try {
            Object value = method.invoke(Modifier.isStatic(method.getModifiers()) ? null : sut, args);
            return ExecutionResult.returned(value);
        } catch (InvocationTargetException e) {
            return ExecutionResult.threw(e.getCause() == null ? e : e.getCause());
        } catch (IllegalArgumentException e) {
            throw new HarnessException("Argument mismatch calling " + methodName + ": " + e.getMessage(), e);
        } catch (IllegalAccessException e) {
            throw new HarnessException("Cannot access " + methodName, e);
        }
    }

    public static Object rawInvoke(Object sut, Class<?> owner, String methodName, String[] declaredTypes,
            Object[] args) throws Throwable {
        Class<?> resolveOn = sut == null ? owner : sut.getClass();
        Method method = resolveMethod(resolveOn, methodName, declaredTypes);
        try {
            return method.invoke(Modifier.isStatic(method.getModifiers()) ? null : sut, args);
        } catch (InvocationTargetException e) {
            throw e.getCause() == null ? e : e.getCause();
        }
    }
}

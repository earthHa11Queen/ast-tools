package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableConflictGatewayWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableConflictGateway#applyToReal.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableConflictGatewayApplyToRealScenario {

    @Test
    @DisplayName("UTAPI-003127")
    void case_UTAPI_003127() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003127",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003127", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003127", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003127", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003127", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003127", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003127", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003127", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003127", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003127", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003127", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003127", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003127", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003127")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003128")
    void case_UTAPI_003128() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003128",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003128", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003128", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003128", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003128", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003128", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003128", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003128", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003128", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003128", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003128", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003128", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003128", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003128")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003129")
    void case_UTAPI_003129() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003129",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003129", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003129", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003129", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003129", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003129", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003129", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003129", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003129", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003129", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003129", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003129", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003129", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003129")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003130")
    void case_UTAPI_003130() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003130",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003130", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003130", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003130", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003130", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003130", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003130", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003130", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003130", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003130", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003130", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003130", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003130", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003130")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003131")
    void case_UTAPI_003131() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003131",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003131", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003131", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003131", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003131", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003131", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003131", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003131", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003131", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003131", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003131", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003131", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003131", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003131")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003132")
    void case_UTAPI_003132() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003132",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003132", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003132", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003132", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003132", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003132", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003132", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003132", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003132", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003132", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003132", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003132", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003132", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003132")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003133")
    void case_UTAPI_003133() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003133",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003133", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003133", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003133", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003133", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003133", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003133", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003133", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003133", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003133", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003133", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003133", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003133", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003133")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003134")
    void case_UTAPI_003134() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003134",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003134", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003134", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003134", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003134", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003134", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003134", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003134", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003134", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003134", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003134", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003134", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003134", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003134")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003135")
    void case_UTAPI_003135() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003135",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003135", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003135", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003135", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003135", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003135", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003135", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003135", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003135", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003135", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003135", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003135", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003135", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003135")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003136")
    void case_UTAPI_003136() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003136",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003136", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003136", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003136", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003136", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003136", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003136", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003136", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003136", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003136", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003136", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003136", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003136", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003136")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003137")
    void case_UTAPI_003137() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003137",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003137", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003137", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003137", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003137", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003137", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003137", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003137", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003137", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003137", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003137", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003137", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003137", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003137")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003138")
    void case_UTAPI_003138() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003138",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003138", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003138", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003138", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003138", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003138", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003138", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003138", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003138", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003138", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003138", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003138", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003138", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003138")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003139")
    void case_UTAPI_003139() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003139",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003139", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003139", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003139", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003139", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003139", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003139", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003139", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003139", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003139", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003139", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003139", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003139", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003139")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003140")
    void case_UTAPI_003140() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003140",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003140", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003140", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003140", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003140", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003140", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003140", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003140", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003140", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003140", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003140", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003140", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003140", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003140")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003141")
    void case_UTAPI_003141() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003141",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003141", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003141", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003141", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003141", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003141", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003141", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003141", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003141", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003141", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003141", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003141", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003141", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003141")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003142")
    void case_UTAPI_003142() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003142",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003142", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003142", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003142", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003142", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003142", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003142", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003142", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003142", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003142", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003142", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003142", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003142", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003142")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003143")
    void case_UTAPI_003143() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003143",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003143", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003143", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003143", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003143", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003143", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003143", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003143", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003143", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003143", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003143", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003143", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003143", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003143")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003144")
    void case_UTAPI_003144() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003144",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003144", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003144", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003144", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003144", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003144", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003144", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003144", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003144", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003144", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003144", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003144", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003144", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003144")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003145")
    void case_UTAPI_003145() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003145",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003145", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003145", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003145", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003145", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003145", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003145", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003145", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003145", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003145", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003145", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003145", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003145", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003145")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003146")
    void case_UTAPI_003146() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003146",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003146", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003146", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003146", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003146", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003146", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003146", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003146", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003146", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003146", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003146", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003146", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003146", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003146")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003147")
    void case_UTAPI_003147() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003147",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003147", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003147", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003147", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003147", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003147", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003147", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003147", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003147", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003147", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003147", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003147", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003147", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003147")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003148")
    void case_UTAPI_003148() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003148",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003148", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003148", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003148", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003148", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003148", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003148", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003148", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003148", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003148", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003148", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003148", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003148", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003148")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003149")
    void case_UTAPI_003149() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003149",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003149", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003149", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003149", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003149", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003149", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003149", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003149", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003149", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003149", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003149", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003149", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003149", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003149")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003150")
    void case_UTAPI_003150() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003150",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003150", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003150", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003150", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003150", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003150", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003150", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003150", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003150", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003150", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003150", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003150", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003150", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003150")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003151")
    void case_UTAPI_003151() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003151",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003151", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003151", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003151", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003151", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003151", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003151", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003151", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003151", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003151", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003151", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003151", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003151", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003151")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003152")
    void case_UTAPI_003152() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003152",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003152", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003152", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003152", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003152", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003152", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003152", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003152", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003152", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003152", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003152", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003152", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003152", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003152")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003153")
    void case_UTAPI_003153() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003153",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003153", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003153", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003153", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003153", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003153", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003153", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003153", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003153", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003153", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003153", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003153", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003153", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003153")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003154")
    void case_UTAPI_003154() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003154",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003154", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003154", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003154", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003154", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003154", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003154", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003154", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003154", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003154", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003154", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003154", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003154", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003154")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003155")
    void case_UTAPI_003155() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003155",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003155", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003155", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003155", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003155", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003155", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003155", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003155", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003155", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003155", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003155", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003155", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003155", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003155")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003156")
    void case_UTAPI_003156() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003156",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003156", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003156", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003156", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003156", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003156", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003156", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003156", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003156", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003156", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003156", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003156", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003156", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003156")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003157")
    void case_UTAPI_003157() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003157",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003157", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003157", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003157", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003157", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003157", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003157", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003157", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003157", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003157", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003157", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003157", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003157", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003157")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003158")
    void case_UTAPI_003158() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003158",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003158", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003158", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003158", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003158", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003158", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003158", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003158", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003158", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003158", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003158", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003158", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003158", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003158")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003159")
    void case_UTAPI_003159() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003159",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003159", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003159", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003159", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003159", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003159", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003159", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003159", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003159", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003159", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003159", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003159", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003159", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003159")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003160")
    void case_UTAPI_003160() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003160",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003160", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003160", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003160", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003160", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003160", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003160", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003160", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003160", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003160", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003160", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003160", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003160", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003160")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003161")
    void case_UTAPI_003161() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003161",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003161", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003161", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003161", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003161", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003161", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003161", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003161", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003161", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003161", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003161", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003161", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003161", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003161")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003162")
    void case_UTAPI_003162() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003162",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003162", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003162", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003162", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003162", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003162", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003162", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003162", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003162", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003162", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003162", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003162", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003162", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003162")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003163")
    void case_UTAPI_003163() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003163",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003163", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003163", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003163", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003163", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003163", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003163", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003163", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003163", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003163", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003163", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003163", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003163", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003163")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003164")
    void case_UTAPI_003164() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003164",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003164", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003164", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003164", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003164", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003164", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003164", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003164", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003164", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003164", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003164", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003164", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003164", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003164")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003165")
    void case_UTAPI_003165() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003165",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003165", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003165", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003165", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003165", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003165", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003165", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003165", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003165", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003165", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003165", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003165", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003165", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003165")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003166")
    void case_UTAPI_003166() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003166",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003166", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003166", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003166", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003166", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003166", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003166", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003166", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003166", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003166", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003166", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003166", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003166", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003166")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003167")
    void case_UTAPI_003167() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003167",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003167", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003167", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003167", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003167", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003167", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003167", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003167", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003167", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003167", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003167", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003167", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003167", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003167")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003168")
    void case_UTAPI_003168() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003168",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003168", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003168", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003168", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003168", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003168", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003168", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003168", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003168", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003168", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003168", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003168", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003168", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003168")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003169")
    void case_UTAPI_003169() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003169",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003169", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003169", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003169", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003169", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003169", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003169", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003169", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003169", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003169", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003169", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003169", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003169", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003169")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003170")
    void case_UTAPI_003170() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003170",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003170", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003170", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003170", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003170", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003170", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003170", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003170", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003170", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003170", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003170", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003170", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003170", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003170")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003171")
    void case_UTAPI_003171() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003171",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003171", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003171", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003171", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003171", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003171", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003171", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003171", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003171", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003171", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003171", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003171", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003171", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003171")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003172")
    void case_UTAPI_003172() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003172",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003172", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003172", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003172", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003172", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003172", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003172", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003172", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003172", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003172", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003172", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003172", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003172", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003172")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003173")
    void case_UTAPI_003173() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003173",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003173", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003173", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003173", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003173", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003173", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003173", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003173", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003173", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003173", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003173", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003173", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003173", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003173")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003174")
    void case_UTAPI_003174() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003174",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003174", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003174", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003174", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003174", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003174", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003174", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003174", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003174", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003174", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003174", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003174", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003174", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003174")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003175")
    void case_UTAPI_003175() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003175",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003175", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003175", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003175", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003175", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003175", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003175", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003175", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003175", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003175", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003175", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003175", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003175", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003175")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003176")
    void case_UTAPI_003176() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003176",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003176", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003176", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003176", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003176", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003176", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003176", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003176", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003176", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003176", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003176", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003176", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003176", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003176")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003177")
    void case_UTAPI_003177() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003177",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003177", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003177", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003177", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003177", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003177", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003177", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003177", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003177", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003177", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003177", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003177", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003177", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003177")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003178")
    void case_UTAPI_003178() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003178",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003178", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003178", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003178", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003178", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003178", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003178", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003178", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003178", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003178", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003178", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003178", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003178", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003178")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003179")
    void case_UTAPI_003179() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003179",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003179", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003179", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003179", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003179", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003179", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003179", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003179", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003179", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003179", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003179", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003179", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003179", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003179")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003180")
    void case_UTAPI_003180() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003180",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003180", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003180", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003180", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003180", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003180", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003180", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003180", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003180", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003180", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003180", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003180", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003180", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003180")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003181")
    void case_UTAPI_003181() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003181",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003181", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003181", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003181", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003181", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003181", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003181", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003181", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003181", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003181", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003181", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003181", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003181", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003181")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003182")
    void case_UTAPI_003182() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003182",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003182", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003182", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003182", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003182", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003182", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003182", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003182", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003182", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003182", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003182", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003182", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003182", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003182")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003183")
    void case_UTAPI_003183() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003183",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003183", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003183", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003183", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003183", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003183", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003183", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003183", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003183", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003183", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003183", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003183", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003183", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003183")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003184")
    void case_UTAPI_003184() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003184",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003184", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003184", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003184", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003184", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003184", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003184", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003184", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003184", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003184", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003184", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003184", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003184", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003184")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003185")
    void case_UTAPI_003185() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003185",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003185", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003185", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003185", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003185", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003185", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003185", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003185", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003185", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003185", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003185", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003185", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003185", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003185")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003186")
    void case_UTAPI_003186() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003186",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003186", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003186", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003186", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003186", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003186", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003186", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003186", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003186", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003186", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003186", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003186", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003186", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003186")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003187")
    void case_UTAPI_003187() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003187",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003187", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003187", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003187", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003187", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003187", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003187", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003187", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003187", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003187", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003187", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003187", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003187", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003187")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003188")
    void case_UTAPI_003188() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003188",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003188", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003188", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003188", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003188", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003188", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003188", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003188", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003188", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003188", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003188", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003188", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003188", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003188")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003189")
    void case_UTAPI_003189() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003189",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003189", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003189", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003189", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003189", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003189", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003189", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003189", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003189", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003189", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003189", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003189", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003189", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003189")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003190")
    void case_UTAPI_003190() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003190",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003190", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003190", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003190", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003190", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003190", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003190", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003190", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003190", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003190", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003190", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003190", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003190", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003190")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003191")
    void case_UTAPI_003191() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003191",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003191", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003191", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003191", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003191", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003191", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003191", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003191", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003191", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003191", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003191", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003191", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003191", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003191")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003192")
    void case_UTAPI_003192() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003192",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003192", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003192", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003192", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003192", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003192", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003192", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003192", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003192", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003192", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003192", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003192", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003192", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003192")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003193")
    void case_UTAPI_003193() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003193",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003193", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003193", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003193", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003193", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003193", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003193", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003193", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003193", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003193", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003193", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003193", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003193", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003193")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003194")
    void case_UTAPI_003194() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003194",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003194", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003194", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003194", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003194", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003194", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003194", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003194", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003194", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003194", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003194", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003194", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003194", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003194")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003195")
    void case_UTAPI_003195() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003195",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003195", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003195", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003195", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003195", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003195", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003195", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003195", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003195", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003195", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003195", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003195", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003195", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003195")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003196")
    void case_UTAPI_003196() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003196",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003196", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003196", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003196", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003196", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003196", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003196", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003196", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003196", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003196", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003196", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003196", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003196", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003196")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003197")
    void case_UTAPI_003197() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003197",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003197", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003197", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003197", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003197", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003197", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003197", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003197", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003197", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003197", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003197", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003197", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003197", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003197")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003198")
    void case_UTAPI_003198() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003198",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003198", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003198", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003198", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003198", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003198", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003198", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003198", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003198", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003198", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003198", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003198", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003198", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003198")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003199")
    void case_UTAPI_003199() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003199",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003199", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003199", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003199", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003199", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003199", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003199", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003199", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003199", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003199", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003199", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003199", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003199", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003199")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003200")
    void case_UTAPI_003200() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003200",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003200", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003200", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003200", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003200", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003200", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003200", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003200", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003200", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003200", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003200", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003200", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003200", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003200")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003201")
    void case_UTAPI_003201() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003201",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003201", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003201", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003201", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003201", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003201", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003201", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003201", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003201", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003201", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003201", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003201", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003201", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003201")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003202")
    void case_UTAPI_003202() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003202",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003202", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003202", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003202", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003202", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003202", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003202", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003202", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003202", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003202", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003202", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003202", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003202", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003202")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003203")
    void case_UTAPI_003203() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003203",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003203", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003203", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003203", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003203", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003203", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003203", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003203", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003203", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003203", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003203", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003203", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003203", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003203")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003204")
    void case_UTAPI_003204() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003204",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003204", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003204", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003204", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003204", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003204", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003204", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003204", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003204", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003204", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003204", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003204", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003204", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003204")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003205")
    void case_UTAPI_003205() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003205",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003205", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003205", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003205", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003205", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003205", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003205", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003205", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003205", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003205", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003205", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003205", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003205", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003205")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003206")
    void case_UTAPI_003206() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003206",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003206", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003206", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003206", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003206", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003206", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003206", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003206", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003206", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003206", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003206", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003206", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003206", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003206")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003207")
    void case_UTAPI_003207() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003207",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003207", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003207", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003207", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003207", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003207", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003207", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003207", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003207", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003207", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003207", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003207", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003207", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003207")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003208")
    void case_UTAPI_003208() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003208",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003208", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003208", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003208", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003208", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003208", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003208", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003208", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003208", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003208", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003208", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003208", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003208", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003208")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003209")
    void case_UTAPI_003209() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003209",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003209", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003209", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003209", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003209", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003209", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003209", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003209", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003209", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003209", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003209", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003209", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003209", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003209")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003210")
    void case_UTAPI_003210() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003210",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003210", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003210", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003210", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003210", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003210", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003210", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003210", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003210", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003210", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003210", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003210", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003210", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003210")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003211")
    void case_UTAPI_003211() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003211",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003211", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003211", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003211", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003211", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003211", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003211", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003211", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003211", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003211", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003211", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003211", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003211", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003211")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003212")
    void case_UTAPI_003212() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003212",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003212", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003212", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003212", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003212", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003212", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003212", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003212", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003212", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003212", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003212", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003212", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003212", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003212")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003213")
    void case_UTAPI_003213() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003213",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003213", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003213", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003213", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003213", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003213", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003213", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003213", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003213", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003213", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003213", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003213", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003213", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003213")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003214")
    void case_UTAPI_003214() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003214",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003214", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003214", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003214", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003214", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003214", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003214", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003214", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003214", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003214", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003214", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003214", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003214", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003214")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003215")
    void case_UTAPI_003215() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003215",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003215", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003215", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003215", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003215", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003215", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003215", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003215", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003215", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003215", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003215", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003215", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003215", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003215")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003216")
    void case_UTAPI_003216() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003216",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003216", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003216", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003216", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003216", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003216", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003216", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003216", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003216", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003216", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003216", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003216", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003216", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003216")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003217")
    void case_UTAPI_003217() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003217",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003217", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003217", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003217", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003217", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003217", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003217", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003217", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003217", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003217", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003217", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003217", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003217", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003217")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003218")
    void case_UTAPI_003218() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003218",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003218", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003218", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003218", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003218", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003218", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003218", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003218", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003218", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003218", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003218", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003218", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003218", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003218")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003219")
    void case_UTAPI_003219() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003219",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003219", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003219", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003219", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003219", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003219", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003219", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003219", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003219", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003219", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003219", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003219", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003219", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003219")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003220")
    void case_UTAPI_003220() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003220",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003220", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003220", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003220", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003220", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003220", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003220", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003220", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003220", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003220", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003220", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003220", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003220", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003220")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003221")
    void case_UTAPI_003221() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003221",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003221", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003221", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003221", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003221", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003221", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003221", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003221", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003221", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003221", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003221", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003221", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003221", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003221")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003222")
    void case_UTAPI_003222() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003222",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003222", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003222", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003222", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003222", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003222", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003222", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003222", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003222", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003222", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003222", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003222", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003222", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003222")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003223")
    void case_UTAPI_003223() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003223",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003223", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003223", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003223", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003223", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003223", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003223", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003223", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003223", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003223", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003223", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003223", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003223", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003223")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003224")
    void case_UTAPI_003224() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003224",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003224", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003224", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003224", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003224", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003224", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003224", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003224", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003224", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003224", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003224", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003224", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003224", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003224")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003225")
    void case_UTAPI_003225() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003225",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003225", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003225", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003225", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003225", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003225", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003225", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003225", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003225", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003225", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003225", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003225", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003225", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003225")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003226")
    void case_UTAPI_003226() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003226",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003226", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003226", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003226", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003226", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003226", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003226", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003226", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003226", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003226", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003226", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003226", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003226", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003226")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003227")
    void case_UTAPI_003227() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003227",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003227", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003227", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003227", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003227", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003227", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003227", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003227", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003227", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003227", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003227", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003227", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003227", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003227")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003228")
    void case_UTAPI_003228() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003228",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003228", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003228", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003228", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003228", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003228", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003228", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003228", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003228", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003228", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003228", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003228", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003228", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003228")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003229")
    void case_UTAPI_003229() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003229",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003229", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003229", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003229", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003229", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003229", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003229", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003229", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003229", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003229", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003229", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003229", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003229", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003229")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003230")
    void case_UTAPI_003230() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003230",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003230", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003230", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003230", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003230", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003230", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003230", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003230", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003230", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003230", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003230", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003230", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003230", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003230")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003231")
    void case_UTAPI_003231() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003231",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003231", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003231", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003231", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003231", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003231", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003231", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003231", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003231", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003231", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003231", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003231", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003231", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003231")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003232")
    void case_UTAPI_003232() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003232",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003232", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003232", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003232", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003232", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003232", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003232", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003232", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003232", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003232", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003232", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003232", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003232", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003232")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003233")
    void case_UTAPI_003233() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003233",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003233", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003233", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003233", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003233", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003233", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003233", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003233", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003233", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003233", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003233", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003233", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003233", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003233")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003234")
    void case_UTAPI_003234() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003234",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003234", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003234", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003234", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003234", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003234", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003234", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003234", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003234", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003234", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003234", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003234", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003234", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003234")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003235")
    void case_UTAPI_003235() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003235",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003235", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003235", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003235", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003235", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003235", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003235", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003235", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003235", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003235", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003235", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003235", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003235", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003235")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003236")
    void case_UTAPI_003236() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003236",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003236", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003236", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003236", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003236", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003236", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003236", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003236", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003236", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003236", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003236", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003236", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003236", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003236")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003237")
    void case_UTAPI_003237() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003237",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003237", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003237", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003237", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003237", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003237", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003237", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003237", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003237", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003237", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003237", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003237", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003237", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003237")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003238")
    void case_UTAPI_003238() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003238",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003238", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003238", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003238", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003238", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003238", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003238", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003238", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003238", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003238", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003238", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003238", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003238", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003238")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003239")
    void case_UTAPI_003239() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003239",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003239", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003239", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003239", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003239", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003239", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003239", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003239", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003239", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003239", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003239", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003239", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003239", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003239")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003240")
    void case_UTAPI_003240() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003240",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003240", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003240", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003240", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003240", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003240", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003240", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003240", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003240", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003240", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003240", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003240", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003240", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003240")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003241")
    void case_UTAPI_003241() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003241",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003241", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003241", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003241", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003241", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003241", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003241", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003241", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003241", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003241", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003241", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003241", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003241", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003241")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003242")
    void case_UTAPI_003242() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003242",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003242", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003242", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003242", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003242", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003242", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003242", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003242", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003242", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003242", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003242", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003242", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003242", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003242")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003243")
    void case_UTAPI_003243() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003243",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003243", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003243", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003243", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003243", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003243", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003243", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003243", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003243", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003243", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003243", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003243", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003243", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003243")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003244")
    void case_UTAPI_003244() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003244",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003244", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003244", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003244", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003244", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003244", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003244", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003244", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003244", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003244", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003244", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003244", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003244", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003244")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003245")
    void case_UTAPI_003245() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003245",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003245", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003245", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003245", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003245", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003245", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003245", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003245", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003245", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003245", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003245", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003245", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003245", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003245")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003246")
    void case_UTAPI_003246() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003246",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003246", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003246", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003246", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003246", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003246", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003246", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003246", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003246", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003246", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003246", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003246", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003246", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003246")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003247")
    void case_UTAPI_003247() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003247",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003247", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003247", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003247", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003247", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003247", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003247", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003247", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003247", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003247", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003247", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003247", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003247", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003247")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003248")
    void case_UTAPI_003248() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003248",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003248", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003248", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003248", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003248", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003248", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003248", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003248", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003248", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003248", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003248", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003248", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003248", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003248")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003249")
    void case_UTAPI_003249() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003249",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003249", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003249", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003249", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003249", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003249", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003249", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003249", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003249", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003249", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003249", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003249", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003249", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003249")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003250")
    void case_UTAPI_003250() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003250",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003250", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003250", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003250", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003250", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003250", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003250", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003250", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003250", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003250", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003250", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003250", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003250", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003250")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003251")
    void case_UTAPI_003251() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003251",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003251", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003251", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003251", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003251", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003251", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003251", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003251", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003251", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003251", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003251", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003251", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003251", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003251")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003252")
    void case_UTAPI_003252() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003252",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003252", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003252", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003252", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003252", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003252", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003252", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003252", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003252", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003252", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003252", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003252", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003252", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003252")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003253")
    void case_UTAPI_003253() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003253",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003253", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003253", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003253", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003253", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003253", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003253", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003253", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003253", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003253", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003253", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003253", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003253", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003253")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003254")
    void case_UTAPI_003254() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003254",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003254", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003254", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003254", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003254", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003254", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003254", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003254", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003254", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003254", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003254", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003254", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003254", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003254")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003255")
    void case_UTAPI_003255() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003255",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003255", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003255", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003255", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003255", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003255", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003255", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003255", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003255", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003255", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003255", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003255", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003255", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003255")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003256")
    void case_UTAPI_003256() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003256",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003256", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003256", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003256", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003256", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003256", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003256", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003256", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003256", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003256", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003256", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003256", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003256", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003256")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003257")
    void case_UTAPI_003257() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003257",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003257", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003257", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003257", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003257", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003257", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003257", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003257", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003257", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003257", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003257", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003257", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003257", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003257")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003258")
    void case_UTAPI_003258() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003258",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003258", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003258", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003258", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003258", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003258", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003258", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003258", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003258", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003258", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003258", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003258", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003258", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003258")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003259")
    void case_UTAPI_003259() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003259",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003259", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003259", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003259", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003259", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003259", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003259", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003259", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003259", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003259", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003259", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003259", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003259", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003259")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003260")
    void case_UTAPI_003260() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003260",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003260", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003260", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003260", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003260", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003260", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003260", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003260", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003260", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003260", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003260", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003260", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003260", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003260")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003261")
    void case_UTAPI_003261() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003261",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003261", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003261", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003261", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003261", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003261", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003261", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003261", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003261", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003261", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003261", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003261", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003261", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003261")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003262")
    void case_UTAPI_003262() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003262",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003262", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003262", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003262", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003262", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003262", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003262", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003262", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003262", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003262", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003262", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003262", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003262", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003262")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003263")
    void case_UTAPI_003263() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003263",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003263", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003263", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003263", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003263", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003263", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003263", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003263", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003263", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003263", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003263", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003263", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003263", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003263")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003264")
    void case_UTAPI_003264() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003264",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003264", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003264", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003264", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003264", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003264", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003264", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003264", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003264", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003264", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003264", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003264", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003264", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003264")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003265")
    void case_UTAPI_003265() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003265",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003265", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003265", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003265", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003265", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003265", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003265", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003265", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003265", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003265", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003265", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003265", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003265", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003265")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003266")
    void case_UTAPI_003266() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003266",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003266", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003266", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003266", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003266", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003266", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003266", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003266", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003266", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003266", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003266", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003266", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003266", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003266")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003267")
    void case_UTAPI_003267() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003267",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003267", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003267", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003267", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003267", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003267", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003267", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003267", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003267", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003267", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003267", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003267", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003267", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003267")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003268")
    void case_UTAPI_003268() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003268",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003268", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003268", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003268", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003268", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003268", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003268", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003268", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003268", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003268", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003268", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003268", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003268", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003268")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003269")
    void case_UTAPI_003269() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003269",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003269", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003269", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003269", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003269", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003269", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003269", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003269", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003269", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003269", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003269", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003269", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003269", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003269")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003270")
    void case_UTAPI_003270() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003270",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003270", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003270", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003270", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003270", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003270", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003270", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003270", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003270", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003270", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003270", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003270", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003270", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003270")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003271")
    void case_UTAPI_003271() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003271",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003271", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003271", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003271", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003271", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003271", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003271", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003271", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003271", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003271", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003271", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003271", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003271", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003271")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003272")
    void case_UTAPI_003272() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003272",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003272", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003272", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003272", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003272", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003272", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003272", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003272", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003272", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003272", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003272", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003272", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003272", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003272")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003273")
    void case_UTAPI_003273() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003273",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003273", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003273", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003273", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003273", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003273", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003273", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003273", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003273", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003273", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003273", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003273", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003273", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003273")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003274")
    void case_UTAPI_003274() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003274",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003274", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003274", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003274", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003274", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003274", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003274", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003274", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003274", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003274", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003274", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003274", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003274", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003274")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003275")
    void case_UTAPI_003275() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003275",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003275", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003275", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003275", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003275", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003275", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003275", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003275", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003275", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003275", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003275", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003275", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003275", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003275")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003276")
    void case_UTAPI_003276() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003276",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003276", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003276", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003276", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003276", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003276", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003276", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003276", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003276", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003276", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003276", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003276", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003276", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003276")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003277")
    void case_UTAPI_003277() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003277",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003277", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003277", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003277", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003277", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003277", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003277", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003277", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003277", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003277", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003277", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003277", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003277", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003277")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003278")
    void case_UTAPI_003278() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003278",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003278", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003278", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003278", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003278", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003278", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003278", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003278", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003278", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003278", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003278", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003278", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003278", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003278")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003279")
    void case_UTAPI_003279() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003279",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003279", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003279", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003279", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003279", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003279", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003279", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003279", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003279", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003279", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003279", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003279", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003279", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003279")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003280")
    void case_UTAPI_003280() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003280",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003280", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003280", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003280", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003280", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003280", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003280", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003280", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003280", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003280", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003280", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003280", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003280", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003280")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003281")
    void case_UTAPI_003281() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003281",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003281", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003281", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003281", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003281", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003281", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003281", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003281", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003281", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003281", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003281", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003281", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003281", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003281")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003282")
    void case_UTAPI_003282() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003282",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003282", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003282", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003282", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003282", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003282", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003282", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003282", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003282", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003282", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003282", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003282", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003282", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003282")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003283")
    void case_UTAPI_003283() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003283",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003283", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003283", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003283", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003283", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003283", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003283", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003283", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003283", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003283", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003283", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003283", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003283", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003283")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003284")
    void case_UTAPI_003284() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003284",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003284", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003284", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003284", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003284", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003284", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003284", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003284", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003284", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003284", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003284", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003284", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003284", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003284")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003285")
    void case_UTAPI_003285() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003285",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003285", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003285", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003285", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003285", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003285", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003285", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003285", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003285", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003285", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003285", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003285", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003285", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003285")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003286")
    void case_UTAPI_003286() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003286",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003286", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003286", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003286", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003286", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003286", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003286", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003286", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003286", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003286", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003286", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003286", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003286", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003286")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003287")
    void case_UTAPI_003287() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003287",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003287", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003287", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003287", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003287", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003287", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003287", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003287", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003287", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003287", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003287", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003287", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003287", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003287")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003288")
    void case_UTAPI_003288() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003288",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003288", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003288", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003288", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003288", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003288", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003288", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003288", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003288", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003288", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003288", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003288", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003288", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003288")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003289")
    void case_UTAPI_003289() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003289",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003289", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003289", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003289", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003289", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003289", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003289", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003289", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003289", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003289", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003289", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003289", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003289", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003289")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003290")
    void case_UTAPI_003290() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003290",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003290", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003290", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003290", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003290", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003290", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003290", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003290", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003290", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003290", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003290", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003290", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003290", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003290")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003291")
    void case_UTAPI_003291() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003291",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003291", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003291", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003291", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003291", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003291", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003291", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003291", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003291", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003291", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003291", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003291", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003291", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003291")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003292")
    void case_UTAPI_003292() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003292",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003292", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003292", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003292", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003292", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003292", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003292", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003292", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003292", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003292", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003292", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003292", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003292", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003292")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003293")
    void case_UTAPI_003293() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003293",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003293", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003293", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003293", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003293", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003293", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003293", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003293", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003293", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003293", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003293", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003293", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003293", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003293")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003294")
    void case_UTAPI_003294() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003294",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003294", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003294", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003294", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003294", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003294", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003294", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003294", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003294", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003294", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003294", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003294", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003294", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003294")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003295")
    void case_UTAPI_003295() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003295",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003295", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003295", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003295", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003295", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003295", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003295", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003295", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003295", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003295", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003295", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003295", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003295", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003295")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003296")
    void case_UTAPI_003296() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003296",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003296", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003296", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003296", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003296", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003296", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003296", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003296", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003296", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003296", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003296", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003296", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003296", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003296")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003297")
    void case_UTAPI_003297() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003297",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003297", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003297", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003297", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003297", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003297", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003297", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003297", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003297", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003297", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003297", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003297", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003297", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003297")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003298")
    void case_UTAPI_003298() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003298",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003298", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003298", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003298", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003298", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003298", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003298", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003298", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003298", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003298", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003298", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003298", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003298", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003298")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003299")
    void case_UTAPI_003299() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003299",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003299", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003299", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003299", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003299", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003299", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003299", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003299", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003299", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003299", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003299", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003299", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003299", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003299")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003300")
    void case_UTAPI_003300() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003300",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003300", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003300", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003300", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003300", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003300", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003300", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003300", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003300", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003300", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003300", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003300", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003300", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003300")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003301")
    void case_UTAPI_003301() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003301",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003301", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003301", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003301", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003301", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003301", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003301", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003301", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003301", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003301", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003301", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003301", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003301", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003301")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003302")
    void case_UTAPI_003302() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003302",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003302", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003302", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003302", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003302", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003302", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003302", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003302", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003302", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003302", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003302", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003302", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003302", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003302")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003303")
    void case_UTAPI_003303() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003303",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003303", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003303", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003303", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003303", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003303", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003303", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003303", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003303", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003303", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003303", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003303", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003303", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003303")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003304")
    void case_UTAPI_003304() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003304",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003304", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003304", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003304", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003304", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003304", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003304", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003304", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003304", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003304", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003304", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003304", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003304", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003304")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003305")
    void case_UTAPI_003305() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003305",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003305", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003305", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003305", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003305", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003305", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003305", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003305", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003305", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003305", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003305", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003305", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003305", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003305")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003306")
    void case_UTAPI_003306() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003306",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003306", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003306", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003306", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003306", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003306", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003306", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003306", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003306", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003306", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003306", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003306", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003306", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003306")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003307")
    void case_UTAPI_003307() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003307",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003307", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003307", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003307", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003307", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003307", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003307", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003307", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003307", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003307", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003307", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003307", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003307", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003307")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003308")
    void case_UTAPI_003308() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003308",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003308", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003308", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003308", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003308", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003308", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003308", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003308", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003308", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003308", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003308", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003308", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003308", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003308")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003309")
    void case_UTAPI_003309() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003309",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003309", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003309", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003309", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003309", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003309", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003309", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003309", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003309", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003309", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003309", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003309", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003309", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003309")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

}

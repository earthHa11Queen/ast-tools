package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.SqlResponseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for SqlResponse#summaryFromEntity.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class SqlResponseSummaryFromEntityScenario {

    @Test
    @DisplayName("UTAPI-010482")
    void case_UTAPI_010482() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010482",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010482", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010482", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010482", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010482", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010482", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010482", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010482", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010482")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "1:length_null", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose contentSql", "getContentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010483")
    void case_UTAPI_010483() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010483",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010483", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010483", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010483", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010483", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010483", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010483", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010483", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010483")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "2:length_empty", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose contentSql", "getContentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010484")
    void case_UTAPI_010484() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010484",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010484", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010484", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010484", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010484", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010484", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010484", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010484", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010484")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "3:length_min", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose contentSql", "getContentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010485")
    void case_UTAPI_010485() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010485",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010485", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010485", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010485", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010485", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010485", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010485", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010485", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010485")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose contentSql", "getContentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010486")
    void case_UTAPI_010486() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010486",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010486", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010486", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010486", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010486", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010486", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010486", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010486", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010486")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "5:length_max", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose contentSql", "getContentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010487")
    void case_UTAPI_010487() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010487",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010487", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010487", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010487", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010487", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010487", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010487", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010487", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010487")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose contentSql", "getContentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010488")
    void case_UTAPI_010488() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010488",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010488", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010488", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010488", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010488", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010488", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010488", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010488", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010488")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose contentSql", "getContentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010489")
    void case_UTAPI_010489() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010489",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010489", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010489", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010489", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010489", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010489", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010489", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010489", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010489")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::contentSql")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose contentSql", "getContentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010490")
    void case_UTAPI_010490() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010490",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010490", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010490", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010490", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010490", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010490", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010490", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010490", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010490")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::contentSql")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose contentSql", "getContentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010491")
    void case_UTAPI_010491() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010491",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010491", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010491", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010491", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010491", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010491", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010491", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010491", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010491")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::contentSql")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose contentSql", "getContentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010492")
    void case_UTAPI_010492() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010492",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010492", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010492", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010492", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010492", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010492", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010492", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010492", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010492")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose contentSql", "getContentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010493")
    void case_UTAPI_010493() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010493",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010493", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010493", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010493", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010493", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010493", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010493", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010493", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010493")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose contentSql", "getContentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010494")
    void case_UTAPI_010494() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010494",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010494", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010494", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010494", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010494", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010494", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010494", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010494", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010494")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "56:space")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose contentSql", "getContentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010495")
    void case_UTAPI_010495() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010495",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010495", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010495", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010495", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010495", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010495", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010495", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010495", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010495")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose contentSql", "getContentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010496")
    void case_UTAPI_010496() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010496",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010496", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010496", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010496", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010496", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010496", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010496", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010496", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010496")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose contentSql", "getContentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010497")
    void case_UTAPI_010497() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010497",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010497", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010497", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010497", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010497", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010497", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010497", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010497", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010497")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "59:tab")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose contentSql", "getContentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010498")
    void case_UTAPI_010498() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010498",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010498", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010498", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010498", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010498", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010498", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010498", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010498", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010498")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "60:control_character_null")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose contentSql", "getContentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010499")
    void case_UTAPI_010499() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010499",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010499", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010499", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010499", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010499", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010499", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010499", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010499", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010499")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose contentSql", "getContentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010500")
    void case_UTAPI_010500() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010500",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010500", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010500", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010500", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010500", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010500", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010500", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010500", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010500")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose contentSql", "getContentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010501")
    void case_UTAPI_010501() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010501",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010501", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010501", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010501", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010501", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010501", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010501", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010501", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010501")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose contentSql", "getContentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010502")
    void case_UTAPI_010502() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010502",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010502", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010502", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010502", "sql.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010502", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010502", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010502", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010502", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010502")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("sql.createdTimestamp", "SavedSql.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010503")
    void case_UTAPI_010503() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010503",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010503", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010503", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010503", "sql.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010503", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010503", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010503", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010503", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010503")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("sql.createdTimestamp", "SavedSql.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010504")
    void case_UTAPI_010504() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010504",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010504", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010504", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010504", "sql.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010504", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010504", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010504", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010504", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010504")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("sql.createdTimestamp", "SavedSql.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010505")
    void case_UTAPI_010505() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010505",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010505", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010505", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010505", "sql.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010505", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010505", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010505", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010505", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010505")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("sql.createdTimestamp", "SavedSql.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010506")
    void case_UTAPI_010506() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010506",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010506", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010506", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010506", "sql.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010506", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010506", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010506", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010506", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010506")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("sql.createdTimestamp", "SavedSql.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010507")
    void case_UTAPI_010507() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010507",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010507", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010507", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010507", "sql.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010507", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010507", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010507", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010507", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010507")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("sql.createdTimestamp", "SavedSql.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010508")
    void case_UTAPI_010508() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010508",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010508", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010508", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010508", "sql.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010508", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010508", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010508", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010508", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010508")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("sql.createdTimestamp", "SavedSql.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010509")
    void case_UTAPI_010509() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010509",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010509", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010509", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010509", "sql.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010509", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010509", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010509", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010509", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010509")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("sql.createdTimestamp", "SavedSql.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010510")
    void case_UTAPI_010510() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010510",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010510", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010510", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010510", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010510", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010510", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010510", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010510", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010510")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.dbConnectionId survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010511")
    void case_UTAPI_010511() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010511",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010511", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010511", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010511", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010511", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010511", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010511", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010511", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010511")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.dbConnectionId survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010512")
    void case_UTAPI_010512() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010512",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010512", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010512", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010512", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010512", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010512", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010512", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010512", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010512")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.dbConnectionId survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010513")
    void case_UTAPI_010513() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010513",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010513", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010513", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010513", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010513", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010513", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010513", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010513", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010513")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.dbConnectionId survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010514")
    void case_UTAPI_010514() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010514",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010514", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010514", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010514", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010514", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010514", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010514", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010514", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010514")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.dbConnectionId survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010515")
    void case_UTAPI_010515() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010515",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010515", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010515", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010515", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010515", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010515", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010515", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010515", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010515")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.dbConnectionId survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010516")
    void case_UTAPI_010516() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010516",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010516", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010516", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010516", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010516", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010516", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010516", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010516", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010516")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.dbConnectionId survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010517")
    void case_UTAPI_010517() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010517",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010517", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010517", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010517", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010517", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010517", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010517", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010517", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010517")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.dbConnectionId survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010518")
    void case_UTAPI_010518() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010518",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010518", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010518", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010518", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010518", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010518", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010518", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010518", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010518")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.dbConnectionId survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010519")
    void case_UTAPI_010519() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010519",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010519", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010519", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010519", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010519", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010519", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010519", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010519", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010519")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.dbConnectionId survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010520")
    void case_UTAPI_010520() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010520",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010520", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010520", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010520", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010520", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010520", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010520", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010520", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010520")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.dbConnectionId survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010521")
    void case_UTAPI_010521() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010521",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010521", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010521", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010521", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010521", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010521", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010521", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010521", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010521")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::n")
                    .mirror("-", "1:length_null", "-")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010522")
    void case_UTAPI_010522() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010522",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010522", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010522", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010522", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010522", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010522", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010522", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010522", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010522")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010523")
    void case_UTAPI_010523() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010523",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010523", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010523", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010523", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010523", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010523", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010523", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010523", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010523")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::n")
                    .mirror("-", "3:length_min", "-")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010524")
    void case_UTAPI_010524() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010524",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010524", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010524", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010524", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010524", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010524", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010524", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010524", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010524")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010525")
    void case_UTAPI_010525() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010525",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010525", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010525", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010525", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010525", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010525", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010525", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010525", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010525")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::n")
                    .mirror("-", "5:length_max", "-")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010526")
    void case_UTAPI_010526() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010526",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010526", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010526", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010526", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010526", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010526", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010526", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010526", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010526")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010527")
    void case_UTAPI_010527() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010527",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010527", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010527", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010527", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010527", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010527", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010527", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010527", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010527")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010528")
    void case_UTAPI_010528() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010528",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010528", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010528", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010528", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010528", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010528", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010528", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010528", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010528")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010529")
    void case_UTAPI_010529() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010529",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010529", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010529", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010529", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010529", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010529", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010529", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010529", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010529")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010530")
    void case_UTAPI_010530() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010530",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010530", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010530", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010530", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010530", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010530", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010530", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010530", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010530")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010531")
    void case_UTAPI_010531() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010531",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010531", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010531", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010531", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010531", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010531", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010531", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010531", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010531")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010532")
    void case_UTAPI_010532() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010532",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010532", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010532", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010532", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010532", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010532", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010532", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010532", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010532")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "1:length_null", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010533")
    void case_UTAPI_010533() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010533",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010533", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010533", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010533", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010533", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010533", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010533", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010533", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010533")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "2:length_empty", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010534")
    void case_UTAPI_010534() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010534",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010534", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010534", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010534", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010534", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010534", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010534", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010534", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010534")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "3:length_min", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010535")
    void case_UTAPI_010535() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010535",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010535", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010535", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010535", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010535", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010535", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010535", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010535", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010535")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010536")
    void case_UTAPI_010536() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010536",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010536", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010536", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010536", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010536", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010536", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010536", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010536", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010536")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "5:length_max", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010537")
    void case_UTAPI_010537() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010537",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010537", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010537", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010537", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010537", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010537", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010537", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010537", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010537")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010538")
    void case_UTAPI_010538() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010538",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010538", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010538", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010538", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010538", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010538", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010538", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010538", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010538")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010539")
    void case_UTAPI_010539() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010539",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010539", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010539", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010539", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010539", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010539", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010539", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010539", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010539")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::titleSql")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010540")
    void case_UTAPI_010540() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010540",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010540", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010540", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010540", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010540", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010540", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010540", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010540", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010540")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::titleSql")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010541")
    void case_UTAPI_010541() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010541",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010541", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010541", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010541", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010541", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010541", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010541", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010541", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010541")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::titleSql")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010542")
    void case_UTAPI_010542() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010542",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010542", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010542", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010542", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010542", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010542", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010542", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010542", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010542")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::titleSql")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010543")
    void case_UTAPI_010543() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010543",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010543", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010543", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010543", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010543", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010543", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010543", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010543", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010543")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010544")
    void case_UTAPI_010544() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010544",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010544", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010544", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010544", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010544", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010544", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010544", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010544", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010544")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010545")
    void case_UTAPI_010545() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010545",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010545", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010545", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010545", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010545", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010545", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010545", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010545", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010545")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "56:space")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010546")
    void case_UTAPI_010546() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010546",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010546", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010546", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010546", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010546", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010546", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010546", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010546", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010546")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010547")
    void case_UTAPI_010547() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010547",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010547", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010547", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010547", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010547", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010547", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010547", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010547", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010547")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010548")
    void case_UTAPI_010548() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010548",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010548", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010548", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010548", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010548", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010548", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010548", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010548", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010548")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "59:tab")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010549")
    void case_UTAPI_010549() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010549",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010549", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010549", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010549", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010549", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010549", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010549", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010549", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010549")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "60:control_character_null")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010550")
    void case_UTAPI_010550() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010550",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010550", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010550", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010550", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010550", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010550", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010550", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010550", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010550")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010551")
    void case_UTAPI_010551() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010551",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010551", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010551", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010551", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010551", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010551", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010551", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010551", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010551")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010552")
    void case_UTAPI_010552() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010552",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010552", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010552", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010552", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010552", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010552", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010552", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010552", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010552")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010553")
    void case_UTAPI_010553() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010553",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010553", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010553", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010553", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010553", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010553", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010553", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010553", "sql.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010553")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("sql.updatedTimestamp", "SavedSql.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.updatedTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose updatedTimestamp", "getUpdatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010554")
    void case_UTAPI_010554() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010554",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010554", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010554", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010554", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010554", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010554", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010554", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010554", "sql.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010554")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("sql.updatedTimestamp", "SavedSql.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.updatedTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose updatedTimestamp", "getUpdatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010555")
    void case_UTAPI_010555() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010555",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010555", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010555", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010555", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010555", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010555", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010555", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010555", "sql.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010555")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("sql.updatedTimestamp", "SavedSql.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.updatedTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose updatedTimestamp", "getUpdatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010556")
    void case_UTAPI_010556() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010556",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010556", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010556", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010556", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010556", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010556", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010556", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010556", "sql.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010556")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("sql.updatedTimestamp", "SavedSql.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.updatedTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose updatedTimestamp", "getUpdatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010557")
    void case_UTAPI_010557() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010557",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010557", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010557", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010557", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010557", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010557", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010557", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010557", "sql.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010557")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("sql.updatedTimestamp", "SavedSql.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.updatedTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose updatedTimestamp", "getUpdatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010558")
    void case_UTAPI_010558() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010558",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010558", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010558", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010558", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010558", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010558", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010558", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010558", "sql.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010558")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("sql.updatedTimestamp", "SavedSql.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.updatedTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose updatedTimestamp", "getUpdatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010559")
    void case_UTAPI_010559() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010559",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010559", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010559", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010559", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010559", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010559", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010559", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010559", "sql.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010559")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("sql.updatedTimestamp", "SavedSql.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.updatedTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose updatedTimestamp", "getUpdatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010560")
    void case_UTAPI_010560() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010560",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "summaryFromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010560", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010560", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010560", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010560", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010560", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010560", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010560", "sql.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010560")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::summaryFromEntity::2::FIELD::1::SavedSql::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("sql.updatedTimestamp", "SavedSql.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.summaryFromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.updatedTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_NULL, "getContent must not be populated by this list oriented mapping", "getContent")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose updatedTimestamp", "getUpdatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

}

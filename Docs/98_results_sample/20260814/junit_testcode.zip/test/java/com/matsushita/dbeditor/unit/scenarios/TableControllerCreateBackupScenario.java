package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableController#createBackup.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableControllerCreateBackupScenario {

    @Test
    @DisplayName("UTAPI-001264")
    void case_UTAPI_001264() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001264",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001264", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001264", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001264", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001264", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001264")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::ARG::1::-::name")
                    .mirror("-", "1:length_null", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001265")
    void case_UTAPI_001265() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001265",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001265", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001265", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001265", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001265", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001265")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::ARG::1::-::name")
                    .mirror("-", "2:length_empty", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001266")
    void case_UTAPI_001266() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001266",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001266", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001266", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001266", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001266", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001266")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::ARG::1::-::name")
                    .mirror("-", "3:length_min", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001267")
    void case_UTAPI_001267() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001267",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001267", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001267", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001267", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001267", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001267")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::ARG::1::-::name")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001268")
    void case_UTAPI_001268() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001268",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001268", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001268", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001268", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001268", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001268")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::ARG::1::-::name")
                    .mirror("-", "5:length_max", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001269")
    void case_UTAPI_001269() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001269",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001269", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001269", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001269", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001269", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001269")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::ARG::1::-::name")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001270")
    void case_UTAPI_001270() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001270",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001270", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001270", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001270", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001270", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001270")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::ARG::1::-::name")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001271")
    void case_UTAPI_001271() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001271",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001271", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001271", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001271", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001271", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001271")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::ARG::1::-::name")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001272")
    void case_UTAPI_001272() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001272",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001272", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001272", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001272", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001272", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001272")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::ARG::1::-::name")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001273")
    void case_UTAPI_001273() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001273",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001273", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001273", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001273", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001273", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001273")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::ARG::1::-::name")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001274")
    void case_UTAPI_001274() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001274",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001274", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001274", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001274", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001274", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001274")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::ARG::1::-::name")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001275")
    void case_UTAPI_001275() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001275",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001275", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001275", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001275", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001275", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001275")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::ARG::1::-::name")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001276")
    void case_UTAPI_001276() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001276",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001276", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001276", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001276", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001276", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001276")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::ARG::1::-::name")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001277")
    void case_UTAPI_001277() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001277",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001277", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001277", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001277", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001277", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001277")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::ARG::1::-::name")
                    .mirror("-", "-", "56:space")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001278")
    void case_UTAPI_001278() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001278",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001278", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001278", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001278", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001278", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001278")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::ARG::1::-::name")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001279")
    void case_UTAPI_001279() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001279",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001279", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001279", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001279", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001279", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001279")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::ARG::1::-::name")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001280")
    void case_UTAPI_001280() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001280",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001280", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001280", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001280", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001280", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001280")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::ARG::1::-::name")
                    .mirror("-", "-", "59:tab")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001281")
    void case_UTAPI_001281() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001281",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001281", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001281", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001281", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001281", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001281")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::ARG::1::-::name")
                    .mirror("-", "-", "60:control_character_null")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001282")
    void case_UTAPI_001282() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001282",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001282", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001282", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001282", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001282", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001282")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::ARG::1::-::name")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001283")
    void case_UTAPI_001283() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001283",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001283", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001283", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001283", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001283", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001283")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::ARG::1::-::name")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001284")
    void case_UTAPI_001284() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001284",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001284", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001284", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001284", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001284", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001284")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::ARG::1::-::name")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001285")
    void case_UTAPI_001285() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001285",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001285", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001285", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001285", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001285", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001285")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConflictCheckRequest.connectionId classifies this input condition", "ConflictCheckRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001286")
    void case_UTAPI_001286() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001286",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001286", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001286", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001286", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001286", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001286")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConflictCheckRequest.connectionId classifies this input condition", "ConflictCheckRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001287")
    void case_UTAPI_001287() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001287",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001287", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001287", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001287", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001287", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001287")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConflictCheckRequest.connectionId classifies this input condition", "ConflictCheckRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001288")
    void case_UTAPI_001288() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001288",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001288", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001288", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001288", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001288", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001288")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConflictCheckRequest.connectionId classifies this input condition", "ConflictCheckRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001289")
    void case_UTAPI_001289() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001289",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001289", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001289", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001289", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001289", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001289")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConflictCheckRequest.connectionId classifies this input condition", "ConflictCheckRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001290")
    void case_UTAPI_001290() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001290",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001290", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001290", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001290", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001290", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001290")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConflictCheckRequest.connectionId classifies this input condition", "ConflictCheckRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001291")
    void case_UTAPI_001291() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001291",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001291", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001291", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001291", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001291", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001291")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001292")
    void case_UTAPI_001292() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001292",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001292", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001292", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001292", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001292", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001292")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001293")
    void case_UTAPI_001293() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001293",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001293", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001293", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001293", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001293", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001293")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001294")
    void case_UTAPI_001294() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001294",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001294", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001294", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001294", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001294", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001294")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001295")
    void case_UTAPI_001295() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001295",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001295", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001295", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001295", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001295", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001295")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001296")
    void case_UTAPI_001296() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001296",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001296", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001296", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001296", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001296", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001296")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001297")
    void case_UTAPI_001297() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001297",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001297", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001297", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001297", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001297", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001297")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001298")
    void case_UTAPI_001298() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001298",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001298", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001298", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001298", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001298", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001298")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001299")
    void case_UTAPI_001299() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001299",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001299", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001299", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001299", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001299", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001299")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001300")
    void case_UTAPI_001300() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001300",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001300", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001300", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001300", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001300", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001300")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001301")
    void case_UTAPI_001301() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001301",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001301", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001301", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001301", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001301", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001301")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001302")
    void case_UTAPI_001302() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001302",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001302", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001302", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001302", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001302", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001302")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001303")
    void case_UTAPI_001303() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001303",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001303", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001303", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001303", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001303", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001303")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001304")
    void case_UTAPI_001304() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001304",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001304", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001304", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001304", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001304", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001304")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001305")
    void case_UTAPI_001305() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001305",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001305", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001305", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001305", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001305", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001305")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001306")
    void case_UTAPI_001306() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001306",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001306", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001306", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001306", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001306", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001306")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001307")
    void case_UTAPI_001307() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001307",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001307", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001307", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001307", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001307", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001307")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001308")
    void case_UTAPI_001308() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001308",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001308", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001308", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001308", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001308", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001308")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001309")
    void case_UTAPI_001309() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001309",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001309", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001309", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001309", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001309", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001309")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001310")
    void case_UTAPI_001310() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001310",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001310", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001310", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001310", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001310", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001310")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001311")
    void case_UTAPI_001311() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001311",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001311", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001311", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001311", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001311", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001311")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001312")
    void case_UTAPI_001312() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001312",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001312", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001312", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001312", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001312", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001312")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001313")
    void case_UTAPI_001313() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001313",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001313", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001313", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001313", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001313", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001313")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001314")
    void case_UTAPI_001314() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001314",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001314", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001314", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001314", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001314", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001314")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001315")
    void case_UTAPI_001315() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001315",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createBackup",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001315", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001315", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001315", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001315", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001315")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createBackup::10::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.createBackup")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.createBackup", "conflictUseCase", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.createBackup must carry the value generated for request.connectionId", "conflictUseCase", "createBackup", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.createBackup must carry the value generated for request.schemaName", "conflictUseCase", "createBackup", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.createBackup must carry the value generated for name", "conflictUseCase", "createBackup", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

}

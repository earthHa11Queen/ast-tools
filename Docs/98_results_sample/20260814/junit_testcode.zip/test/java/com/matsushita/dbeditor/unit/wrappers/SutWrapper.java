package com.matsushita.dbeditor.unit.wrappers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.mockito.invocation.Invocation;

import com.matsushita.dbeditor.fixtures.SentinelRegistry;
import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.Interaction;
import com.matsushita.dbeditor.utils.ProjectTypes;
import com.matsushita.dbeditor.utils.SutSupport;
import com.matsushita.dbeditor.utils.TypeSupport;

/**
 * Boundary between a Scenario and one SUT class.
 *
 * <p>The Wrapper hides SUT construction and dependency injection, exposes exactly the
 * operations the generated scenarios need, and never swallows an exception the Oracle has
 * to observe.</p>
 */
public abstract class SutWrapper {

    private final String sutClassName;
    private final String implClassName;
    private final String[] depNames;
    private final String[] depTypes;
    private final boolean staticOnly;

    private final Map<String, Object> mocks = new LinkedHashMap<String, Object>();
    private final Map<String, String> mockTypes = new LinkedHashMap<String, String>();
    private final SentinelRegistry registry = new SentinelRegistry();
    private final List<Interaction> staticInteractions = new ArrayList<Interaction>();
    private final List<AutoCloseable> closeables = new ArrayList<AutoCloseable>();

    protected Object sut;

    protected SutWrapper(String sutClassName, String implClassName, String[] depNames, String[] depTypes,
            boolean staticOnly) {
        this.sutClassName = sutClassName;
        this.implClassName = implClassName;
        this.depNames = depNames;
        this.depTypes = depTypes;
        this.staticOnly = staticOnly;
        for (int i = 0; i < depNames.length; i++) {
            this.mockTypes.put(depNames[i], TypeSupport.raw(depTypes[i]));
        }
    }

    public final String sutClassName() {
        return sutClassName;
    }

    public final SentinelRegistry registry() {
        return registry;
    }

    public void setUp() {
        if (!staticOnly) {
            this.sut = SutSupport.newSut(implClassName, depNames, depTypes, registry, mocks);
        }
        openStatics();
    }

    /** Overridden when the declared contract of the SUT is observed through a static API. */
    protected void openStatics() {
    }

    protected final void registerCloseable(AutoCloseable closeable) {
        closeables.add(closeable);
    }

    protected final void recordStatic(String owner, String method, Object[] args) {
        staticInteractions.add(new Interaction(owner, method, args));
    }

    public final Object mock(String field) {
        return mocks.get(field);
    }

    public final Object sentinelOf(String mockField, String methodName) {
        String type = mockTypes.get(mockField);
        if (type == null) {
            type = mockField;
        }
        String key = type + "#" + methodName;
        if (registry.has(key)) {
            return registry.peek(key);
        }
        String declared = com.matsushita.dbeditor.constants.AstMethodReturns.returnTypeOf(type, methodName);
        return registry.forOperation(key, declared, Object.class, null);
    }

    /** Dispatches to the operation of this SUT that the Scenario requested. */
    public abstract ExecutionResult execute(String operation, Object[] args);

    public final ExecutionResult invoke(String methodName, String[] declaredTypes, Object[] args) {
        return SutSupport.invoke(sut, ProjectTypes.load(implClassName), methodName, declaredTypes, args);
    }

    public final Object rawInvoke(String methodName, String[] declaredTypes, Object[] args) throws Throwable {
        return SutSupport.rawInvoke(sut, ProjectTypes.load(implClassName), methodName, declaredTypes, args);
    }

    /** Every interaction the SUT had with its declared collaborators during this Case. */
    public final List<Interaction> interactions() {
        List<Interaction> all = new ArrayList<Interaction>(staticInteractions);
        collect(mocks, all);
        collect(registry.createdMocks(), all);
        return all;
    }

    private void collect(Map<String, Object> source, List<Interaction> out) {
        for (Map.Entry<String, Object> entry : source.entrySet()) {
            Object mock = entry.getValue();
            if (mock == null) {
                continue;
            }
            try {
                Collection<Invocation> invocations = org.mockito.Mockito.mockingDetails(mock).getInvocations();
                for (Invocation invocation : invocations) {
                    out.add(new Interaction(entry.getKey(), invocation.getMethod().getName(),
                            invocation.getArguments()));
                }
            } catch (Throwable ignored) {
                // Not a mock, or invocation data unavailable; nothing to observe here.
            }
        }
    }

    public void close() {
        for (int i = closeables.size() - 1; i >= 0; i--) {
            try {
                closeables.get(i).close();
            } catch (Throwable ignored) {
                // Closing a static mock must not hide the Case result.
            }
        }
        closeables.clear();
    }
}

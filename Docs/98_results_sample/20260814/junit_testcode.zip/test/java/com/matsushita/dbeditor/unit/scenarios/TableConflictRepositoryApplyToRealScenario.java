package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableConflictRepositoryWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableConflictRepository#applyToReal.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableConflictRepositoryApplyToRealScenario {

    @Test
    @DisplayName("UTAPI-007283")
    void case_UTAPI_007283() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007283",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007283", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007283", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007283", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007283", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007283", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007283", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007283", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007283", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007283", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007283", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007283", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007283", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007283")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007284")
    void case_UTAPI_007284() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007284",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007284", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007284", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007284", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007284", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007284", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007284", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007284", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007284", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007284", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007284", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007284", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007284", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007284")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007285")
    void case_UTAPI_007285() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007285",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007285", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007285", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007285", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007285", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007285", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007285", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007285", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007285", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007285", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007285", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007285", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007285", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007285")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007286")
    void case_UTAPI_007286() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007286",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007286", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007286", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007286", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007286", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007286", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007286", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007286", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007286", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007286", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007286", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007286", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007286", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007286")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007287")
    void case_UTAPI_007287() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007287",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007287", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007287", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007287", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007287", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007287", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007287", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007287", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007287", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007287", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007287", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007287", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007287", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007287")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007288")
    void case_UTAPI_007288() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007288",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007288", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007288", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007288", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007288", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007288", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007288", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007288", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007288", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007288", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007288", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007288", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007288", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007288")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007289")
    void case_UTAPI_007289() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007289",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007289", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007289", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007289", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007289", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007289", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007289", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007289", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007289", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007289", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007289", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007289", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007289", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007289")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007290")
    void case_UTAPI_007290() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007290",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007290", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007290", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007290", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007290", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007290", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007290", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007290", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007290", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007290", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007290", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007290", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007290", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007290")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007291")
    void case_UTAPI_007291() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007291",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007291", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007291", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007291", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007291", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007291", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007291", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007291", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007291", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007291", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007291", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007291", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007291", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007291")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007292")
    void case_UTAPI_007292() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007292",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007292", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007292", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007292", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007292", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007292", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007292", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007292", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007292", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007292", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007292", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007292", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007292", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007292")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007293")
    void case_UTAPI_007293() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007293",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007293", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007293", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007293", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007293", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007293", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007293", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007293", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007293", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007293", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007293", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007293", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007293", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007293")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007294")
    void case_UTAPI_007294() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007294",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007294", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007294", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007294", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007294", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007294", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007294", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007294", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007294", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007294", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007294", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007294", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007294", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007294")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007295")
    void case_UTAPI_007295() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007295",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007295", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007295", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007295", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007295", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007295", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007295", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007295", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007295", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007295", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007295", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007295", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007295", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007295")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007296")
    void case_UTAPI_007296() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007296",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007296", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007296", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007296", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007296", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007296", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007296", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007296", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007296", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007296", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007296", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007296", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007296", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007296")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007297")
    void case_UTAPI_007297() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007297",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007297", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007297", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007297", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007297", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007297", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007297", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007297", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007297", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007297", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007297", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007297", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007297", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007297")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007298")
    void case_UTAPI_007298() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007298",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007298", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007298", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007298", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007298", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007298", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007298", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007298", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007298", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007298", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007298", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007298", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007298", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007298")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007299")
    void case_UTAPI_007299() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007299",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007299", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007299", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007299", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007299", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007299", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007299", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007299", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007299", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007299", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007299", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007299", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007299", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007299")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007300")
    void case_UTAPI_007300() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007300",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007300", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007300", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007300", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007300", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007300", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007300", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007300", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007300", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007300", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007300", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007300", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007300", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007300")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007301")
    void case_UTAPI_007301() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007301",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007301", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007301", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007301", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007301", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007301", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007301", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007301", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007301", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007301", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007301", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007301", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007301", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007301")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007302")
    void case_UTAPI_007302() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007302",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007302", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007302", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007302", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007302", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007302", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007302", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007302", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007302", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007302", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007302", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007302", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007302", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007302")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007303")
    void case_UTAPI_007303() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007303",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007303", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007303", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007303", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007303", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007303", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007303", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007303", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007303", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007303", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007303", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007303", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007303", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007303")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007304")
    void case_UTAPI_007304() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007304",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007304", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007304", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007304", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007304", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007304", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007304", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007304", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007304", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007304", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007304", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007304", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007304", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007304")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007305")
    void case_UTAPI_007305() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007305",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007305", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007305", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007305", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007305", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007305", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007305", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007305", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007305", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007305", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007305", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007305", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007305", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007305")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007306")
    void case_UTAPI_007306() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007306",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007306", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007306", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007306", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007306", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007306", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007306", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007306", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007306", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007306", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007306", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007306", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007306", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007306")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007307")
    void case_UTAPI_007307() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007307",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007307", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007307", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007307", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007307", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007307", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007307", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007307", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007307", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007307", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007307", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007307", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007307", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007307")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007308")
    void case_UTAPI_007308() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007308",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007308", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007308", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007308", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007308", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007308", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007308", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007308", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007308", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007308", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007308", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007308", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007308", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007308")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007309")
    void case_UTAPI_007309() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007309",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007309", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007309", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007309", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007309", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007309", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007309", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007309", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007309", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007309", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007309", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007309", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007309", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007309")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007310")
    void case_UTAPI_007310() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007310",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007310", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007310", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007310", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007310", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007310", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007310", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007310", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007310", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007310", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007310", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007310", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007310", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007310")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007311")
    void case_UTAPI_007311() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007311",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007311", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007311", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007311", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007311", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007311", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007311", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007311", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007311", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007311", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007311", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007311", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007311", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007311")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007312")
    void case_UTAPI_007312() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007312",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007312", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007312", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007312", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007312", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007312", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007312", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007312", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007312", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007312", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007312", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007312", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007312", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007312")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007313")
    void case_UTAPI_007313() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007313",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007313", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007313", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007313", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007313", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007313", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007313", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007313", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007313", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007313", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007313", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007313", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007313", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007313")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007314")
    void case_UTAPI_007314() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007314",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007314", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007314", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007314", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007314", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007314", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007314", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007314", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007314", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007314", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007314", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007314", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007314", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007314")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007315")
    void case_UTAPI_007315() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007315",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007315", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007315", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007315", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007315", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007315", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007315", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007315", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007315", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007315", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007315", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007315", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007315", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007315")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007316")
    void case_UTAPI_007316() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007316",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007316", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007316", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007316", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007316", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007316", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007316", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007316", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007316", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007316", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007316", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007316", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007316", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007316")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007317")
    void case_UTAPI_007317() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007317",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007317", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007317", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007317", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007317", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007317", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007317", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007317", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007317", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007317", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007317", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007317", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007317", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007317")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007318")
    void case_UTAPI_007318() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007318",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007318", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007318", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007318", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007318", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007318", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007318", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007318", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007318", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007318", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007318", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007318", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007318", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007318")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007319")
    void case_UTAPI_007319() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007319",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007319", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007319", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007319", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007319", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007319", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007319", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007319", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007319", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007319", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007319", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007319", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007319", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007319")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007320")
    void case_UTAPI_007320() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007320",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007320", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007320", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007320", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007320", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007320", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007320", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007320", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007320", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007320", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007320", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007320", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007320", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007320")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007321")
    void case_UTAPI_007321() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007321",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007321", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007321", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007321", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007321", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007321", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007321", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007321", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007321", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007321", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007321", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007321", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007321", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007321")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007322")
    void case_UTAPI_007322() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007322",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007322", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007322", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007322", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007322", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007322", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007322", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007322", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007322", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007322", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007322", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007322", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007322", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007322")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007323")
    void case_UTAPI_007323() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007323",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007323", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007323", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007323", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007323", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007323", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007323", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007323", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007323", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007323", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007323", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007323", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007323", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007323")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007324")
    void case_UTAPI_007324() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007324",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007324", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007324", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007324", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007324", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007324", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007324", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007324", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007324", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007324", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007324", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007324", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007324", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007324")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007325")
    void case_UTAPI_007325() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007325",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007325", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007325", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007325", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007325", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007325", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007325", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007325", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007325", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007325", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007325", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007325", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007325", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007325")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007326")
    void case_UTAPI_007326() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007326",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007326", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007326", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007326", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007326", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007326", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007326", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007326", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007326", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007326", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007326", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007326", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007326", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007326")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007327")
    void case_UTAPI_007327() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007327",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007327", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007327", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007327", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007327", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007327", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007327", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007327", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007327", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007327", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007327", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007327", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007327", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007327")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007328")
    void case_UTAPI_007328() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007328",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007328", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007328", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007328", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007328", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007328", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007328", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007328", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007328", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007328", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007328", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007328", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007328", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007328")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007329")
    void case_UTAPI_007329() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007329",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007329", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007329", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007329", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007329", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007329", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007329", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007329", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007329", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007329", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007329", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007329", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007329", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007329")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007330")
    void case_UTAPI_007330() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007330",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007330", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007330", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007330", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007330", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007330", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007330", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007330", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007330", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007330", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007330", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007330", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007330", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007330")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007331")
    void case_UTAPI_007331() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007331",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007331", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007331", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007331", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007331", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007331", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007331", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007331", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007331", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007331", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007331", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007331", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007331", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007331")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007332")
    void case_UTAPI_007332() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007332",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007332", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007332", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007332", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007332", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007332", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007332", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007332", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007332", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007332", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007332", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007332", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007332", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007332")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007333")
    void case_UTAPI_007333() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007333",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007333", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007333", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007333", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007333", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007333", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007333", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007333", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007333", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007333", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007333", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007333", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007333", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007333")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007334")
    void case_UTAPI_007334() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007334",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007334", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007334", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007334", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007334", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007334", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007334", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007334", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007334", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007334", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007334", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007334", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007334", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007334")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007335")
    void case_UTAPI_007335() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007335",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007335", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007335", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007335", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007335", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007335", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007335", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007335", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007335", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007335", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007335", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007335", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007335", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007335")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007336")
    void case_UTAPI_007336() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007336",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007336", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007336", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007336", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007336", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007336", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007336", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007336", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007336", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007336", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007336", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007336", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007336", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007336")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007337")
    void case_UTAPI_007337() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007337",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007337", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007337", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007337", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007337", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007337", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007337", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007337", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007337", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007337", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007337", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007337", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007337", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007337")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007338")
    void case_UTAPI_007338() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007338",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007338", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007338", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007338", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007338", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007338", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007338", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007338", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007338", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007338", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007338", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007338", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007338", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007338")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007339")
    void case_UTAPI_007339() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007339",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007339", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007339", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007339", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007339", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007339", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007339", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007339", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007339", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007339", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007339", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007339", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007339", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007339")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007340")
    void case_UTAPI_007340() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007340",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007340", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007340", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007340", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007340", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007340", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007340", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007340", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007340", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007340", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007340", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007340", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007340", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007340")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007341")
    void case_UTAPI_007341() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007341",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007341", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007341", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007341", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007341", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007341", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007341", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007341", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007341", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007341", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007341", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007341", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007341", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007341")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007342")
    void case_UTAPI_007342() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007342",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007342", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007342", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007342", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007342", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007342", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007342", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007342", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007342", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007342", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007342", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007342", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007342", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007342")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007343")
    void case_UTAPI_007343() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007343",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007343", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007343", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007343", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007343", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007343", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007343", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007343", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007343", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007343", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007343", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007343", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007343", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007343")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007344")
    void case_UTAPI_007344() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007344",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007344", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007344", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007344", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007344", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007344", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007344", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007344", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007344", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007344", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007344", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007344", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007344", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007344")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007345")
    void case_UTAPI_007345() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007345",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007345", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007345", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007345", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007345", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007345", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007345", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007345", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007345", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007345", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007345", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007345", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007345", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007345")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007346")
    void case_UTAPI_007346() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007346",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007346", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007346", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007346", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007346", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007346", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007346", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007346", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007346", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007346", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007346", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007346", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007346", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007346")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007347")
    void case_UTAPI_007347() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007347",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007347", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007347", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007347", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007347", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007347", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007347", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007347", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007347", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007347", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007347", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007347", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007347", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007347")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007348")
    void case_UTAPI_007348() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007348",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007348", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007348", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007348", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007348", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007348", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007348", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007348", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007348", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007348", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007348", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007348", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007348", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007348")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007349")
    void case_UTAPI_007349() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007349",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007349", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007349", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007349", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007349", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007349", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007349", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007349", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007349", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007349", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007349", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007349", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007349", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007349")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007350")
    void case_UTAPI_007350() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007350",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007350", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007350", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007350", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007350", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007350", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007350", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007350", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007350", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007350", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007350", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007350", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007350", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007350")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007351")
    void case_UTAPI_007351() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007351",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007351", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007351", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007351", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007351", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007351", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007351", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007351", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007351", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007351", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007351", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007351", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007351", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007351")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007352")
    void case_UTAPI_007352() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007352",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007352", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007352", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007352", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007352", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007352", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007352", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007352", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007352", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007352", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007352", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007352", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007352", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007352")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007353")
    void case_UTAPI_007353() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007353",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007353", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007353", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007353", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007353", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007353", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007353", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007353", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007353", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007353", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007353", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007353", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007353", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007353")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007354")
    void case_UTAPI_007354() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007354",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007354", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007354", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007354", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007354", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007354", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007354", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007354", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007354", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007354", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007354", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007354", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007354", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007354")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007355")
    void case_UTAPI_007355() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007355",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007355", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007355", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007355", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007355", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007355", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007355", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007355", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007355", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007355", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007355", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007355", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007355", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007355")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007356")
    void case_UTAPI_007356() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007356",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007356", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007356", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007356", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007356", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007356", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007356", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007356", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007356", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007356", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007356", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007356", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007356", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007356")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007357")
    void case_UTAPI_007357() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007357",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007357", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007357", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007357", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007357", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007357", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007357", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007357", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007357", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007357", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007357", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007357", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007357", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007357")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007358")
    void case_UTAPI_007358() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007358",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007358", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007358", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007358", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007358", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007358", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007358", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007358", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007358", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007358", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007358", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007358", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007358", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007358")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007359")
    void case_UTAPI_007359() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007359",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007359", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007359", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007359", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007359", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007359", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007359", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007359", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007359", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007359", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007359", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007359", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007359", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007359")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007360")
    void case_UTAPI_007360() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007360",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007360", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007360", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007360", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007360", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007360", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007360", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007360", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007360", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007360", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007360", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007360", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007360", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007360")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007361")
    void case_UTAPI_007361() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007361",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007361", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007361", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007361", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007361", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007361", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007361", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007361", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007361", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007361", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007361", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007361", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007361", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007361")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007362")
    void case_UTAPI_007362() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007362",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007362", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007362", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007362", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007362", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007362", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007362", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007362", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007362", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007362", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007362", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007362", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007362", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007362")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007363")
    void case_UTAPI_007363() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007363",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007363", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007363", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007363", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007363", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007363", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007363", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007363", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007363", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007363", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007363", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007363", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007363", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007363")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007364")
    void case_UTAPI_007364() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007364",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007364", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007364", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007364", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007364", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007364", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007364", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007364", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007364", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007364", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007364", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007364", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007364", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007364")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007365")
    void case_UTAPI_007365() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007365",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007365", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007365", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007365", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007365", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007365", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007365", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007365", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007365", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007365", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007365", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007365", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007365", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007365")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007366")
    void case_UTAPI_007366() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007366",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007366", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007366", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007366", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007366", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007366", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007366", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007366", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007366", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007366", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007366", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007366", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007366", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007366")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007367")
    void case_UTAPI_007367() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007367",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007367", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007367", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007367", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007367", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007367", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007367", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007367", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007367", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007367", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007367", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007367", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007367", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007367")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007368")
    void case_UTAPI_007368() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007368",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007368", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007368", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007368", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007368", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007368", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007368", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007368", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007368", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007368", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007368", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007368", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007368", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007368")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007369")
    void case_UTAPI_007369() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007369",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007369", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007369", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007369", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007369", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007369", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007369", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007369", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007369", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007369", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007369", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007369", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007369", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007369")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007370")
    void case_UTAPI_007370() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007370",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007370", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007370", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007370", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007370", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007370", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007370", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007370", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007370", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007370", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007370", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007370", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007370", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007370")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007371")
    void case_UTAPI_007371() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007371",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007371", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007371", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007371", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007371", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007371", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007371", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007371", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007371", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007371", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007371", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007371", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007371", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007371")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007372")
    void case_UTAPI_007372() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007372",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007372", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007372", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007372", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007372", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007372", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007372", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007372", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007372", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007372", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007372", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007372", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007372", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007372")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007373")
    void case_UTAPI_007373() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007373",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007373", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007373", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007373", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007373", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007373", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007373", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007373", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007373", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007373", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007373", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007373", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007373", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007373")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007374")
    void case_UTAPI_007374() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007374",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007374", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007374", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007374", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007374", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007374", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007374", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007374", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007374", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007374", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007374", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007374", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007374", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007374")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007375")
    void case_UTAPI_007375() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007375",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007375", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007375", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007375", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007375", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007375", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007375", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007375", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007375", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007375", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007375", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007375", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007375", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007375")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007376")
    void case_UTAPI_007376() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007376",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007376", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007376", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007376", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007376", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007376", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007376", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007376", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007376", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007376", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007376", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007376", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007376", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007376")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007377")
    void case_UTAPI_007377() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007377",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007377", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007377", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007377", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007377", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007377", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007377", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007377", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007377", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007377", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007377", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007377", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007377", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007377")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007378")
    void case_UTAPI_007378() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007378",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007378", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007378", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007378", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007378", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007378", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007378", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007378", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007378", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007378", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007378", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007378", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007378", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007378")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007379")
    void case_UTAPI_007379() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007379",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007379", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007379", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007379", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007379", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007379", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007379", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007379", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007379", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007379", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007379", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007379", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007379", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007379")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007380")
    void case_UTAPI_007380() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007380",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007380", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007380", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007380", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007380", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007380", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007380", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007380", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007380", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007380", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007380", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007380", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007380", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007380")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007381")
    void case_UTAPI_007381() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007381",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007381", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007381", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007381", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007381", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007381", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007381", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007381", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007381", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007381", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007381", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007381", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007381", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007381")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007382")
    void case_UTAPI_007382() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007382",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007382", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007382", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007382", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007382", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007382", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007382", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007382", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007382", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007382", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007382", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007382", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007382", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007382")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007383")
    void case_UTAPI_007383() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007383",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007383", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007383", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007383", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007383", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007383", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007383", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007383", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007383", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007383", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007383", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007383", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007383", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007383")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007384")
    void case_UTAPI_007384() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007384",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007384", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007384", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007384", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007384", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007384", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007384", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007384", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007384", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007384", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007384", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007384", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007384", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007384")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007385")
    void case_UTAPI_007385() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007385",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007385", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007385", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007385", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007385", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007385", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007385", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007385", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007385", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007385", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007385", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007385", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007385", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007385")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007386")
    void case_UTAPI_007386() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007386",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007386", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007386", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007386", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007386", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007386", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007386", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007386", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007386", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007386", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007386", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007386", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007386", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007386")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007387")
    void case_UTAPI_007387() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007387",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007387", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007387", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007387", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007387", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007387", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007387", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007387", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007387", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007387", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007387", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007387", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007387", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007387")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007388")
    void case_UTAPI_007388() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007388",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007388", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007388", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007388", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007388", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007388", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007388", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007388", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007388", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007388", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007388", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007388", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007388", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007388")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007389")
    void case_UTAPI_007389() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007389",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007389", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007389", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007389", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007389", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007389", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007389", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007389", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007389", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007389", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007389", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007389", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007389", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007389")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007390")
    void case_UTAPI_007390() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007390",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007390", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007390", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007390", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007390", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007390", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007390", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007390", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007390", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007390", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007390", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007390", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007390", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007390")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007391")
    void case_UTAPI_007391() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007391",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007391", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007391", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007391", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007391", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007391", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007391", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007391", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007391", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007391", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007391", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007391", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007391", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007391")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007392")
    void case_UTAPI_007392() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007392",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007392", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007392", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007392", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007392", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007392", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007392", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007392", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007392", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007392", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007392", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007392", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007392", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007392")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007393")
    void case_UTAPI_007393() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007393",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007393", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007393", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007393", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007393", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007393", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007393", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007393", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007393", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007393", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007393", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007393", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007393", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007393")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007394")
    void case_UTAPI_007394() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007394",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007394", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007394", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007394", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007394", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007394", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007394", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007394", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007394", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007394", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007394", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007394", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007394", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007394")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007395")
    void case_UTAPI_007395() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007395",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007395", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007395", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007395", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007395", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007395", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007395", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007395", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007395", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007395", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007395", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007395", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007395", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007395")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007396")
    void case_UTAPI_007396() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007396",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007396", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007396", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007396", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007396", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007396", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007396", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007396", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007396", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007396", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007396", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007396", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007396", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007396")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007397")
    void case_UTAPI_007397() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007397",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007397", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007397", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007397", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007397", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007397", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007397", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007397", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007397", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007397", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007397", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007397", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007397", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007397")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007398")
    void case_UTAPI_007398() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007398",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007398", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007398", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007398", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007398", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007398", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007398", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007398", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007398", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007398", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007398", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007398", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007398", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007398")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007399")
    void case_UTAPI_007399() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007399",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007399", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007399", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007399", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007399", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007399", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007399", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007399", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007399", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007399", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007399", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007399", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007399", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007399")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007400")
    void case_UTAPI_007400() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007400",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007400", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007400", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007400", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007400", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007400", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007400", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007400", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007400", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007400", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007400", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007400", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007400", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007400")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007401")
    void case_UTAPI_007401() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007401",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007401", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007401", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007401", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007401", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007401", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007401", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007401", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007401", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007401", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007401", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007401", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007401", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007401")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007402")
    void case_UTAPI_007402() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007402",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007402", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007402", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007402", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007402", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007402", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007402", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007402", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007402", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007402", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007402", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007402", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007402", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007402")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007403")
    void case_UTAPI_007403() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007403",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007403", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007403", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007403", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007403", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007403", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007403", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007403", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007403", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007403", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007403", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007403", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007403", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007403")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007404")
    void case_UTAPI_007404() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007404",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007404", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007404", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007404", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007404", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007404", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007404", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007404", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007404", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007404", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007404", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007404", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007404", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007404")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007405")
    void case_UTAPI_007405() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007405",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007405", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007405", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007405", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007405", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007405", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007405", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007405", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007405", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007405", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007405", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007405", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007405", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007405")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007406")
    void case_UTAPI_007406() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007406",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007406", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007406", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007406", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007406", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007406", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007406", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007406", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007406", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007406", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007406", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007406", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007406", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007406")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007407")
    void case_UTAPI_007407() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007407",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007407", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007407", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007407", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007407", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007407", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007407", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007407", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007407", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007407", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007407", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007407", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007407", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007407")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007408")
    void case_UTAPI_007408() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007408",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007408", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007408", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007408", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007408", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007408", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007408", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007408", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007408", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007408", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007408", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007408", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007408", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007408")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007409")
    void case_UTAPI_007409() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007409",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007409", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007409", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007409", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007409", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007409", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007409", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007409", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007409", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007409", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007409", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007409", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007409", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007409")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007410")
    void case_UTAPI_007410() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007410",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007410", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007410", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007410", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007410", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007410", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007410", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007410", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007410", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007410", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007410", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007410", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007410", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007410")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007411")
    void case_UTAPI_007411() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007411",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007411", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007411", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007411", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007411", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007411", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007411", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007411", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007411", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007411", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007411", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007411", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007411", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007411")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007412")
    void case_UTAPI_007412() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007412",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007412", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007412", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007412", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007412", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007412", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007412", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007412", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007412", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007412", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007412", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007412", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007412", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007412")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007413")
    void case_UTAPI_007413() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007413",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007413", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007413", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007413", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007413", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007413", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007413", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007413", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007413", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007413", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007413", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007413", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007413", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007413")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007414")
    void case_UTAPI_007414() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007414",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007414", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007414", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007414", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007414", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007414", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007414", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007414", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007414", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007414", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007414", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007414", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007414", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007414")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007415")
    void case_UTAPI_007415() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007415",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007415", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007415", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007415", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007415", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007415", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007415", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007415", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007415", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007415", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007415", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007415", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007415", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007415")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007416")
    void case_UTAPI_007416() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007416",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007416", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007416", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007416", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007416", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007416", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007416", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007416", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007416", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007416", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007416", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007416", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007416", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007416")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007417")
    void case_UTAPI_007417() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007417",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007417", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007417", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007417", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007417", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007417", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007417", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007417", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007417", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007417", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007417", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007417", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007417", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007417")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007418")
    void case_UTAPI_007418() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007418",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007418", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007418", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007418", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007418", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007418", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007418", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007418", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007418", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007418", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007418", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007418", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007418", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007418")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007419")
    void case_UTAPI_007419() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007419",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007419", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007419", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007419", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007419", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007419", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007419", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007419", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007419", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007419", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007419", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007419", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007419", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007419")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007420")
    void case_UTAPI_007420() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007420",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007420", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007420", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007420", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007420", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007420", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007420", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007420", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007420", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007420", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007420", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007420", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007420", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007420")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007421")
    void case_UTAPI_007421() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007421",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007421", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007421", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007421", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007421", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007421", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007421", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007421", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007421", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007421", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007421", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007421", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007421", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007421")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007422")
    void case_UTAPI_007422() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007422",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007422", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007422", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007422", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007422", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007422", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007422", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007422", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007422", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007422", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007422", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007422", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007422", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007422")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007423")
    void case_UTAPI_007423() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007423",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007423", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007423", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007423", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007423", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007423", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007423", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007423", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007423", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007423", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007423", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007423", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007423", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007423")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007424")
    void case_UTAPI_007424() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007424",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007424", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007424", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007424", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007424", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007424", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007424", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007424", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007424", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007424", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007424", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007424", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007424", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007424")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007425")
    void case_UTAPI_007425() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007425",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007425", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007425", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007425", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007425", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007425", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007425", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007425", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007425", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007425", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007425", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007425", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007425", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007425")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007426")
    void case_UTAPI_007426() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007426",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007426", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007426", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007426", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007426", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007426", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007426", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007426", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007426", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007426", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007426", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007426", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007426", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007426")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007427")
    void case_UTAPI_007427() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007427",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007427", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007427", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007427", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007427", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007427", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007427", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007427", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007427", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007427", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007427", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007427", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007427", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007427")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007428")
    void case_UTAPI_007428() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007428",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007428", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007428", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007428", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007428", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007428", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007428", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007428", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007428", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007428", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007428", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007428", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007428", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007428")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007429")
    void case_UTAPI_007429() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007429",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007429", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007429", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007429", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007429", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007429", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007429", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007429", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007429", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007429", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007429", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007429", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007429", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007429")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007430")
    void case_UTAPI_007430() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007430",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007430", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007430", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007430", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007430", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007430", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007430", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007430", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007430", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007430", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007430", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007430", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007430", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007430")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007431")
    void case_UTAPI_007431() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007431",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007431", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007431", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007431", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007431", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007431", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007431", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007431", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007431", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007431", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007431", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007431", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007431", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007431")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007432")
    void case_UTAPI_007432() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007432",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007432", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007432", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007432", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007432", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007432", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007432", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007432", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007432", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007432", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007432", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007432", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007432", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007432")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007433")
    void case_UTAPI_007433() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007433",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007433", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007433", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007433", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007433", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007433", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007433", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007433", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007433", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007433", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007433", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007433", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007433", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007433")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007434")
    void case_UTAPI_007434() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007434",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007434", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007434", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007434", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007434", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007434", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007434", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007434", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007434", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007434", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007434", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007434", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007434", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007434")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007435")
    void case_UTAPI_007435() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007435",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007435", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007435", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007435", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007435", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007435", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007435", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007435", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007435", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007435", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007435", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007435", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007435", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007435")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007436")
    void case_UTAPI_007436() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007436",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007436", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007436", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007436", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007436", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007436", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007436", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007436", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007436", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007436", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007436", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007436", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007436", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007436")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007437")
    void case_UTAPI_007437() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007437",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007437", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007437", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007437", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007437", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007437", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007437", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007437", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007437", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007437", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007437", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007437", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007437", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007437")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007438")
    void case_UTAPI_007438() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007438",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007438", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007438", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007438", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007438", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007438", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007438", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007438", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007438", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007438", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007438", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007438", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007438", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007438")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007439")
    void case_UTAPI_007439() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007439",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007439", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007439", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007439", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007439", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007439", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007439", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007439", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007439", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007439", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007439", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007439", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007439", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007439")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007440")
    void case_UTAPI_007440() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007440",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007440", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007440", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007440", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007440", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007440", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007440", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007440", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007440", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007440", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007440", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007440", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007440", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007440")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007441")
    void case_UTAPI_007441() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007441",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007441", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007441", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007441", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007441", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007441", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007441", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007441", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007441", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007441", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007441", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007441", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007441", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007441")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007442")
    void case_UTAPI_007442() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007442",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007442", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007442", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007442", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007442", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007442", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007442", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007442", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007442", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007442", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007442", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007442", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007442", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007442")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007443")
    void case_UTAPI_007443() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007443",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007443", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007443", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007443", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007443", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007443", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007443", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007443", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007443", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007443", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007443", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007443", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007443", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007443")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007444")
    void case_UTAPI_007444() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007444",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007444", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007444", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007444", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007444", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007444", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007444", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007444", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007444", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007444", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007444", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007444", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007444", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007444")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007445")
    void case_UTAPI_007445() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007445",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007445", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007445", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007445", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007445", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007445", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007445", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007445", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007445", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007445", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007445", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007445", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007445", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007445")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007446")
    void case_UTAPI_007446() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007446",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007446", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007446", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007446", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007446", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007446", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007446", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007446", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007446", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007446", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007446", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007446", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007446", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007446")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007447")
    void case_UTAPI_007447() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007447",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007447", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007447", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007447", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007447", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007447", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007447", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007447", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007447", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007447", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007447", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007447", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007447", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007447")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007448")
    void case_UTAPI_007448() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007448",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007448", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007448", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007448", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007448", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007448", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007448", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007448", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007448", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007448", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007448", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007448", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007448", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007448")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007449")
    void case_UTAPI_007449() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007449",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007449", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007449", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007449", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007449", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007449", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007449", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007449", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007449", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007449", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007449", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007449", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007449", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007449")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007450")
    void case_UTAPI_007450() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007450",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007450", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007450", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007450", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007450", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007450", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007450", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007450", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007450", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007450", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007450", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007450", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007450", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007450")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007451")
    void case_UTAPI_007451() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007451",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007451", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007451", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007451", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007451", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007451", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007451", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007451", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007451", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007451", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007451", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007451", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007451", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007451")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007452")
    void case_UTAPI_007452() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007452",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007452", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007452", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007452", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007452", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007452", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007452", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007452", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007452", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007452", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007452", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007452", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007452", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007452")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007453")
    void case_UTAPI_007453() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007453",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007453", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007453", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007453", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007453", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007453", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007453", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007453", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007453", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007453", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007453", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007453", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007453", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007453")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007454")
    void case_UTAPI_007454() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007454",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007454", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007454", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007454", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007454", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007454", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007454", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007454", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007454", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007454", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007454", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007454", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007454", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007454")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007455")
    void case_UTAPI_007455() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007455",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007455", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007455", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007455", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007455", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007455", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007455", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007455", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007455", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007455", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007455", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007455", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007455", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007455")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007456")
    void case_UTAPI_007456() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007456",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007456", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007456", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007456", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007456", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007456", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007456", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007456", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007456", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007456", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007456", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007456", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007456", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007456")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007457")
    void case_UTAPI_007457() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007457",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007457", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007457", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007457", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007457", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007457", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007457", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007457", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007457", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007457", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007457", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007457", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007457", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007457")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007458")
    void case_UTAPI_007458() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007458",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007458", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007458", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007458", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007458", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007458", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007458", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007458", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007458", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007458", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007458", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007458", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007458", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007458")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007459")
    void case_UTAPI_007459() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007459",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007459", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007459", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007459", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007459", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007459", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007459", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007459", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007459", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007459", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007459", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007459", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007459", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007459")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007460")
    void case_UTAPI_007460() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007460",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007460", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007460", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007460", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007460", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007460", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007460", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007460", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007460", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007460", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007460", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007460", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007460", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007460")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007461")
    void case_UTAPI_007461() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007461",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007461", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007461", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007461", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007461", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007461", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007461", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007461", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007461", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007461", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007461", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007461", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007461", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007461")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007462")
    void case_UTAPI_007462() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007462",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007462", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007462", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007462", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007462", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007462", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007462", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007462", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007462", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007462", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007462", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007462", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007462", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007462")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007463")
    void case_UTAPI_007463() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007463",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007463", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007463", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007463", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007463", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007463", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007463", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007463", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007463", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007463", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007463", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007463", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007463", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007463")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007464")
    void case_UTAPI_007464() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007464",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007464", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007464", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007464", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007464", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007464", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007464", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007464", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007464", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007464", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007464", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007464", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007464", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007464")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007465")
    void case_UTAPI_007465() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007465",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007465", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007465", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007465", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007465", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007465", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007465", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007465", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007465", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007465", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007465", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007465", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007465", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007465")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

}

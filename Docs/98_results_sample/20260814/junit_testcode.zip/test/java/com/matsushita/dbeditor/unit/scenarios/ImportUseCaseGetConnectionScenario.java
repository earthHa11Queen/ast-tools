package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ImportUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ImportUseCase#getConnection.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ImportUseCaseGetConnectionScenario {

    @Test
    @DisplayName("UTAPI-012522")
    void case_UTAPI_012522() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012522",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "getConnection",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012522", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012522")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::getConnection::6::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012523")
    void case_UTAPI_012523() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012523",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "getConnection",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012523", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012523")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::getConnection::6::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012524")
    void case_UTAPI_012524() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012524",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "getConnection",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012524", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012524")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::getConnection::6::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012525")
    void case_UTAPI_012525() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012525",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "getConnection",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012525", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012525")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::getConnection::6::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012526")
    void case_UTAPI_012526() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012526",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "getConnection",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012526", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012526")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::getConnection::6::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012527")
    void case_UTAPI_012527() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012527",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "getConnection",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012527", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012527")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::getConnection::6::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012528")
    void case_UTAPI_012528() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012528",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "getConnection",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012528", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012528")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::getConnection::6::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012529")
    void case_UTAPI_012529() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012529",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "getConnection",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012529", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012529")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::getConnection::6::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012530")
    void case_UTAPI_012530() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012530",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "getConnection",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012530", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012530")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::getConnection::6::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012531")
    void case_UTAPI_012531() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012531",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "getConnection",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012531", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012531")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::getConnection::6::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012532")
    void case_UTAPI_012532() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012532",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "getConnection",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012532", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012532")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::getConnection::6::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

}

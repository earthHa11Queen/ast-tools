package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ExportUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ExportUseCase#exportMarkdown.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ExportUseCaseExportMarkdownScenario {

    @Test
    @DisplayName("UTAPI-012200")
    void case_UTAPI_012200() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012200",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012200", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012200", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012200", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012200")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012201")
    void case_UTAPI_012201() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012201",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012201", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012201", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012201", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012201")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012202")
    void case_UTAPI_012202() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012202",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012202", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012202", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012202", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012202")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012203")
    void case_UTAPI_012203() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012203",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012203", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012203", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012203", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012203")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012204")
    void case_UTAPI_012204() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012204",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012204", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012204", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012204", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012204")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012205")
    void case_UTAPI_012205() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012205",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012205", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012205", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012205", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012205")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012206")
    void case_UTAPI_012206() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012206",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012206", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012206", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012206", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012206")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012207")
    void case_UTAPI_012207() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012207",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012207", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012207", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012207", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012207")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012208")
    void case_UTAPI_012208() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012208",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012208", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012208", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012208", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012208")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012209")
    void case_UTAPI_012209() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012209",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012209", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012209", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012209", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012209")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012210")
    void case_UTAPI_012210() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012210",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012210", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012210", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012210", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012210")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012211")
    void case_UTAPI_012211() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012211",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012211", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012211", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012211", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012211")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012212")
    void case_UTAPI_012212() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012212",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012212", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012212", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012212", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012212")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012213")
    void case_UTAPI_012213() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012213",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012213", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012213", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012213", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012213")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012214")
    void case_UTAPI_012214() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012214",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012214", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012214", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012214", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012214")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012215")
    void case_UTAPI_012215() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012215",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012215", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012215", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012215", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012215")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012216")
    void case_UTAPI_012216() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012216",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012216", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012216", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012216", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012216")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012217")
    void case_UTAPI_012217() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012217",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012217", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012217", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012217", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012217")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012218")
    void case_UTAPI_012218() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012218",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012218", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012218", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012218", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012218")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012219")
    void case_UTAPI_012219() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012219",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012219", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012219", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012219", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012219")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012220")
    void case_UTAPI_012220() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012220",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012220", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012220", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012220", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012220")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012221")
    void case_UTAPI_012221() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012221",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012221", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012221", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012221", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012221")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012222")
    void case_UTAPI_012222() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012222",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012222", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012222", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012222", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012222")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012223")
    void case_UTAPI_012223() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012223",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012223", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012223", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012223", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012223")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012224")
    void case_UTAPI_012224() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012224",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012224", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012224", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012224", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012224")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012225")
    void case_UTAPI_012225() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012225",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012225", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012225", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012225", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012225")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012226")
    void case_UTAPI_012226() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012226",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012226", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012226", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012226", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012226")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012227")
    void case_UTAPI_012227() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012227",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012227", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012227", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012227", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012227")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012228")
    void case_UTAPI_012228() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012228",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012228", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012228", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012228", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012228")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012229")
    void case_UTAPI_012229() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012229",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012229", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012229", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012229", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012229")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012230")
    void case_UTAPI_012230() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012230",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012230", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012230", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012230", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012230")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012231")
    void case_UTAPI_012231() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012231",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012231", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012231", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012231", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012231")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012232")
    void case_UTAPI_012232() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012232",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012232", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012232", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012232", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012232")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012233")
    void case_UTAPI_012233() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012233",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012233", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012233", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012233", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012233")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012234")
    void case_UTAPI_012234() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012234",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012234", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012234", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012234", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012234")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012235")
    void case_UTAPI_012235() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012235",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012235", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012235", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012235", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012235")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012236")
    void case_UTAPI_012236() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012236",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012236", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012236", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012236", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012236")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012237")
    void case_UTAPI_012237() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012237",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012237", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012237", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012237", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012237")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012238")
    void case_UTAPI_012238() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012238",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012238", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012238", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012238", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012238")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012239")
    void case_UTAPI_012239() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012239",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012239", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012239", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012239", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012239")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012240")
    void case_UTAPI_012240() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012240",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012240", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012240", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012240", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012240")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012241")
    void case_UTAPI_012241() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012241",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012241", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012241", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012241", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012241")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012242")
    void case_UTAPI_012242() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012242",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012242", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012242", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012242", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012242")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012243")
    void case_UTAPI_012243() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012243",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012243", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012243", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012243", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012243")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012244")
    void case_UTAPI_012244() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012244",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012244", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012244", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012244", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012244")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012245")
    void case_UTAPI_012245() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012245",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012245", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012245", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012245", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012245")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012246")
    void case_UTAPI_012246() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012246",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012246", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012246", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012246", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012246")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012247")
    void case_UTAPI_012247() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012247",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012247", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012247", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012247", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012247")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012248")
    void case_UTAPI_012248() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012248",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012248", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012248", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012248", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012248")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012249")
    void case_UTAPI_012249() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012249",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012249", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012249", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012249", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012249")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012250")
    void case_UTAPI_012250() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012250",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012250", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012250", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012250", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012250")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012251")
    void case_UTAPI_012251() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012251",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012251", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012251", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012251", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012251")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012252")
    void case_UTAPI_012252() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012252",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportMarkdown",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012252", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012252", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012252", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012252")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportMarkdown::3::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

}
